// --------------------------------
// correctores: www.auladoce.com
// autor: jose manuel baldo pujante
// email: jmbp10m@msn.com
// corrector level1/tad01.cc
// --------------------------------

#include <iostream>
#include "tavlcalendario.h"

using namespace std;

int main(void)
{
  TAVLCalendario a, b, c;
  cout << "No hace nada" << endl;
  return 0;
}
