// --------------------------------
// correctores: www.auladoce.com
// autor: jose manuel baldo pujante
// email: jmbp10m@msn.com
// corrector level3/tad02.cc
// --------------------------------
// prueba II a tuti pleni
#include <iostream>
#include "tavlcalendario.h"
using namespace std;

const int kCalendarios = 100;
int main(void)
{
	TAVLCalendario a;
	int i;
	TCalendario calendarios[kCalendarios];

	for(i = 0; i < kCalendarios; i++)
		calendarios[i].ModFecha(1, 1, 2000 + i); 


	for(i = kCalendarios - 1; i >= 0 ; i--)
		a.Insertar(calendarios[i]);

	cout << a.Inorden() << endl << a.Preorden() << endl; 

	return 0;
}
