//Daniel Asensi Roch 
//48776120C

#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <vector>
#include <string>
#include <cstring>


using namespace std;

#define KRef 16
#define Knom 50
#define KDes 200


struct Tproductos
{
    char referencia[KRef];
    char nombre[Knom];
    char descripcion[KDes];
    unsigned cod;
    float precio;
    bool temp;
    int cant;
};

struct Ttipos
{
    unsigned cod;
    char descripcion[KDes];
};

//PROTOTIPOS
void mostrarLeotipos(Ttipos nuevo);
void mostrarLeoProductos(Tproductos nuevo);
bool leerFicheroBinarioproductos(string ficheroBin, vector<Tproductos>&productos,bool mostrar);
bool leerFicheroBinariotipos(string ficheroBin, vector<Ttipos>&tipos,bool mostrar);
void generarFichero(vector<Ttipos> tipos, vector<Tproductos>productos,string ficheroSalida,string separador);
bool comprobarArgumentos(int args, char *argv[], string &separador, string &ficheroSalida, bool &mostrar);





int main(int args, char *argv[])
{
    string ficheroSalida;
    string separador="";
    string ficheroBin1="products.bin";
    string ficheroBin2="types.bin";
    vector<Tproductos>productos;
    vector<Ttipos>tipos;
    bool mostrar;
    
    if(comprobarArgumentos(args,argv,separador,ficheroSalida,mostrar)==false)
    {
        cout<<"Error en los argumentos"<<endl;
    }
    else{
        if(leerFicheroBinarioproductos(ficheroBin1,productos,mostrar)==true&&leerFicheroBinariotipos(ficheroBin2,tipos,mostrar)==true)
        {
          if(separador=="pc")
          {
            separador=";";
          }
          if(separador=="dp")
          {
            separador=":";
          }
          if(separador=="co")
          {
            separador=";";
          }
            generarFichero(tipos,productos,ficheroSalida,separador);
        }
    }
}

/*
  Funció que utilizamos para mostrar lo que vamos leyendo desde el fichero binario;
*/
void mostrarLeotipos(Ttipos nuevo)
{
    cout<<nuevo.cod<<" "<<nuevo.descripcion<<endl;

}
/*
  Funció que utilizamos para mostrar lo que vamos leyendo desde el fichero binario;
*/

void mostrarLeoProductos(Tproductos nuevo)
{
    cout<<nuevo.referencia<<" "<<nuevo.nombre<<" "<<nuevo.descripcion<<" ";
    cout<<nuevo.cod<<" "<<nuevo.precio<<" "<<nuevo.cant;
    cout<<endl;

}

/*Leemos el fichero binario de productos, importante 
pasarle el bool de mostrar para mostrarlo o no mientras leemos*/

bool leerFicheroBinarioproductos(string ficheroBin, vector<Tproductos>&productos,bool mostrar)
{
    Tproductos nuevo;
    bool leido=false;

    ifstream fich(ficheroBin,ios::binary);

    if(fich.is_open())
    {
        while(fich.read((char* )&nuevo,sizeof(nuevo))){
            productos.push_back(nuevo);
            if(mostrar==true){
                mostrarLeoProductos(nuevo);
            }
        }
        fich.close();
        leido=true;
    }
    else
    {
        cout<<"No se ha podido abrir el bin"<<endl;
    }
    return leido;
}
/*Leemos el fichero binario de tipos, importante 
pasarle el bool de mostrar para mostrarlo o no mientras leemos*/

bool leerFicheroBinariotipos(string ficheroBin, vector<Ttipos>&tipos,bool mostrar)
{
    Ttipos nuevo;
    bool leido=false;

    ifstream fich(ficheroBin,ios::binary);

    if(fich.is_open())
    {
        while(fich.read((char* )&nuevo,sizeof(nuevo))){

            tipos.push_back(nuevo);
            mostrarLeotipos(nuevo);
        }
        fich.close();
        leido=true;
    }
    else
    {
        cout<<"No se ha podido abrir el bin"<<endl;
    }
    return leido;
}


/* No me ha dado tiempo a generear el fichero de forma correcta*/
void generarFichero(vector<Ttipos> tipos, vector<Tproductos>productos,string ficheroSalida,string separador)
{
    ofstream fich(ficheroSalida);

        for(unsigned i = 0; i < productos.size();i++)
        {
            for(unsigned j = 0; j < tipos.size(); j++)
            {
                if(productos[i].cod==tipos[j].cod)
                {
                  fich<<productos[i].referencia<<separador<<productos[i].nombre<<separador;
                  for(unsigned k = 0; k < 100; k++)
                  {
                    fich<<tipos[i].descripcion[k];
                  }
                  fich<<separador<<productos[i].precio<<separador<<endl;
                }
            }
        }
}


bool comprobarArgumentos(int args, char *argv[], string &separador, string &ficheroSalida, bool &mostrar)
{ 
  bool aprobado = true; 
  separador = ""; 
  ficheroSalida = "";
  mostrar = false;

  for(int i = 1; i < args && aprobado != false; i++)
  { 
    if(strcmp(argv[i], "-v") == 0)
    { 
      if(!mostrar){ 
        mostrar = true;
      }
      else{
        aprobado = false; 
      }
    }
    else{
      if(strcmp(argv[i], "-f") == 0){ 
        if(ficheroSalida == ""){ 
          if(i + 1 < args){ 
            ficheroSalida = argv[i + 1]; 
            i++;
          }
          else{
            aprobado = false; 
          }
        }
        else{
          aprobado = false; 
        }
      }
      else{ 
        if(strcmp(argv[i], "-s") == 0){ 
          if(separador == ""){
            if(i + 1 < args){ 
              separador = argv[i + 1]; 
              i++;
            }
            else{
              aprobado = false; 
            }
          }
          else{
            aprobado = false; 
          }
        }
        else{
          aprobado = false; 
        }
      }
    }
  }

  if(ficheroSalida == ""){
    aprobado = false;
  }
  if(separador == ""){
    aprobado = false;
  }
  return aprobado; 
}