// Programación 2 - Examen Julio 2020         

#include "Record.h"

// Crea una instancia de registro médico, el doctor se referencia por su identificador
Record::Record(unsigned int doctor, string report, int cost, bool hospitalized) {
    this->doctor = doctor;
    this->report = report;
    this->cost = cost;
    this->hospitalized = hospitalized;
}

// Devuelve el identificador del doctor que trató al paciente
unsigned int Record::getDoctor() const {
    return doctor;
}

// Devuelve el informe del tratamiento
string Record::getReport() const {
    return report;
}

// Devuelve el coste del tratamiento
int Record::getCost() const {
    return cost;
}

// Devuelve verdadero si el tratamiento requirió hospitalización del paciente
bool Record::isHospitalized() const {
    return hospitalized;
}
