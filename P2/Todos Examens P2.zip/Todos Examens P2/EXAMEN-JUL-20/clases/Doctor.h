// Programación 2 - Examen Julio 2020 
//Daniel Asensi Roch 48776120C        

#ifndef __DOCTOR__
#define __DOCTOR__

#include <string>

using namespace std;

class Doctor {
    private:
        unsigned int id;
        string name;
        string specialty;
    public:
        Doctor(unsigned int id, string name, string specialty);
        unsigned int getId() const;
        string getName() const;
        string getSpecialty() const;
};

#endif
