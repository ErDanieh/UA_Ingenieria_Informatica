// Programación 2 - Examen Julio 2020         
//Daniel Asensi Roch 48776120C
#ifndef __PATIENT__
#define __PATIENT__

#include <string>
#include <vector>

using namespace std;

#include "Record.h"

class Patient {
  private:
    unsigned int id;
    string name;
    string address;
    string country;
    vector<Record> records;

  public:
    Patient(unsigned int id, string name, string address, string country);
    unsigned int getId() const;
    string getName() const;
    string getAddress() const;
    string getCountry() const;
    void createRecord(unsigned int doctor, string report, int cost, bool hospitalized);
    //Almacenamos los records de cada paciente
    vector <Record> getRecords(); 
    //Almacenamos las posiciones en el vector
    vector <unsigned> getDoctors();

};

#endif
