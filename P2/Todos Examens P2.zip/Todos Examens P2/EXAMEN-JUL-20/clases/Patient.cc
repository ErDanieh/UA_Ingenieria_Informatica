// Programación 2 - Examen Julio 2020         
//Daniel Asensi Roch 48776120C
#include "Patient.h"

// Crea una instancia de la clase Patient
// El identificador lo gestiona la clase Hospital
Patient::Patient(unsigned int id, string name, string address, string country) {
    this->id = id;
    this->name = name;
    this->address = address;
    this->country = country;
}

// Devuelve el identificador del paciente
unsigned int Patient::getId() const {
    return id;
}

// Devuelve el nombre del paciente
string Patient::getName() const {
    return name;
}

// Devuelve la dirección del paciente
string Patient::getAddress() const {
    return address;
}

// Devuelve el país del paciente
string Patient::getCountry() const {
    return country;
}

// Crea un registro médico para el paciente
// El parámetro doctor contiene el identificador del doctor que le atendió
void Patient::createRecord(unsigned int doctor, string report, int cost, bool hospitalized) {
    Record r(doctor, report, cost, hospitalized);
    records.push_back(r);
}


vector <Record> Patient::getRecords(){
    return records;
}


/*
    funcion que devuelve un array de lso doctores
    sin repeticiones
*/
vector <unsigned> Patient::getDoctors(){
    
    vector <unsigned> doctores;
    vector <unsigned> doctoresUnicos;
    bool existe = false;
    
    unsigned int codDoctor;

    //Recorremos los doctores para meterlos en el vector
    for(unsigned i = 0; i < records.size(); i++){
        doctores.push_back(records[i].getDoctor());
    }

    for(unsigned i = 0; i < doctores.size(); i++){
        for (unsigned j = 0; j < doctoresUnicos.size() && existe == false; j++)
        {
            if(doctoresUnicos[j] == doctores[i]){
                existe = true;
            }
        }
        if(existe == false){
            doctoresUnicos.push_back(doctores[i]);
        }

        //Reiniciamos la busqueda
        existe = false;
    }
    

    return doctores;
}


