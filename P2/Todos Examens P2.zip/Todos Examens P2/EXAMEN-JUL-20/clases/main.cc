// Programación 2 - Examen Julio 2020    
//Daniel Asensi Roch 48776120C     

#include <iostream>

using namespace std;

#include "Hospital.h"

void createData(Hospital &);

int main() {
    Hospital obj("Johns Hopkins");
    createData(obj);
}

// Crea datos de ejemplo para probar las funcionalidades
void createData(Hospital &obj) {
    obj.createDoctor("Lourdes R. Barrett", "Cardiology");
    obj.createDoctor("Ricky K. Dolezal", "Cardiology");
    obj.createDoctor("Ashlee J. Weaver", "Cardiology");
    obj.createDoctor("Michael T. Welch", "Pediatrics");
    obj.createDoctor("Sonya C. Sims", "Pediatrics");
    obj.createDoctor("Sarah L. Sale", "Dermatology");
    obj.createDoctor("Herman M. Pratt", "Dermatology");

    obj.createPatient("Jennifer M. Houston", "1821 Winifred Way", "Spain");
    obj.createPatient("Brian O. Bailey", "3411 Bastin Drive", "Spain");
    obj.createPatient("Michael T. Welch", "872 Concord Street", "Spain");
    obj.createPatient("Gladys J. Barter", "2706 Angie Drive", "Spain");
    obj.createPatient("Desiree Gallardo", "4936 Karen Lane", "Mexico");
    obj.createPatient("Duane D. Lyles", "2792 University Drive", "Colombia");
    obj.createPatient("Jeffrey D. Howard", "165 Winifred Way", "Spain");

    obj.createRecord("Jennifer M. Houston", "Sarah L. Sale", "First visit", 65, false);
    obj.createRecord("Jennifer M. Houston", "Sarah L. Sale", "Stain treatment", 150, false);
    obj.createRecord("Jennifer M. Houston", "Sonya C. Sims", "First visit", 35, false);
    obj.createRecord("Brian O. Bailey", "Sarah L. Sale", "First visit", 65, false);
    obj.createRecord("Brian O. Bailey", "Ricky K. Dolezal", "First visit", 90, false);
    obj.createRecord("Brian O. Bailey", "Ricky K. Dolezal", "Bypass", 2000, true);
    obj.createRecord("Brian O. Bailey", "Ricky K. Dolezal", "Medical monitoring", 50, false);
    obj.createRecord("Brian O. Bailey", "Sonya C. Sims", "First visit", 35, false);
    obj.createRecord("Michael T. Welch", "Michael T. Welch", "First visit", 35, false);
    obj.createRecord("Michael T. Welch", "Michael T. Welch", "Medical monitoring", 35, false);
    obj.createRecord("Michael T. Welch", "Sarah L. Sale", "First visit", 65, false);
    obj.createRecord("Gladys J. Barter", "Sarah L. Sale", "First visit", 65, false);
    obj.createRecord("Gladys J. Barter", "Sonya C. Sims", "First visit", 35, false);
    obj.createRecord("Gladys J. Barter", "Sonya C. Sims", "Admission to hospital for observation", 1500, true);
    obj.createRecord("Gladys J. Barter", "Sonya C. Sims", "Medical monitoring", 45, false);
    obj.createRecord("Desiree Gallardo", "Herman M. Pratt", "First visit", 70, false);
    obj.createRecord("Duane D. Lyles", "Michael T. Welch", "First visit", 35, false);
    obj.createRecord("Duane D. Lyles", "Michael T. Welch", "Medical monitoring", 35, false);
    obj.createRecord("Jeffrey D. Howard", "Ricky K. Dolezal", "First visit", 90, false);

    //Llamada a la función de report, dentro de la función he
    //hecho que se muestre por pantalla los nombres
    //Este es solo una prueba de ejecución
    obj.report("Brian O. Bailey");

    
}
