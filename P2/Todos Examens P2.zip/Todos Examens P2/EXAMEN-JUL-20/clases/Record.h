// Programación 2 - Examen Julio 2020         

#ifndef __RECORD__
#define __RECORD__

#include <string>

using namespace std;

class Record {
    private:
        unsigned int doctor;
        string report;
        int cost;
        bool hospitalized;
    public:
        Record(unsigned int doctor, string report, int cost, bool hospitalized);
        unsigned int getDoctor() const;
        string getReport() const;
        int getCost() const;
        bool isHospitalized() const;
};

#endif
