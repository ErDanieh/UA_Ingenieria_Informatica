// Programación 2 - Examen Julio 2020 
//Daniel Asensi Roch 48776120C        

#include "Doctor.h"

// Crea una instancia del doctor
// El identificador lo gestiona la clase Hospital
Doctor::Doctor(unsigned int id, string name, string specialty) {
    this->id = id;
    this->name = name;
    this->specialty = specialty;
}

// Devuelve el id del doctor
unsigned int Doctor::getId() const {
    return id;
}

// Devuelve el nombre del doctor
string Doctor::getName() const {
    return name;
}

// Devuelve la especialidad del doctor
string Doctor::getSpecialty() const {
    return specialty;
}
