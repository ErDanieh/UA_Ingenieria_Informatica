// Programación 2 - Examen Julio 2020       
//Daniel Asensi Roch 48776120C  

#ifndef __HOSPITAL__
#define __HOSPITAL__

#include <string>
#include <vector>

#include "Doctor.h"
#include "Patient.h"

using namespace std;

// Excepciones que puede lanzar la clase
enum ExceptionsHospital {
    unknown_doctor,
    doctor_exists,
    unknown_patient,
    patient_exists
};

class Hospital {
  private:
    static unsigned int nextPatientId;
    static unsigned int nextDoctorId;
    string name;
    vector<Doctor> doctors;
    vector<Patient> patients;
    int searchDoctorByName(string name) const;
    int searchPatientByName(string name) const;

  public:
    Hospital(string name);
    void createDoctor(string name, string specialty);
    void createPatient(string name, string address, string country);
    void createRecord(string patient, string doctor, string report, int cost, bool hospitalized);
    vector <string> report(string patient);
    int calcularSimilares(vector <unsigned> vec1, vector <unsigned> vec2);
};

#endif
