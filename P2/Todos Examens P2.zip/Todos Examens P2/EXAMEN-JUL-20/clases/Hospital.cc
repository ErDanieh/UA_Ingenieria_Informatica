// Programación 2 - Examen Julio 2020  
//Daniel Asensi Roch 48776120C       

#include <iostream>
using namespace std;

#include "Hospital.h"

unsigned int Hospital::nextDoctorId = 1000;
unsigned int Hospital::nextPatientId = 2000;

// Devuelve la posición del doctor en el vector doctors dado el nombre, o -1 si no lo encuentra
int Hospital::searchDoctorByName(string name) const {
    for (unsigned i = 0; i < doctors.size(); i++) {
        if (doctors[i].getName() == name) {
            return i;
        }
    }
    return -1;
}

// Devuelve la posición del paciente en el vector patients dado el nombre, o -1 si no lo encuentra
int Hospital::searchPatientByName(string name) const {
    for (unsigned i = 0; i < patients.size(); i++) {
        if (patients[i].getName() == name) {
            return i;
        }
    }
    return -1;
}

// Crea una instancia del hospital
Hospital::Hospital(string name) {
    this->name = name;
}

// Crea un doctor y lo guarda en el vector de doctores
// Lanza una excepción si ya hay un doctor con ese nombre
void Hospital::createDoctor(string name, string specialty) {
    int pos = searchDoctorByName(name);
    if (pos != -1) {
        throw doctor_exists;
    }
    unsigned int id = nextDoctorId++;
    Doctor d(id, name, specialty);
    doctors.push_back(d);
}

// Crea un paciente y lo guarda en el vector de pacientes
// Lanza una excepción si ya hay un paciente con ese nombre
void Hospital::createPatient(string name, string address, string country) {
    int pos = searchPatientByName(name);
    if (pos != -1) {
        throw patient_exists;
    }
    unsigned int id = nextPatientId++;
    Patient p(id, name, address, country);
    patients.push_back(p);
}

// Crea un registro médico y lo guarda en el vector de registros del paciente
// Si el paciente o el doctor no existen lanza una excepción
void Hospital::createRecord(string patient, string doctor, string report, int cost, bool hospitalized) {
    int pos = searchPatientByName(patient);
    if (pos == -1) {
        throw unknown_patient;
    }
    int pos2 = searchDoctorByName(doctor);
    if (pos2 == -1) {
        throw unknown_doctor;
    }
    unsigned int doctorId = doctors[pos2].getId();
    patients[pos].createRecord(doctorId, report, cost, hospitalized);
}


vector <string> Hospital::report(string patient){


    int pos = searchPatientByName(patient);//Buscamos la posicion del paciente

    vector <string> reportPacientes;
    
    for (unsigned i = 0; i < patients.size(); i++)
    {
        //Comparamos los codigos de los docotores
        if(i != pos && calcularSimilares(patients[pos].getDoctors(),patients[i].getDoctors()) >= 2){
            reportPacientes.push_back(patients[i].getName());
        }



    }
    
    for(unsigned i = 0 ; i < reportPacientes.size(); i++){
        cout << reportPacientes[i] << endl;
    }
    return reportPacientes;
}

/*
    funcion que devuelve el numero de similitudes entre
    dos vectores con elementos no repetidos, devolviendo su longitud
    si su longitud es mayor o igual a 2, metemos al paciente en el vector
*/
int Hospital::calcularSimilares(vector <unsigned> vec1, vector <unsigned> vec2){
    
    vector <unsigned> similares = vec1;

    int numSimilares = 0;
    bool existe = false;
    
    for(unsigned i = 0; i < vec2.size(); i++){
        for(unsigned j = 0; j < similares.size() && existe == false; j++){
            
            if(vec2[i] == similares[j]){
                existe = true;
            }
        }

        if(existe == true){
            similares.push_back(vec2[i]);
        }

        existe = false;
    }

    numSimilares = similares.size();

    return numSimilares;
}
