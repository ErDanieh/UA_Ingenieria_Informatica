#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <vector>
#include <string>
#include <cstring>

using namespace std;

struct TActividad
{
    string Actividad;
    vector<string>Participantes;
};

void anadir(string nombre,string actividad,vector<TActividad>&actividades)
{
    int pos=-1;
    TActividad nueva;

    for(unsigned i = 0; i < actividades.size(); i++)
    {
        if(actividades[i].Actividad==actividad)
        {
            pos=i;
        }
    }
    
    if(pos==-1)
    {
        nueva.Actividad=actividad;
        nueva.Participantes.push_back(nombre);
        actividades.push_back(nueva);
    }
    else
    {
        actividades[pos].Participantes.push_back(nombre);
    }
}

void leerFichero(string ficheroTexto, vector<TActividad> &actividades)
{
    string nombre;
    string actividad;
    TActividad nueva;
    string linea;
    
    ifstream fich(ficheroTexto);
    if(fich.is_open())
    {
        while(getline(fich,linea))
        {
            stringstream proce(linea);
            getline(proce,nombre,',');
            
            getline(proce,actividad,',');

            anadir(nombre,actividad,actividades);
            while(!proce.eof())
            {
                getline(proce,actividad,',');
                anadir(nombre,actividad,actividades);
            }

        }
        fich.close();
    }
    else
    {
        cout<<"Error al abrir el fichero"<<endl;
    }
}


void imprimir(vector<TActividad>actividades)
{
    for(unsigned i = 0; i < actividades.size(); i++)
    {
        cout<<actividades[i].Actividad<<": ";
        for(unsigned j = 0; j < actividades[i].Participantes.size();j++)
        {
            cout<<actividades[i].Participantes[j]<<" ";
        }
        cout<<endl;
    }
}


int main (int args, char *argv[])
{
    string ficheroTexto;
    vector<TActividad>actividades;

    if(args!=2)
    {
        cout<<"Error en los argumentos"<<endl;
    }
    else
    {
        ficheroTexto=argv[1];
        leerFichero(ficheroTexto,actividades);
        imprimir(actividades);
        
    }
}