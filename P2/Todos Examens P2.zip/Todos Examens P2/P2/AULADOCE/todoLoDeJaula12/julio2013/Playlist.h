#ifndef _Playlist
#define _Playlist
#include <iostream>
#include <vector>
#include "Cancion.h"
using namespace std;

class Playlist{
	friend ostream &operator<<(ostream &os, const Playlist &pl);
	private:
		string nombre;
		vector<Cancion> canciones;
		bool buscarCancion(const Cancion &c) const;
	public:
		Playlist(string nombre);
		float getPuntuacionMedia() const;
		vector<string> getArtistas() const;
		bool anyadirCancion(const Cancion &c);
};


#endif
