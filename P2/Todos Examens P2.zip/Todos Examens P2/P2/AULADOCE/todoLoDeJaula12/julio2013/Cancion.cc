#include "Cancion.h"
const int Cancion::SP = -1;
Cancion::Cancion(string nombre, string artista, int punt){
	this->nombre = nombre;
	this->artista = artista;
	if(punt < 0 || punt > 5){
		puntuacion = SP;
	}
	else{
		puntuacion = punt;	
	}
}
string Cancion::getNombre() const{
	return nombre;
}
string Cancion::getArtista() const{
	return artista;
}
int Cancion::getPuntuacion() const{
	return puntuacion;
}
void Cancion::setPuntuacion(int puntuacion){
	if(puntuacion >= 1 && puntuacion <= 5){
		this->puntuacion = puntuacion;
	}
	else{
		cout << "Error en puntuacion" << endl;
	}

}	
ostream &operator<<(ostream &os, const Cancion &can){
	os << can.artista << " - " << can.nombre;
	if(can.puntuacion != Cancion::SP){
		os << " - " << can.puntuacion;
	}
	return os;
}
