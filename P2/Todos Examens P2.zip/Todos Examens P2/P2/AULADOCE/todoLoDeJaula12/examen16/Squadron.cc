#include "Squadron.h"
#include <fstream>

Squadron::Squadron(string filename, string name){
	ifstream fich;
	string type;
	int attack, shield;	

	this->name = name;
	wins = 0;
	losses = 0;
	fich.open(filename.c_str());
	if(fich.is_open()){
		fich >> type >> attack >> shield;
		while(!fich.eof()){
			// creamos el Fighter y lo metemos
			try{
				Fighter nuevo(type, attack, shield);
				fighters.push_back(nuevo);			
			}
			catch(int &e){
				cout << "Wrong fighter data" << endl;
			}
			fich >> type >> attack >> shield;		
		}
		fich.close();
	}	
}

void Squadron::fight(Squadron &enemy){
	int pos, posEnemy;
	//Fighter feste, fenemy;
	
	while(fighters.size() > 0 && enemy.fighters.size() > 0){
		pos = Fighter::getRandomNumber(fighters.size());
		posEnemy = Fighter::getRandomNumber(enemy.fighters.size());
		Fighter feste = fighters[pos];
		Fighter fenemy = enemy.fighters[posEnemy];
		fighters.erase(fighters.begin() + pos);
		enemy.fighters.erase(enemy.fighters.begin() + posEnemy);
		// luchar hasta que se mueran
		while(feste.getShield() >= 0 && fenemy.getShield() >= 0){
			if(!feste.fight(fenemy)){
				fenemy.fight(feste);
			}
		}
		if(feste.getShield() >= 0){
			fighters.push_back(feste);
			wins++;
			enemy.losses++;
		}
		else{
			enemy.fighters.push_back(fenemy);
			enemy.wins++;
			losses++;	
		}
	}
}

ostream &operator<<(ostream &os, const Squadron &sq){
	os << sq.name << ": Wins=" << sq.wins << " Losses=" << sq.losses;
	for(int i  = 0; i < sq.fighters.size(); i++){
		os << " " << sq.fighters[i] ;
	}
	return os;
}











