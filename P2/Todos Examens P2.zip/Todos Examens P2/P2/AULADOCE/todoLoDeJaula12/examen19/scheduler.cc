#include "scheduler.h"
#include <fstream>

scheduler::scheduler(string filename)
{
    ifstream fich;
    string linea;

    fich.open(filename.c_str());

    if(fich.is_open())
    {
        while(getline(fich,linea))
        {
            hoguera nueva(linea);
            hoguera.push_back(nueva);
        }
        fich.close();
    }
    else
    {
        cout<<"Error al abrir el fichero"<<endl;
    }
}

void scheduler::addTeam(string team)
{
    teams.push_back(team);
}

void scheduler::distributeTeams()
{
    int pos;
    bool todasAsignadas=false;
    
    while(todasAsignadas==false)
    {
        for(unsigned i = 0; i < hoguera.size(); i++)
        {
            pos=getMinor();
            if(pos!=-1)
            {
                hoguera[pos].setTeam(team[i]);
            }
            else{
                todasAsignadas=true;
            }
        }
    }
}

int scheduler::getMinor()const
{
    int pos=-1;

    for (unsigned i = 0; i < hoguera.size(); i++)
    {
        if(hoguera[i].getTeam()=="")
        {
            if(pos==-1)
            {
                pos=i;
            }
            else{
                if(hoguera[i].getTime()< hoguera[pos].getTime())
                {
                    pos=i;
                }
            }
        }

    }
    return pos;
}