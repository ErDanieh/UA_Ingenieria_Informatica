#include "hoguera.h"
#include <sstream>

int hoguera::idNextHoguera=1;

hoguera::hoguera(string line)
{
    stringstream proce(line);

    getline(proce,name,':');
    getline(proce,time);

    id=idNextHoguera;
    idNextHoguera++;
    team="";
}

hoguera::getTime()const
{
    return time;
}

hoguera::getTime()const
{
    return team;
}

hoguera::setTime(int time)
{
    this->time=time;
}

hoguera::setTeam(string team)
{
    this->team=team;
}

ostream &operator<<(ostream &os, const hoguera &g)
{
    os<<hoguera.name<<"( "<<hoguera.id<<")="hoguera.time;
    return os;
}