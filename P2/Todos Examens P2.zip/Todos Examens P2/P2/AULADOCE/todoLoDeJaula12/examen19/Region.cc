#include <iostream>
#include "Region.h"

Region::Region(string name){
	this->name = name;
}

int Region::findStation(string name) const{
	int i, pos;
	pos = -1;
	for(i = 0; i < stations.size() && pos == -1; i++){
		if(stations[i].getName() == name){
			pos = i;
		}
	}
	return pos;
}

bool Region::addStation(string filename){
	bool added = false;
	int pos;

	try{
		Station newStation(filename);
		pos = findStation(newStation.getName());
		if(pos == -1){
			stations.push_back(newStation);
		}
		else{
			stations[pos] = newStation;
		}
	}
	catch(int &e){
		added = false;
		cout << "Error opening file" << endl;
	}
	return added;
}

float Region::getValue(string name, Value v, Month m) const{
	int pos;
	float average;
	pos = findStation(name);
	if(pos == -1){
		average = -1;
		cout << "Wrong station name" << endl;
	}
	else{
		average = stations[pos].getValue(v, m);
	}
	return average;
}

float Region::getAvgTemp(Month m) const{
	float totalAverage = 0;

	for(int i = 0; i < stations.size(); i++){
		totalAverage += stations[i].getValue(T, m);
	}
	if(stations.size() > 0){
		totalAverage /= stations.size();
	}

	return 0;
}

string Region::getWarmestStation(Month m) const{
	string warmestName = "";
	int posMax, i;

	if(stations.size() > 0){
		posMax = 0;
		for(i = 0; i < stations.size(); i++){
			// si el valor de la posicion i es mayor que el de posMax
			if(stations[i].getValue(TM, m) > stations[posMax].getValue(TM, m)){
				posMax = i;
			}
		}
		warmestName = stations[posMax].getName();
	}
	return warmestName;	
}























