#include <iostream>
#include "Station.h"
#include <fstream>
unsigned int Station::nextId = 1;

Station::Station(string filename){
	ifstream fich;
	string ignored;

	fich.open(filename.c_str());
	if(!fich.is_open()){
		throw 1;
	}	

	// leemos el nombre de la estacion.
	getline(fich, name);
	for(int i = Jan; i <= Dec; i++){
		fich >> ignored >> data[T][i] >> data[TM][i] >> data[Tm][i];
	}
	fich.close();

	id = nextId;
	nextId++;
}

float Station::getValue(Value v, Month m) const{
	return data[v][m];
}

string Station::getName() const{
	return name;
}

ostream &operator<<(ostream &os, const Station &s){
	os << s.name << " (" << s.id << ")";
	return os;
}
