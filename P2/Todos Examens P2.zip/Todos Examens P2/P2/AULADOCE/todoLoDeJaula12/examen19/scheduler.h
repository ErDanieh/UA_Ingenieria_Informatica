#ifndef _scheduler_
#define _scheduler_

#include <iostream>
#include <cstring>
#include <hoguera.h>

using namespace std;

class scheduler
{
    friend ostream& operator<<(ostream &os, scheduler &q);

    private:
    vector<string> teams;
    vector<hoguera>hoguera;

    public:
    scheduler(string fileName);
    void addTeam(string team);
    void distributeTeams();
    int getMinor()const;

};

#endif