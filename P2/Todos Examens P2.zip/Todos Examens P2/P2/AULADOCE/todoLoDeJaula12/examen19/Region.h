#ifndef _REGION_
#define _REGION_
#include "Station.h"
#include <vector>
#include <iostream>
using namespace std;

class Region{
	private:
		string name;
		vector<Station> stations;
		int findStation(string name) const;
	public:
		Region(string name);
		bool addStation(string filename);
		float getValue(string name, Value v, Month m) const;
		float getAvgTemp(Month m) const;
		string getWarmestStation(Month m) const;
};
#endif
