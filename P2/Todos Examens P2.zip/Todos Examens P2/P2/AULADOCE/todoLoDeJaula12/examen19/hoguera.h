#ifndef _hoguera_
#define _hoguera_

#include <iostream>
#include <cstring>

using namespace std;

class hoguera
{
    friend ostream& operator<<(ostream &os, hoguera &q);

    private:
    //Si esta subrayado hay que ponerle static delante
    static int idNextHoguera;
    int id;
    string team;
    int time;
    string name;

    public:
    hoguera(string line);
    int getTime()const;
    string getTeam()const;
    void setTime(int time);
    void setTeam(string team);

};

#endif