#include <iostream>
#include "Station.h"
using namespace std;


int main(){
	Station athar("medidas.txt");

	cout << athar << endl;
	for(int i = 0; i < 12; i++){
		for(int j = 0; j < 3; j++){
			 cout << athar.getValue((Value)j, (Month)i) << " ";		
		}
		cout << endl;
	}
	return 0;
}
