#include "Region.h"
#include "Station.h"
using namespace std;

int main(){
    Region r("Comunitat Valenciana");
        
    r.addStation("Alicante.txt");
    r.addStation("Valencia.txt");
    r.addStation("Castellon.txt");
    r.addStation("unknown.txt");

    cout << r.getValue("Alicante",Tm,Sep) << endl;
    cout << r.getAvgTemp(Oct) << endl;
    cout << r.getWarmestStation(Aug) << endl;

    return 0;
}
	/*
		======================================
		SESIONES DE P2 A PARTIR DEL 18 DE MAYO
		======================================

		1 sesion -----------------------------
			lunes 9 - 10:30
			o
			lunes 16 - 17:30

		2 sesion -----------------------------
			lunes 19 - 20:30
			o		
			jueves 16 - 17:30

		3 sesion -----------------------------
			jueves 19 - 20:30
			o		
			viernes 16 - 17:30
	*/
