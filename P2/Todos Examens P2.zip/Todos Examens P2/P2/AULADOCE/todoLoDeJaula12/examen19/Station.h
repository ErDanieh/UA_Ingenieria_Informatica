#ifndef _STATION_
#define _STATION_
#include <iostream>
using namespace std;

enum Value{T, TM, Tm};
enum Month{Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec};

class Station{
	friend ostream &operator<<(ostream &os, const Station &s);
	private:
		string name;
		static unsigned int nextId;
		unsigned int id;
		float data[3][12];
	public:
		Station(string filename);
		float getValue(Value v, Month m) const;
		string getName() const;
};

#endif
