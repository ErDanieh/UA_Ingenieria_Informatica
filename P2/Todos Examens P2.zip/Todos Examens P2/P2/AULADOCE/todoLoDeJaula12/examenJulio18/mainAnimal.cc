#include <iostream>
#include "Animal.h"
using namespace std;

int main(){
	Animal a("josesdogs,Dog,3");

	cout << a << endl;

	return 0;
}
