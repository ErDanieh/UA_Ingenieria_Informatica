#include "Shelter.h"

const int Shelter::MAXADOPTED = 3;

int Shelter::search(const Animal &a) const{
	int pos, i;
	pos = -1;
	for(i = 0; i < animals.size() && pos == -1; i++){
		if(animals[i].getName() == a.getName()){
			if(animals[i].getAnimalType() == a.getAnimalType()){
				pos = i;
			}
		}
	}
	return pos;
}
/*
bool Shelter::ownerIsValid(string owner) const{
	// contar la cantidad de animales que tiene el dueño.
	bool puede = true;	
	int animalicos = 0;

	for(int i = 0; i < animals.size() && puede == true; i++){
		if(animals[i].getOwner() == owner){
			animalicos++;
			if(animalicos == MAXADOPTED){
				puede = false;
			}
		}
	}
	return puede;
}
*/

bool Shelter::ownerIsValid(string owner) const{
	// contar la cantidad de animales que tiene el dueño.
	int animalicos = 0;
	for(int i = 0; i < animals.size() && animalicos < MAXADOPTED; i++){
		if(animals[i].getOwner() == owner){
			animalicos++;
		}
	}
	return animalicos != 3;
}

Shelter::Shelter(string name){
	this->name = name;
}

bool Shelter::add(const Animal &a){
	bool added = false;
	int pos;
	pos = search(a);
	if(pos != 1){
		animals.push_back(a);
		added = true;
	}
	return added;
}

bool Shelter::adopt(const Animal &a, string owner){
	bool adopted;
	int pos;
	adopted = ownerIsValid(owner);
	pos = search(a);
	if(pos != -1 && adopted && !animals[pos].isAdopted()){
		animals[pos].adopthitler(owner);
	}
	return adopted;
}

ostream &operator<<(ostream &os, const Shelter &s){
	os << "---- Adopted ----" << endl;
	for(int i = 0; i < s.animals.size(); i++){
		if(s.animals[i].isAdopted()){
			os << s.animals[i] << endl;
		}
	}
	os << "---- Not adopted ----" << endl;
	for(int i = 0; i < s.animals.size(); i++){
		if(!s.animals[i].isAdopted()){
			os << s.animals[i] << endl;
		}
	}
	return os;
}














