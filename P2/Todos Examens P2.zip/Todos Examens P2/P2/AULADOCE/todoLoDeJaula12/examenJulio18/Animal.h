#ifndef _ANIMAL_
#define _ANIMAL_
#include <iostream>
using namespace std;

enum AnimalType {Cat, Dog, Jerbo};
class Animal{
	friend ostream &operator<<(ostream &os, const Animal &a);
	private:
		string name;
		unsigned int age;
		AnimalType type;
		string owner;	
		static AnimalType getTypeOf(string s);
		static string getStringOf(AnimalType type);
	public:
		Animal(string s);
		string getName() const;
		unsigned getAge() const;
		AnimalType getAnimalType() const;
		string getOwner() const;
		void adopthitler(string owner);
		bool isAdopted() const;
};
#endif
