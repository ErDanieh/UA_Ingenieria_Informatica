#include "Partida.h"

Partida::Partida(int numJugadores){
	// crea un vector de 5 Jugadores.
	// jugadores = vector<Jugador>(numJugadores);

	Jugador nuevo;
	for(int i = 1; i <= numJugadores; i++){
		jugadores.push_back(nuevo);
	}
	// jugadores.size() no hace falta guardar una variable con el 
	// tamaño del vector.
	rack = "";
}

void Partida::generarRack(){
	char letra;
	char respuesta;	
	string vocales = "AEIOU";
	string letras = "BCDFGHJLMNPQRSTVWXYZ";


	rack = "";
	for(int i = 1; i <= 9; i++){
		do{
			cout << "(V)ocal o (C)onsontante?: ";				
			cin >> respuesta;
			cin.get();
		}while(respuesta != 'V' && respuesta != 'C');
		if(respuesta == 'V'){
			letra = vocales[rand() % vocales.length()];
		}
		else{
			letra = letras[rand() % letras.length()];
		}
		rack += letra;
	}
}

void Partida::jugar(){
	string palabra;
	bool exito, terminar;

	terminar = false;
	do{
		generarRack();
		cout << "Rack=" << rack << endl;
		for(int i = 0; i < jugadores.size() && !terminar; i++){
			do{		
				cout << "Jugador " << i << "=";
				getline(cin, palabra);
				if(palabra == "q"){
					terminar = true;
				}
				else{
					exito = jugadores[i].mover(palabra, rack);
				}
			}while(!exito && !terminar);
		}
	}while(!terminar);
}

ostream &operator<<(ostream &os, const Partida &c){
	for(int i = 0; i < c.jugadores.size(); i++){
		os << "Jugador " << i << ": " << c.jugadores[i].getPuntuacion() << endl;
	}
	return os;
}





