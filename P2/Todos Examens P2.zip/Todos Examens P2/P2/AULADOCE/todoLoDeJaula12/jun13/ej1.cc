#include <iostream>
#include <sstream>
#include <vector>
#include <fstream>
using namespace std;

struct Actividad{
	string deporte;
	vector<string> retards;
};

void actualizar(vector<Actividad> &actividades, string nombre, string deporte){
	int pos, i;
	Actividad nueva;
	pos = -1;
	for(i = 0; i < actividades.size() && pos == -1; i++){
		if(actividades[i].deporte == deporte){
			pos = i;
		}
	}
	if(pos != -1){
		actividades[pos].retards.push_back(nombre);
	}
	else{
		nueva.retards.push_back(nombre);
		nueva.deporte = deporte;
		actividades.push_back(nueva);
	}
}

void procesarLinea(string linea, vector<Actividad> &actividades){
	stringstream ss(linea);
	string nombre, deporte;
	
	getline(ss, nombre, ',');

	getline(ss, deporte, ',');
	while(!ss.eof()){
		actualizar(actividades, nombre, deporte);
		getline(ss, deporte, ',');
	}
	actualizar(actividades, nombre, deporte);
}

void procesarFichero(string nombre){
	vector<Actividad> actividades;
	ifstream fich;
	string linea;

	fich.open(nombre.c_str());
	if(fich.is_open()){
		getline(fich, linea);
		while(!fich.eof()){
			procesarLinea(linea, actividades);
			getline(fich, linea);
		}
		fich.close();
		for(int i = 0; i < actividades.size(); i++){
			cout << actividades[i].deporte << ": ";
			for(int j = 0; j < actividades[i].retards.size(); j++){
				cout << actividades[i].retards[j] << ", ";		
			}	
			cout << endl;
		}
	}
}


int main(int argc, char *argv[]){
	if(argc == 2){
		procesarFichero(argv[1]);		
	}

	return 0;
}
