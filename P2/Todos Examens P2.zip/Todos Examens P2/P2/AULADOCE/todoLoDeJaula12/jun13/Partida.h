#ifndef _PARTIDA_
#define _PARTIDA_
#include "Jugador.h"
#include <iostream>
#include <vector>
using namespace std;

class Partida{
	friend ostream &operator<<(ostream &os, const Partida &partida);
	private:
		vector<Jugador> jugadores; // borja advertisiment
		static const int letrasRack;
		int turno;
		string rack;
		void generarRack();
	public:
		Partida(int numJugadores = 1);
		void jugar();
};


#endif
