#include "Jugador.h"

Jugador::Jugador(){
	puntuacion = 0;
}

int Jugador::getPuntuacion() const{
	return puntuacion;
}

// rack = "--CD-CS"

// palabra = "CADA"

bool Jugador::mover(string palabra, string rack){
	bool found = false;
	// comprobrar que todas las letras de la palabra estan en el rack.
	
	found = true;
	for(int i = 0; i < palabra.length() && found == true; i++){
		found = false;
		for(int j = 0; j < rack.length() && !found; j++){
			if(palabra[i] == rack[j]){
				found = true;
				// rack.erase(palabra.begin() + i);		
				rack[j] = '-';			
			}
		}
	}
	if(found){
		puntuacion = puntuacion + palabra.length();
	}
	else{
		cout << "Palabra incorrecta" << endl;
	}
	return found;
}
