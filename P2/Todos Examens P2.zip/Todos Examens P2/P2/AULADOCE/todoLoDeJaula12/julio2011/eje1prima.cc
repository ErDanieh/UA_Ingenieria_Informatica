/*
	programa que imprime las 5 palabras que mas se repiten en 
	el fichero, ordenadas de mayor a menor cantidad
*/
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <cctype>
using namespace std;

struct Palabra{
	string palabra;
	int veces;
};

// inserta la palabra en el vector palabra
// 	si no estaba la pone al final con una vez.
//	si ya estaba incrementara el numero de veces.
void insertar(vector<Palabra> &palabras, string palabra){
	int i, pos;
	pos = -1;
	for(i = 0; i < palabras.size() && pos == -1; i++){
		if(palabras[i].palabra == palabra){
			pos = i;	
		}
	}
	if(pos == -1){
		Palabra nueva;
		nueva.palabra = palabra;
		nueva.veces = 1;
		palabras.push_back(nueva);
	}
	else{
		palabras[pos].veces++;
	}
}

void procesar(string linea, vector<Palabra> &palabras){
	int i;
	string palabra;
	// vector<Palabra> palabras; El vector viene de fuera
	// para que lo rellenemos aqui, no se declara dentro de la funcion.

	i = 0;
	while(i < linea.length()){
		// busco el princpio de la palabra
		while(i < linea.length() && isalpha(linea[i]) == 0){
			i++;
		}
		
		// busco el final de la palabra
		palabra = "";
		while(i < linea.length() && isalpha(linea[i]) != 0){
			palabra += linea[i];
			i++;
		}
	
		if(palabra != ""){
			insertar(palabras, palabra);
		}
	}
}



void leerFichero(const char filename[]){
	ifstream fich;
	string linea;
	vector<Palabra> palabras;
	
	fich.open(filename);
	if(!fich.is_open()){
		cout << "Error. File not found" << endl;
	}
	else{
		getline(fich, linea);
		while(!fich.eof()){
			// añade las palabras de la linea al vector
			// de palabras.
			procesar(linea, palabras);
			getline(fich, linea);
		}
		fich.close();
		// ordenar el vector.
		for(int i = 1; i < palabras.size(); i++){
			for(int j = palabras.size() - 1; j >= i; j--){
				if(palabras[j].veces > palabras[j-1].veces){
					Palabra aux = palabras[j];
					palabras[j] = palabras[j-1];
					palabras[j-1] = aux;
				}
			}
		}

		// cuando acabamos de leer el fichero imprimimos las palabras
		for(int i = 0; i < palabras.size() && i < 5; i++){
			cout << palabras[i].palabra << ", " << palabras[i].veces << endl;
		}
	}
}


int main(int argc, char *argv[]){
	if(argc == 2){
		leerFichero(argv[1]);
	}
	else{
		cout << "Ussage: ./main filename" << endl;
	}
	return 0;
}
