#ifndef _PIEZA_
#define _PIEZA_
#include <iostream>
using namespace std;

class Pieza{
	private:
		char tipo;
		bool color;
	public:
		Pieza(char tipo = ' ', bool color = false);
		char getTipo() const;
		bool getColor() const;
		bool isVacia() const;
		void setVacia();
};


#endif
