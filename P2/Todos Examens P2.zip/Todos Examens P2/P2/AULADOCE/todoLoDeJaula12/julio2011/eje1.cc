#include <iostream>
#include <fstream>
#include <vector>
#include <cctype>
#include <algorithm>
using namespace std;

// inserta la palabra en el vector palabras, si aun no estaba.
void insertar(vector<string> &palabras, string palabra){
	if(find(palabras.begin(), palabras.end(), palabra) == palabras.end()){
		palabras.push_back(palabra);
	}
}


void procesar(string linea){
	int i;
	string palabra;
	vector<string> palabras;

	i = 0;
	while(i < linea.length()){
		// busco el princpio de la palabra
		while(i < linea.length() && isalpha(linea[i]) == 0){
			i++;
		}
		
		// busco el final de la palabra
		palabra = "";
		while(i < linea.length() && isalpha(linea[i]) != 0){
			palabra += linea[i];
			i++;
		}
	
		if(palabra != ""){
			insertar(palabras, palabra);
		}
	}
	cout << palabras.size() << " " << linea << endl;
}


/*
// Muestra para cada linea las palabras.
void procesar(string linea){
	int i;
	string palabra;

	i = 0;
	while(i < linea.length()){
		// busco el princpio de la palabra
		while(i < linea.length() && isalpha(linea[i]) == 0){
			i++;
		}
		
		// busco el final de la palabra
		palabra = "";
		while(i < linea.length() && isalpha(linea[i]) != 0){
			palabra += linea[i];
			i++;
		}
	
		if(palabra != ""){
			cout << palabra << endl;
		}
	}
	cout << "------------------------" << endl;
}
*/
// leer el fichero linea a linea
void leerFichero(const char filename[]){
	ifstream fich;
	string linea;
	
	fich.open(filename);
	if(!fich.is_open()){
		cout << "Error. File not found" << endl;
	}
	else{
		getline(fich, linea);
		while(!fich.eof()){
			procesar(linea);
			getline(fich, linea);
		}
	}
}


int main(int argc, char *argv[]){
	if(argc == 2){
		leerFichero(argv[1]);
	}
	else{
		cout << "Ussage: ./main filename" << endl;
	}
	return 0;
}
