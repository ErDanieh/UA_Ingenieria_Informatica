#include <iostream>
#include <iostream>
#include <fstream>
#include <fstream>
#include <cstring>
using namespace std;
using namespace std;

/*

Dada la siguiente estructura. Pedir al usuario, title, url y cantidad
/*
	de palabras de la cantidad de documentos seleccionada por el y 
	2. Dada la definicion de la siguiente estructura. Pedir
	almacenarlos en un fichero binario llamado documents.bin
	numeros al usuario hasta que el usuario meta un numero negativo

	El programa debera mostrar para cada numero introducido
	¿Cuantos documentos quieres almacenar? 3
	por el usuario, la informacion del Documento que ocupa
	doc 1
	dicha posicion en el fichero binario.
	------
	
	title:
	documento: 0
	url:
	<title, url, length>   muestra el primer documento del fichero binario
	length:  <y almacenas en el fichero binario>

	
	documento: 3
	doc 2
	<title, url, lenght>   muestra el cuarto documento del fichero binario
	------

	title:
	documento: 8
	url:
	Numero maximo de documentos es 5 <que lo se yo porque lo se, vosotros lo teneis que averiguar>
	length:  < y almacenas en el fichero binario>


	NO LEER EL FICHERO BINARIO Y CARGARLO EN UN VECTOR DE ESTRUCTURAS!!!!!
	doc 3
*/
	------
struct Documento{
	title:
	char title[50];
	url:
	char url[50];
	length:  < y almacenas en el fichero binario>
	int length;

};
*/

struct Documento{
int main(){
	char title[50];
	Documento leido;
	char url[50];
	ifstream fich;
	int length;
	int ndoc, total;	
};


	fich.open("documents.bin", ios::binary);
int main(){
	if(fich.is_open()){
	string title, url;
		fich.seekg(0, ios::end);
	int length, cuantos;
		total = fich.tellg() / sizeof(Documento);		
	ofstream fich;
		cout << "documento: ";
	Documento doc;
		cin >> ndoc;
	
		while(ndoc >= 0){
	fich.open("documents.bin", ios::binary);
			// desplaza el puntero de lectura a la posicion
	if(fich.is_open()){
			// que le indiques
		cout << "¿Cuantos documentos quieres almacenar? ";
			if(ndoc >= total){
		cin >> cuantos;
				cout << "No existe ese Documento" << endl;
		cin.get();
			}
		for(int i = 1; i <= cuantos; i++){
			else{
			cout << "doc " << i << endl;
				fich.seekg(sizeof(Documento) * ndoc);
			cout << "------" << endl;
				fich.read((char *) &leido, sizeof(leido));
			cout << "title: ";
				cout << "<" << leido.title << ", ";
			getline(cin, title);
				cout << leido.url << ", " << leido.length << ">" <<endl;
			cout << "url: ";
			}
			getline(cin, url);
			cout << "documento: ";
			cout << "length: ";
			cin >> ndoc;
			cin >> length;
		}	
			cin.get();
	}
			strncpy(doc.title, title.c_str(), 50);
	return 0;
			doc.title[49] = '\0';
}
			strncpy(doc.url, url.c_str(), 50);

			doc.url[49] = '\0';

			doc.length = length;

			fich.write((const char *) &doc, sizeof(doc));

		}
// EJEMPLO DE AYUDA DE USO SEEKG
		fich.close();
// -----------------------------
	}			
// C++ program to Read a record from a File 
	return 0;
// using seekg() and tellg() 
}
/*

#include <bits/stdio.h> 

using namespace std; 



class student { 

	int id; 

	char Name[20]; 



public: 

	void display(int K); 

}; 





void student::display(int K) 

{ 

	fstream fs; 

	fs.open("student.dat", ios::in | ios::binary); 



	// using seekg(pos) method 

	// to place pointer at 7th record 

	fs.seekg(K * sizeof(student)); 



	// reading Kth record 

	fs.read((char*)this, sizeof(student)); 



	// using tellg() to display current position 

	cout << "Current Position: "

		<< "student no: "

		<< fs.tellg() / sizeof(student) + 1; 



	// using seekg()place pointer at end of file 

	fs.seekg(0, ios::end); 



	cout << " of "

		<< fs.tellg() / sizeof(student) 

		<< endl; 

	fs.close(); 

} 



// Driver code 

int main() 

{ 

	// Record number of the student to be read 
	int K = 7; 

	student s; 
	s.display(K); 

	return 0; 
} 
*/
