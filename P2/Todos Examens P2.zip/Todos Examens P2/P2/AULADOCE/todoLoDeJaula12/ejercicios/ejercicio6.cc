/*
	realizar un programa de menciones.
	Hemos recibido una conversacion de un grupo de whatsapp y queremos saber quien menciono
	a quien en cada whatsapp. El formato del fichero sera:

	athar said: el    puto     @juan esta loco y es muy facha
	juan said: mediciona @julia jaa ja ja @dani negro es
	nico said: @josea12 @pacomoreno se aman
	jose said: @juan @julia @nico estais todos locos si muy locos
	jose said: @juan

	El programa debera mostrar para cada usuario a quien nombre
	@athar -> @juan
	@nico -> @josea12 @pacomoreno
	@jose -> @juan @julia @nico

	suponer que es un whatsapp por linea.
*/
#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <algorithm>
using namespace std;

struct Entrada{
	string nombre;
	vector<string> mencionados;
};

void insertar(vector<Entrada> &entradas, string nombre, string mensionao){
	int i, pos;
	pos = -1;
	for(i = 0; i < entradas.size() && pos == -1; i++){
		if(entradas[i].nombre == nombre){
			pos = i;
		}
	}
	if(pos == -1){
		Entrada nueva;
		nueva.nombre = nombre;
		nueva.mencionados.push_back(mensionao);
		entradas.push_back(nueva);
	}
	else{
		if(find(entradas[pos].mencionados.begin(), entradas[pos].mencionados.end(), mensionao) == entradas[pos].mencionados.end()){
			entradas[pos].mencionados.push_back(mensionao);
		}
	}

}


// como estan separadas por espacios las palabras usaremos stringstream
void procesarLineaMulti(vector<Entrada> &entradas, string linea){
	int i;
	string nombre;
	string aux;
	stringstream ss(linea);

	ss >> nombre; // nombre
	
	while(ss >> aux){
		if(aux[0] == '@'){
			insertar(entradas, nombre, aux);
		}
	}
}


// como estan separadas por espacios las palabras usaremos stringstream
void procesarLinea(vector<Entrada> &entradas, string linea){
	int i;
	string aux;
	Entrada nueva;	
	stringstream ss(linea);
	ss >> nueva.nombre;
	while(ss >> aux){
		if(aux[0] == '@'){
			nueva.mencionados.push_back(aux);
		}
	}
	entradas.push_back(nueva);
}
/*
void procesarLinea(vector<Entrada> &entradas, string linea){
	int i;
	string nombre, mencionado;
	Entrada nueva;	
	i = 0;
	nombre = "";
	while(linea[i] != ' '){
		nombre += linea[i++];
	}
	nueva.nombre = nombre;
	while(i < linea.length()){
		while(i < linea.length() && linea[i] == ' '){
			i++;	
		}
		mencionado = "";
		while(i < linea.length() && linea[i] != ' '){
			mencionado += linea[i];
		}
		if(mencionado[0] == '@'){
			nueva.mencionados.push_back(mencionado);
		}
	}
	entradas.push_back(nueva);
}
*/
void leerFichero(string nom_fich){
	ifstream fich;
	string linea;
	vector<Entrada> menciones;

	fich.open(nom_fich.c_str());
	if(fich.is_open()){
		getline(fich, linea);
		while(!fich.eof()){
			procesarLineaMulti(menciones, linea);
			getline(fich, linea);
		}
		fich.close();
		for(int i = 0; i < menciones.size(); i++){
			cout << "Usuario: " << menciones[i].nombre << endl;
			cout << "Menciones: ";		
			for(int j = 0; j < menciones[i].mencionados.size(); j++){
				cout << menciones[i].mencionados[j] << " ";
			} 
			cout << endl;
		}
	}	
}

int main(int argc, char *argv[]){
	leerFichero(argv[1]);
	return 0;
}

