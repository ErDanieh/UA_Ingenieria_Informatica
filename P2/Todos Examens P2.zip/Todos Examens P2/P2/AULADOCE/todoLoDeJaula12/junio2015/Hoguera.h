#ifndef _HOGUERA_
#define _HOGUERA_
#include <iostream>
using namespace std;
class Hoguera{
	friend ostream &operator<<(ostream &os, const Hoguera &h);
	private:
		static int idNextHoguera;
		int id;
		string team;
		int time;
		string name;
	public:
		Hoguera(string line);
		int getTime() const;
		string getTeam() const;
		void setTime(int time);
		void setTeam(string team);
};
#endif
