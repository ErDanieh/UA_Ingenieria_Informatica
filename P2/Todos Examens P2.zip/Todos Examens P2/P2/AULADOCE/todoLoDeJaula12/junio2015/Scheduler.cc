#include "Scheduler.h"
#include <fstream>

Scheduler::Scheduler(string fileName){
	ifstream fich;
	string linea;

	fich.open(fileName.c_str());
	if(fich.is_open()){
		getline(fich, linea);
		while(!fich.eof()){
			Hoguera nueva(linea);
			hogueras.push_back(nueva);
			getline(fich, linea);
		}		
		fich.close();
	}
}

void Scheduler::addTeam(string team){
	teams.push_back(team);
}

void Scheduler::distributeTeams(){
	int pos;
	bool todasAsignadas = false;

	while(!todasAsignadas){
		for(int i = 0; i < teams.size() && !todasAsignadas; i++){
			pos = getMinor();
			if(pos != -1){
				hogueras[pos].setTeam(teams[i]);
			}
			else{
				todasAsignadas = true;
			}
		}
	}
}

ostream &operator<<(ostream &os, const Scheduler &s){
	for(int i = 0; i < s.teams.size(); i++){
		os << "[" << s.teams[i] << "]: ";
		for(int j = 0; j < s.hogueras.size(); j++){
			if(s.hogueras[j].getTeam() == s.teams[i]){
				os << s.hogueras[j] << " ";
			}
		}
		os << endl;
	}
	return os;
}

// devuelve la posicion de la hoguera sin equipo asignado
// que tenga un tiempo menor.
int Scheduler::getMinor() const{
	int pos, i;
	pos = -1;
	for(i = 0; i < hogueras.size(); i++){
		if(hogueras[i].getTeam() == ""){
			if(pos == -1){	// el primero que encuentro
				pos = i;
			}
			else{	//resto :)
				if(hogueras[i].getTime() < hogueras[pos].getTime()){
					pos = i;
				}
			}
		}		

	}
	return pos;
}



