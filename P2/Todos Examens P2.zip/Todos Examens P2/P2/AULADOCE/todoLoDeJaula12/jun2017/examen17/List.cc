#include "List.h"
#include <sstream>

List::List(string name){
	this->name = name;
}

bool List::searchMovie(string title) const{
	bool found = false;

	for(int i = 0; i < movies.size() && !found; i++){
		if(movies[i].getTitle() == title){
			found = true;
		}
	}
	return found;
}


void List::addMovie(string desc, Genre genre){
	string newTitle;
	int newScore;
	bool found;
	stringstream ss(desc);
	
	getline(ss, newTitle, ','); // para en la , y la quita del buffer
	ss >> newScore;
	found = searchMovie(newTitle);
	if(!found){
		try{
			Movie nueva(newTitle, genre, newScore);
			movies.push_back(nueva);
		}
		catch(int &e){
			cout << "Wrong movie \"" << newTitle << "\"" << endl; 
		}
	}
}

float List::getMeanScore() const{
	float suma = 0;
	for(int i = 0; i < movies.size(); i++){
		suma += movies[i].getScore();
	}
	if(movies.size() > 0){
		suma = suma / movies.size();
	}
	return suma;
}

ostream &operator<<(ostream &os, const List &list){
	os << list.name << endl;
	os << list.getMeanScore() << endl;
	for(int i = 0; i < list.movies.size(); i++){
		os << list.movies[i] << endl;
	}
	return os;
}










