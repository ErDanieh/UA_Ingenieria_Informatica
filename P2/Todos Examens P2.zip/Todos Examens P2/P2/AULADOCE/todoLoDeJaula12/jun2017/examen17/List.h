#ifndef _LIST_
#define _LIST_
#include "Movie.h"
#include <iostream>
#include <vector>
using namespace std;

class List{
	friend ostream &operator<<(ostream &os, const List &lista);
	private:
		string name;
		vector<Movie> movies;
		bool searchMovie(string title) const;
	public:
		List(string name);
		void addMovie(string desc, Genre genre);
		float getMeanScore() const;
};

#endif
