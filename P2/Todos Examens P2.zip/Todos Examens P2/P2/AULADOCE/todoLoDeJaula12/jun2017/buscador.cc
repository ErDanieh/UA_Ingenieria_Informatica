#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

struct Entrada{
	int id, veces;
};

struct Documento{
	char title[50];
	char url[50];
	int length;
};


// leer el fichero binario documents.bin y lo carga en el vector de documentos
bool cargarBinario(vector<Documento> &docs){
	ifstream fich;
	bool fich_leido = false;
	Documento leido;

	fich.open("documents.bin", ios::binary);
	if(fich.is_open()){
		fich_leido = true;
		fich.read((char *) &leido, sizeof(leido));
		while(!fich.eof()){
			docs.push_back(leido);
			fich.read((char *) &leido, sizeof(leido));
		}
		fich.close();
	}
	return fich_leido;
}

// "0:3|3:5|4:2|12:32|3:34"
void procesarLinea(vector<Entrada> &entradas, string resto){
	int i;
	string cad_id, cad_veces;
	i = 0;
	while(i < resto.length()){
		cad_id = "";
		while(resto[i] != ':'){
			cad_id += resto[i++];
		}
		i++;
		cad_veces = "";
		while(i < resto.length() && resto[i] != '|'){
			cad_veces += resto[i++];
		}
		i++;
		Entrada nueva = {atoi(cad_id.c_str()),
				atoi(cad_veces.c_str())};
		entradas.push_back(nueva);		
	}

}

// lee el fichero de texto y si encuentra la palabra devuelve las entradas
// de dicha palabra
bool leePalabra(vector<Entrada> &entradas, string buscada){
	ifstream fich;
	bool leido_fich = false, encontrada;
	string palabra;
	string resto;

	fich.open("index.txt");
	if(fich.is_open()){
		leido_fich = true;
		encontrada = false;
		getline(fich, palabra, '|');
		while(!fich.eof() && !encontrada){
			getline(fich, resto);			
			if(palabra == buscada){
				encontrada = true;
				procesarLinea(entradas, resto);
			}
			else{
				getline(fich, palabra, '|');
			}
		}	
		fich.close();
	}

	return leido_fich;
}


// "0:3|3:5|4:2|12:32|3:34"
void buscarFrecuencia(string palabra){
	vector<Entrada> entradas;
	vector<Documento> docs;
	double frec, mayor_frec;
	int pos_mayor;
	int posicionDocumento;

	if(cargarBinario(docs)){
		if(leePalabra(entradas, palabra)){
			// buscar la mayor frecuencia.
			for(int i = 0; i < entradas.size(); i++){
				posicionDocumento = entradas[i].id;				
				frec = (double) entradas[i].veces / docs[posicionDocumento].length;
				if(i == 0 || frec > mayor_frec){
					mayor_frec = frec;
					pos_mayor = i;
				}
			}
			cout << docs[pos_mayor].title << " (";
			cout << docs[pos_mayor].url << ") [";
			cout << mayor_frec << "]\n";
		}
	}
}

int main(int argc, char * argv[]){
	if(argc == 2){
		buscarFrecuencia(argv[1]);
	}
	
}





