#ifndef _BIBLIOTECA_
#define _BIBLIOTECA_
#include "Libro.h"
#include <vector>
#include <iostream>
using namespace std;

class Biblioteca{
	friend ostream &operator<<(ostream &os, const Biblioteca &b);
	private:
		string nombre;
		vector<Libro> libros;
		int buscar(const Libro &libro) const;	
	public:
		Biblioteca(string nombre);
		void anyadir(const Libro &libro);
		bool prestar(const Libro &libro);
};


#endif
