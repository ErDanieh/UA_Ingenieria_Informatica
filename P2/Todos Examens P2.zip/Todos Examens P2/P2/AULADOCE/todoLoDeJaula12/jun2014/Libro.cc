#include "Libro.h"

Libro::Libro(string titulo, string autor, int numEjemplares){
	this->titulo = titulo;
	this->autor = autor;
	this->numEjemplares = numEjemplares;
	numPrestados = 0;
}

bool Libro::prestar(){
	bool prestado = false;
	if(numPrestados < numEjemplares){
		prestado = true;
		numPrestados++;
	}
	return prestado;
}

bool Libro::devolver(){
	bool devuelto = false;
	if(numPrestados > 0){
		devuelto = true;
		numPrestados--;
	}
	return devuelto;
}

int Libro::getNumEjemplares() const{
	return numEjemplares;
}

int Libro::getNumDisponibles() const{
	return numEjemplares - numPrestados;
}

void Libro::anyadirEjemplares(int numEjemplaresNuevos){
	numEjemplares += numEjemplaresNuevos;
}

bool Libro::isEqualTo(const Libro &libro) const{
	bool iguales = false;
	if(titulo == libro.titulo && autor == libro.autor){
		iguales = true;
	}
	return iguales;
}

ostream &operator<<(ostream &os, const Libro &libro){
	os << libro.getNumDisponibles() << ": ";
	os << " " << libro.titulo << " (" << libro.autor << ")";
	return os;
}





