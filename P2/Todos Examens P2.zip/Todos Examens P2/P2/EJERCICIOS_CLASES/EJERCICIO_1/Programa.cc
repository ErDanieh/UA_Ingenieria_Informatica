
#include <iostream>
#include "Coordenadas.h"

using namespace std;

int main()
{
  Coordenada c1(2,3);
  cout << c1 << endl;
  c1.setX(12);
  cout << c1 << endl;
  c1.setY(12);
  cout << c1 << endl;

  Coordenada c2(c1);
  Coordenada c3=c1;
  Coordenada c4(1);
  cout << c4 << endl;


  return 0;
}