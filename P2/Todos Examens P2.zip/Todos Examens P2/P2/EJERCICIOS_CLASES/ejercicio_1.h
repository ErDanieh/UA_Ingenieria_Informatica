
class Coordenada
{
    private:
        float x, y;
    public:
        Coordenada(float cx = 0, float xy = 0);
        Coordenada(const Coordenada &);
        ~Coordenada();
};