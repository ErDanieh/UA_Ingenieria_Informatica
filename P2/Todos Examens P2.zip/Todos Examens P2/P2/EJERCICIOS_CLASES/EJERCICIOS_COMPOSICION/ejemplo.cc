#include <iostream>
#include "A.h"
using namespace std;



int main(){
    B *b=new b;
    A a(b);

    return 0;
}