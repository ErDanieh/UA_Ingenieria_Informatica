#include <iostream>
using namespace std;


class A
{
    private:
        B *b;
    public:
        A(B *b){
            this->b=b;
        }
        ~A();
};

