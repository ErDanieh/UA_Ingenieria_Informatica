#include <string>
#include <iostream>

using namespace std;

class Rect
{
  private:
    int x1, y1, x2, y2;
  public:
    Rect(int ax, int ay, int bx, int by);
    ~Rect();
    int base();
    int altura();
    int area();
};