#include <iostream>
#include <math.h>
using namespace std;


int root(int n){
    if(n<0)
        throw exception();
    return sqrt(n);
}

int main(){

    try
    {
        int resul=root(-1);
        cout<<resul<<endl; 
    }
    catch(const exception& e)
    {
        cout << "Negative number"<< endl;
    }
    

    return 0;
}