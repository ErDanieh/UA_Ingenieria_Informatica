#include <iostream>
#include "Factura.h"
#include "Linea.h"
#include "Cliente.h"

using namespace std;

int main()
{
  string nomb = "Ander";
  string dirrec = "C/Pablo Iglesias Nº5";
  string telf = "685035250";
  string fech = "24/07/1999";

  Cliente *client1 = new Cliente(nomb, dirrec, telf);

  Factura fact1(client1, fech);

  fact1.anyadirLinea(2, "Botella de Agua.", 1.22);
  cout << fact1;
  fact1.anyadirLinea(2, "Botella de Agua.", 1.22);
  cout << fact1;
  

  cout << client1->getNombre() << ' ' << client1->getDireccion() 
      << ' ' << client1->getTelefono();

  delete client1;

  return 0;
}