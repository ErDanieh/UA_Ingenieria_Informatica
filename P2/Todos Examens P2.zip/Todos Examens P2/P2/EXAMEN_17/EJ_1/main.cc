#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <fstream>

using namespace std;

struct Documento
{
  char titulo[50];
  char url[50];
  int longitud;
};


void cargarFichero(string filename);
void buscarPalabra(string palabraBuscar, int &indicePalbra, int &indice, int &numRepeteciones);
void devolverInformacion(int indicePalbra, int indice, int numRepeticiones);

int main(int args, char* argv[]){

  string palabraBuscar;
  int indice = 0;
  int numRepeticiones = 0;
  int indicePalbra = -1;

  if(args != 2){
    cout << "Error arguments. " << endl;
  }

  else
  {
    palabraBuscar = argv[1];

    try
    {
     buscarPalabra(palabraBuscar, indicePalbra, indice, numRepeticiones);

     if(indicePalbra == -1){
       cout << "La palabra no existe." << endl;
     }
     else{
       devolverInformacion(indicePalbra, indice, numRepeticiones);
     }
    }
    catch(const std::exception& e)
    {
      cout << "El fichero no existe." << endl;
    }
  }

  return 0;
}

void devolverInformacion(int indicePalbra,int indice,int numRepeticiones){

  Documento documento;

  ifstream ficheroDocuments("documents.bin",ios::binary);

  if(ficheroDocuments.is_open()){

    ficheroDocuments.seekg((indicePalbra)*sizeof(Documento));
    ficheroDocuments.read( (char *)&documento, sizeof(Documento) );
    cout << documento.titulo << " (" << documento.url << ") [" << (float) numRepeticiones / documento.longitud << "]" << endl;
    
  }
  else
  {
    cout << "Error file. File not oppened." << endl;
  }
  

}

void buscarPalabra(string palabraBuscar, int &indicePalbra,int &indice,int &numRepeticiones){
  
  bool existe = false;
  string linea;
  string palabraLeida;
  int indiceActual = -1;
  int indiceLeido = 0;
  int maximoActual = 0;
  int maximoLeido = 0;
  string valorLeido;

  ifstream ficheroIndex("index.txt");

  if(!ficheroIndex.is_open()){
    throw exception();
  }

  
  while (getline(ficheroIndex,linea) && !ficheroIndex.eof())
  {
    stringstream li(linea);
    getline(li,palabraLeida,'|');
    if(existe == false){
      indicePalbra++;
    }
    if(palabraLeida == palabraBuscar){
      while (!li.eof()){
        getline(li,valorLeido,':');
        indiceLeido = stoi(valorLeido);
        getline(li,valorLeido,'|');
        maximoLeido = stoi(valorLeido);

        if(maximoLeido>maximoActual){
          maximoActual = maximoLeido;
          indiceActual = indiceLeido;
          existe = true;
        }
      }
    }
  }

  if(existe == false){
    indicePalbra = -1;
  }
  
  else{
    indice = indiceActual;
    numRepeticiones = maximoActual;
  }
}

