#include "List.h"


const bool List::searchMovie(string title){
  bool existePelicula = false;

  for(unsigned i=0; i<movies.size() && existePelicula == false; i++){
    if(movies[i].getTitle() == title){
      existePelicula = true;
    }
  }

  return existePelicula;
}


List::List(string name){
  this->name=name;
} 

void List::addMovie(string desc, Genre genre){
  string newTitle;
  int newScore;
  unsigned pos;
  char comilla = '"';
  stringstream ss(desc);
  getline(ss,newTitle,',');
  
  ss >> newScore;


  if(searchMovie(newTitle)==false){
    try
    {
      Movie movie(newTitle,genre,newScore);
      movies.push_back(movie);
    }
    catch(const std::exception& e)
    {
      cout << "Wrong movie name " << comilla << newTitle << comilla << endl;
    }
  }
}


float List::getMeanScore() const{
  float sumatorioPuntuaciones = 0;

  for (unsigned i=0; i < movies.size(); i++){
    sumatorioPuntuaciones = sumatorioPuntuaciones + movies[i].getScores();
  }

  return sumatorioPuntuaciones / movies.size();
}

ostream &operator<<(ostream &os, const List &l){
  os << l.name << endl;
  os << l.getMeanScore() << endl;

  for (unsigned i = 0; i < l.movies.size(); i++){
    os << l.movies[i];
  }
  return os;
}

 