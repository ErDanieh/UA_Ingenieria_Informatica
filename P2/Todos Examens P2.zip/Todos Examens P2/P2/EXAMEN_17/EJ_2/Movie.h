#ifndef _MOVIE_H_
#define _MOVIE_H_


#include <vector>
#include <iostream>
#include <string>
#include <sstream>

using namespace std;

enum Genre{Action, SciFi, Drama, Comedy};


class Movie
{
  friend ostream &operator<<(ostream &os, const Movie &m);
  private:
    string title;
    int score;
    Genre genre;
  public:
    static const int NS;
    Movie(string title, Genre genre, int score=NS);
    string getTitle() const{ return title; };
    int getScores() const { return score; };
    static string genreToString(Genre genre);
    Genre getGenre() const { return genre; };

};

#endif