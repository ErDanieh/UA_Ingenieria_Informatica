#include "Biblioteca.h"

int Biblioteca::buscar(const Libro &libro) const{
	int i, pos;
	pos = -1;
	for(i = 0; i < libros.size() && pos == -1; i++){
		if(libros[i].isEqualTo(libro)){
			pos = i;
		}
	}
	return pos;
}


Biblioteca::Biblioteca(string nombre){
	this->nombre = nombre;
}

void Biblioteca::anyadir(const Libro &libro){
	int i, pos;

	pos = buscar(libro);
	if(pos == -1){
		libros.push_back(libro);
	}
	else{
		// esto es una mierda!!!
		// libros[pos].getNumEjemplares()++;
		libros[pos].anyadirEjemplares(libro.getNumEjemplares());	
	}
}

bool Biblioteca::prestar(const Libro &libro){
	int pos;
	bool prestado = false;
	pos = buscar(libro);
	if(pos != -1){
		prestado = libros[pos].prestar();
	}
	return prestado;
}

ostream &operator<<(ostream &os, const Biblioteca &b){
	os << b.nombre << endl;
	os << "-------" << endl;
	os << "libros disponibles: " << endl;
	for(int i = 0; i < b.libros.size(); i++){
		if(b.libros[i].getNumDisponibles() != 0){
			os << b.libros[i] << endl;
		}
	}
	return os;
}







