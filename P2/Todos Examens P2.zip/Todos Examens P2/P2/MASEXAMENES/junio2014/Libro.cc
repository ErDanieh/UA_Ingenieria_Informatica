#include "Libro.h"


Libro::Libro(string titulo, string autor, int numEjemplares){
	this->titulo = titulo;
	this->autor = autor;
	this->numEjemplares = numEjemplares;
	numPrestados = 0; // inicialmente no hay prestados.
}

bool Libro::prestar(){
	bool prestado = false;
	if(numPrestados < numEjemplares){
		prestado = true;
		numPrestados++;
	}
	return prestado;
}

bool Libro::devolver(){
	bool devolvido = false;
	if(numPrestados > 0){
		devolvido = true;
		numPrestados--;
	}
	return devolvido;
}

int Libro::getNumDisponibles() const{
	return numEjemplares - numPrestados;
}

void Libro::anyadirEjemplares(int numEjemplaresNuevos){
	numEjemplares += numEjemplaresNuevos;
}

int Libro::getNumEjemplares() const{
	return numEjemplares;
}

bool Libro::isEqualTo(const Libro &libro) const{
	return autor == libro.autor && titulo == libro.titulo;
}

// 3: La tapadera ( John Grisham )
ostream &operator<<(ostream &os, const Libro &libro){
	os << libro.getNumDisponibles() << ": ";
	os << libro.titulo << " ( ";
	os << libro.autor << " )";
	return os;	
}


