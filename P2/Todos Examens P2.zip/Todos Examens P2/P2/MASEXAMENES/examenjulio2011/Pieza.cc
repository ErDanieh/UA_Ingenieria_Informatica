#include "Pieza.h"

Pieza::Pieza(Tipo tipo, Color color){
	this->tipo = tipo;
	this->color = color;
}

Tipo Pieza::getTipo() const{
	return tipo;
}

Color Pieza::getColor() const{
	return color;
}

string Pieza::colorDe(Color color){
	string piezas[] = {"PEON", "TORRE", "CABALLO", "ALFIL", "REY", "DAMA"};
	return piezas[color];	
}

string Pieza::tipoDe(Color color){
	string colores[] = {"BLANCO", "NEGRO"};
	return colores[color];
}

ostream &operator<<(ostream &os, const Pieza &pieza){
	os << Pieza::tipoDe(pieza.tipo) << " - " << Pieza::colorDe(pieza.color);
	return os;
}

