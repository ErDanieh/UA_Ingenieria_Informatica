#include <iostream>
#include <fstream>
#include <cctype>
#include <vector>
#include <algorithm>
using namespace std;


// inserto la palabra si no esta en el vector.
void insertarPalabra(vector<string> &palabras, string palabra){
	if(find(palabras.begin(), palabras.end(), palabra) == palabras.end()){
		palabras.push_back(palabra);
	}
}

// mostrar la cantidad de palabras distintas que hay en cada linea.
void procesarLinea(string linea){
	vector<string> palabras;
	int i;
	string palabra;

	i = 0;
	while(i < linea.length()){
		// busca el comienzo de la palabra
		while(i < linea.length() && isalpha(linea[i]) == 0){
			i++;
		}
		// buscar el fin de la palabra
		palabra = "";
		while(i < linea.length() && isalpha(linea[i]) != 0){
			palabra += linea[i];
			i++;
		}
		if(palabra != ""){
			insertarPalabra(palabras, palabra);
		}
	}
	cout << palabras.size() << " " << linea << endl;
}




/*
/// "234  234 !!!!++hola   23423hola"
void procesarLinea(string linea){
	vector<string> palabras;
	int i;
	string palabra;

	i = 0;
	while(i < linea.length()){
		// busca el comienzo de la palabra
		while(i < linea.length() && isalpha(linea[i]) == 0){
			i++;
		}
		// buscar el fin de la palabra
		palabra = "";
		while(i < linea.length() && isalpha(linea[i]) != 0){
			palabra += linea[i];
			i++;
		}
		if(palabra != ""){
			palabras.push_back(palabra);
		}
	}
	cout << palabras.size() << " " << linea << endl;
}
*/

// mostrar la cantidad de palabras que hay en cada linea.
void leerFichero(const char filename[]){
	ifstream fich;
	string linea;

	fich.open(filename);
	if(!fich.is_open()){
		cout << "Cant open file " << filename << endl;
	}
	else{
		getline(fich, linea);
		while(!fich.eof()){
			procesarLinea(linea);
			getline(fich, linea);
		}
		fich.close();
	}
}





/*
// funcion que muestra el ficheor linea a linea.
void leerFichero(const char filename[]){
	ifstream fich;
	string linea;

	fich.open(filename);
	if(!fich.is_open()){
		cout << "Cant open file " << filename << endl;
	}
	else{
		getline(fich, linea);
		while(!fich.eof()){
			cout << linea << endl;
			getline(fich, linea);
		}
		fich.close();
	}
}
*/


int main(int argc, char *argv[]){
	if(argc == 2){
		// argv[0] es el nombre del programa
		leerFichero(argv[1]);
	}
	else{
		cout << "Ussage: ./main nombreFichero" << endl;
	}
}
