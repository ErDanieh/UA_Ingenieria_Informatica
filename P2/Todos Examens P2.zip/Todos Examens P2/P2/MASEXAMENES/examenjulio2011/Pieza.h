#ifndef _PIEZA_
#define _PIEZA_
#include <iostream>
using namespace std;

enum Color{BLANCO, NEGRO};
enum Tipo{PEON, TORRE, CABALLO, ALFIL, REY, DAMA};

class Pieza{
	friend ostream &operator<<(ostream &os, const Pieza &pieza);
	private:
		Tipo tipo;
		Color color;
		static string colorDe(Color color);
		static string tipoDe(Tipo tipo);
	public:
		Pieza(char tipo = PEON, bool color = BLANCO);
		Tipo getTipo() const;
		Color getColor() const;
		
};

#endif
