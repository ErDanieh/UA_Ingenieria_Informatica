#include <iostream>
#include <fstream>
#include "Station.h"
#include "Region.h"
using namespace std;

int main(){
	Region r("Comunitat Valenciana");

	r.addStation("Alicante.txt");
	r.addStation("Valencia.txt");

	cout << r.getValue("Alicante", Tm, Sep) << endl;
	
	cout << r.getAvgTemp(Oct) << endl;

	cout << r.getWarmestStation(Aug) << endl;

	return 0;
}
