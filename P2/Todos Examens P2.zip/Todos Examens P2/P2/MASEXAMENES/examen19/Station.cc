#include "Station.h"
#include <fstream>

unsigned int Station::nextId = 1;

Station::Station(string filename){
	ifstream fich;	
	string ignored;

	fich.open(filename.c_str());
	if(!fich.is_open()){
		throw 1;
	}
	getline(fich, this->name);
	for(int i = 0; i < 12; i++){
		fich >> ignored >> data[0][i] >> data[1][i] >> data[2][i];
	}
	fich.close();
	id = nextId;
	nextId++;	
}

float Station::getValue(Value v, Month m) const{
	return data[v][m];
}

string Station::getName() const{
	return name;
}

ostream &operator<<(ostream &os, const Station &station){
	os << station.name << " (" << station.id << ")";
	return os;
}
