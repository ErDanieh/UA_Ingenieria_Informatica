#include "Region.h"


int Region::findStation(string name) const{
	int i, pos;
	pos = -1;
	for(i = 0; i < stations.size() && pos == -1; i++){
		if(stations[i].getName() == name){
			pos = i;
		}
	}
	return pos;
}

Region::Region(string name){
	this->name = name;
}

bool Region::addStation(string filename){
	bool added = false;
	int pos;
	try{
		Station nueva(filename);
		pos = findStation(nueva.getName());
		if(pos == -1){
			stations.push_back(nueva);
		}
		else{
			stations[pos] = nueva;
		}
		added = true;
	}
	catch(int &e){
		cout << "Error opening file" << endl;
	}
	return added;
}

float Region::getValue(string name, Value v, Month m) const{
	float value;
	int pos;
	pos = findStation(name);
	if(pos == -1){
		cout << "Wrong station name" << endl;
		value = -1;
	}
	else{
		// llamo al getValue de la Station encontrada
		value = stations[pos].getValue(v, m);
	}
	return value;
}

// la media de las medias de un mes
float Region::getAvgTemp(Month m) const{
	float avg;
	avg = 0;
	for(int i = 0; i < stations.size(); i++){
		// T == 0
		avg += stations[i].getValue(T, m);
	}
	if(stations.size() != 0){
		avg = avg / stations.size();
	}
	return avg;
}

// la maxima de las maximas de un mes.
string Region::getWarmestStation(Month m) const{
	string warmestName = "";
	int posMax;
	if(stations.size() > 0){
		posMax = 0;
		for(int i = 1; i < stations.size(); i++){
			if(stations[i].getValue(TM, m) > stations[posMax].getValue(TM, m)){
				posMax = i;
			}
		}
		warmestName = stations[posMax].getName();
	}	
	return warmestName;
}








