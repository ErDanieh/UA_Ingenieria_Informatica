#ifndef _STATION_
#define _STATION_
#include <iostream>
using namespace std;
//          0  1   2
enum Value {T, TM, Tm};

//           0    1    2    3    4    5    6    7    8    9   10   11
enum Month {Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec};

/*		i
		Jan	Feb	Mar		Dec
		0	1	2	...	11
		------------------------------------
T	0	11.7	12.3	14.2		12.6
TM	1	17	17.6	19.6		17.7
Tm	2	6.3	7.1	8.9		7.4

*/
class Station{
	friend ostream &operator<<(ostream &os, const Station &station);
	private:
		string name;
		static unsigned int nextId;
		unsigned int id;
		float data[3][12];
	public:
		Station(string filename);
		float getValue(Value v, Month m) const;
		string getName() const;
};
#endif
