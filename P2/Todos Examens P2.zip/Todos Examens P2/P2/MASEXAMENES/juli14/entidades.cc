#include <fstream>
#include <iostream>
using namespace std;


struct Entidades{
	vector<string> fechas;
	vector<string> personas;
	vector<string> empresas;
	vector<string> lugares;
};

bool esComienzo(char c){
	return c == '@' || c == '$' || c == '*' || c == '#';
}

void extraerInfo(string linea, Entidades &entidades){
	int i;
	char comienzo;
	string info;
	i = 0;
	while(i < linea.length()){
		while(i < linea.length() && esComienzo(linea[i]) == false){
			i++;
		}
		if(i < linea.length()){
			comienzo = linea[i];
			i++;
			info = "";
			while(i < linea.length() && linea[i] != comienzo){
				info = info + linea[i];
				i++;
			}
			switch(comienzo){

			}
		}
	}
}


void leerFichero(string nombreFichero, Entidades &entidades){
	string linea;
	ifstream fich;
	fich.open(nombreFichero.c_str());
	if(fich.is_open()){
		getline(fich, linea);
		while(!fich.eof()){
			extraerInfo(linea, entidades);
			getline(fich, linea);
		}
		fich.close();
	}
}


/*
void leerFichero(string nombreFichero, Entidades &entidades){
	char carInicio, carLeido;
	string entrada;

	fich.open(nombreFichero.c_str());
	if(fich.is_open()){
		carLeido = fich.get();
		while(!fich.eof()){
			// buscamos el comienzo de una entidad
			while(!fich.eof() && carLeido != '*' && carLeido != '$' && carLeido != '#' && carLeido != '@'){
				carLeido = fich.get();
			}
			carInicio = carLeido;
			carLeido = fich.get();
			entrada = "";
			while(!fich.eof() && carLeido != carInicio){
				entrada += carLeido;
			}
			switch(carInicio){
				case '@':
					entidades.fechas.push_back(entrada);
					break;
				case '#':
					entidades.personas.push_back(entrada);
			}
			carLeido = fich.get();
		}
	}
}
*/
		fich.close();
	}
}
