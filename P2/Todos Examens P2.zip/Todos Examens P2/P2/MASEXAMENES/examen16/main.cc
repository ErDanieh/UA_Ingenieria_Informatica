#include "Squadron.h"
#include <iostream>
using namespace std;


int main(){
	Squadron sa12( "troops12.txt","sqa12");
	Squadron sua("troopsua.txt","shitua");

	cout << sa12 << endl;
	cout << sua << endl;

	sa12.fight(sua);

	cout << sa12 << endl;
	cout << sua << endl;

	return 0;
}
