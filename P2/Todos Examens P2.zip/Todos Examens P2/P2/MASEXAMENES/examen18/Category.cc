#include <iostream>
#include "Category.h"
using namespace std;

Category::Category(string description, int percentage){
	this->description = description;
	this->percentage = percentage;
	// los vectores STL se inicializan solos a vacio.
}

void Category::addForbiddenNick(string nick){
	forbiddenNicks.push_back(nick);
}

void Category::addYoutuber(string nick, string url){
	bool encontrado;	
	try{
		Youtuber y(nick, url);	// lanza excepciones
		// si se crea bien
		// comprobamos si el nuevo nick contiene alguno de los no
		// permitidos.
		encontrado = false;
		for(int i = 0; i < forbiddenNicks.size() && !encontrado; i++){
			if(nick.find(forbiddenNicks[i]) != string::npos){
				encontrado = true;
			}
		}
		if(encontrado){
			cout << "ERROR: FORBIDDEN NICK " << nick << endl;
		}
		else{
			youtubers.push_back(y);
		}
	}
	catch(int &e){
		if(e == 1){
			cout << "ERROR: DATA MISSING" << endl;
		}
		else{
			cout << "ERROR: WRONG URL " << url << endl;
		}
	}
}

void Category::penalize(string nick){
	// buscar el youtuber con ese nick
	int pos, i;
	pos = -1;
	for(i = 0; i < youtubers.size() && pos == -1; i++){
		if(youtubers[i].getNick() == nick){
			pos = i;
		}
	}
	if(pos != -1){
		// si es la segunda vez que penalizo
		if(youtubers[i].isPenalized()){
			cout << nick << " REMOVED" << endl;
			youtubers.erase(youtubers.begin() + pos);
			addForbiddenNick(nick);
		}
		else{
			youtubers[i].setPenalized(true);
		}
	}
}

void Category::shareProfits(float profits){
	float aRepartir, parte;
	if(youtubers.size() > 0){
		aRepartir = profits * percentage / 100.0;	
		parte = profits / youtubers.size();
		for(int i = 0; i < youtubers.size(); i++){
			youtubers[i].addProfits(parte);
			// this = &youtubers[i];
			// this->profits += parte;
		}
	}	
}

ostream &operator<<(ostream &os, const Category &cat){
	int i;

	os << "---- Category: " << cat.description << "----" << endl;
	for(i = 0; i < cat.youtubers.size(); i++){
		os << cat.youtubers[i] << endl;
	}	
	return os;
}





