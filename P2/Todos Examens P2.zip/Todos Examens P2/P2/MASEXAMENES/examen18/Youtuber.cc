#include "Youtuber.h"

ostream &operator<<(ostream &os, const Youtuber &y){
	os << y.nick << ", url=" << y.url << ", profits=" << y.profits;
	return os;
}

Youtuber::Youtuber(string nick, string url){
	if(nick == ""){
		throw 1; // lanzamos un 1.
	}
	if(url.find("http://www.youtube.com/channel/") != 0){
		throw 2; // lanzamos un 2.
	}
	this->nick = nick;
	this->url = url;
	penalized = false;
	profits = 0;
}

string Youtuber::getNick() const{
	return nick;
}

string Youtuber::getUrl() const{
	return url;
}

bool Youtuber::isPenalized() const{
	return penalized;
}

void Youtuber::setPenalized(bool penalized){
	this->penalized = penalized;
}

void Youtuber::addProfits(float profits){
	this->profits += profits;
}


