#include "Shelter.h"

const unsigned Shelter::MAXADOPTED = 3;

bool Shelter::ownerIsValid(string owner) const{
	// contar la cantidad de animalicos con el dueño owner.
	int i, cuantos;
	bool isvalid;

	cuantos = 0;
	for(i = 0; i < animals.size(); i++){
		if(animals[i].getOwner() == owner){
			cuantos++;
		}
	}
	if(cuantos < MAXADOPTED){
		isvalid = true;
	}
	else{
		isvalid = false;
	}

	return isvalid;		
}

int Shelter::search(const Animal &a) const{
	int i, pos;

	pos = -1;
	for(i = 0; i < animals.size() && pos == -1; i++){
		if(animals[i].getName() == a.getName() && animals[i].getAnimalType() == a.getAnimalType()){
			pos =  i;
		}
	}
	return pos;
}

Shelter::Shelter(string name){
	this->name = name;
}

bool Shelter::add(const Animal &a){
	bool added = false;
	int pos;
	pos = search(a);
	if(pos == -1){
		animals.push_back(a);
		added = true;
	}
	return added;
}

bool Shelter::adopt(const Animal &a, string owner){
	bool adopted, isvalid;
	int pos;

	pos = search(a); // buscamos el animal
	isvalid = ownerIsValid(owner); // miro si aun puede adoptar.
	if(pos != -1 && isvalid && !animals[pos].isAdopted()){
		adopted = true;
		animals[pos].adopt(owner);
	}
	else{
		cout << a.getName() << " can not be adopted" << endl;
		adopted = false;
	}	

	return adopted;
}

ostream &operator<<(ostream &os, const Shelter &shelter){
	os << "--- Adopted ---" << endl;
	for(int i = 0; i < shelter.animals.size(); i++){
		if(shelter.animals[i].isAdopted()){
			os << shelter.animals[i] << endl;
		}
	}
	os << "--- Not adpoted ---" << endl;
	for(int i = 0; i < shelter.animals.size(); i++){
		if(!shelter.animals[i].isAdopted()){
			os << shelter.animals[i] << endl;
		}
	}
	return os;
}






