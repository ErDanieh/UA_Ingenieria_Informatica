#ifndef _ANIMAL_
#define _ANIMAL_
#include <iostream>
using namespace std;

enum AnimalType{Cat, Dog, Verga};

class Animal{
	friend ostream &operator<<(ostream &os, const Animal &a);
	private:
		string name;
		unsigned age;
		AnimalType type;
		string owner;
		// enum => string
		static string stringOf(AnimalType type);
		// string => enum		
		static AnimalType typeOf(string cadena);
	public:
		Animal(string s);
		string getName() const;
		unsigned getAge() const;
		AnimalType getAnimalType() const;
		string getOwner() const;
		void adopt(string owner);
		bool isAdopted() const;
};

#endif
