#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

struct Entrada{
	int doc;
	int veces;
};

struct Documento{
	char title[50];
	char url[50];
	int length;
};

// 0:3|3:5|4:2
void procesarLinea(vector<Entrada> &entradas, string resto){
	string cad_id, cad_pal;	
	int i;
	i = 0;
	while(i < resto.length()){
		cad_id = "";
		while(resto[i] != ':'){
			cad_id += resto[i++];
		}
		i++; // para saltarme los :
		cad_pal = "";
		while(i < resto.length() && resto[i] != '|'){
			cad_pal += resto[i++];
		}
		i++; // me la salto aunque no este
		Entrada nueva = {atoi(cad_id.c_str()), 
				atoi(cad_pal.c_str())};
		entradas.push_back(nueva);
	}
}

bool leerPalabra(vector<Entrada> &entradas, string buscada){
	// buscar la linea que empiece por la palabra que me pasaron 
	ifstream fich;
	bool leido = false;
	bool encontrada = false;
	string leida, resto;	


	fich.open("index.txt");
	if(fich.is_open()){
		leido = true;
		getline(fich, leida, '|');
		while(!fich.eof() && !encontrada){
			getline(fich, resto);
			if(buscada == leida){
				encontrada = true;
				procesarLinea(entradas, resto);
			}
			else{
				getline(fich, leida, '|');
			}
		}
		fich.close();
	}	
	return leido;
}


void buscarFrecuencia(string palabra){
	double mayorFrec, frec;
	int posdoc, total, p;
	ifstream fichIndex, fichDocs;
	Documento documentoSel;	
	string cad_doc, cad_veces, linea, palabra_leida, resto;	
	int i, veces;
	bool encontrado;

	fichIndex.open("index.txt");
	if(fichIndex.is_open()){
		encontrado = false;
		getline(fichIndex, palabra_leida, '|');
		while(!fichIndex.eof() && !encontrado){
			getline(fichIndex, resto);
			if(palabra_leida == palabra){
				encontrado = true;
			}
			else{
				getline(fichIndex, palabra_leida, '|');
			}
		}
		fichIndex.close();
		if(encontrado){
			fichDocs.open("documents.bin", ios::binary);
			if(fichDocs.is_open()){
				i = 0;
				mayorFrec = 0;
				while(i < resto.length()){
					cad_doc = "";
					while(resto[i] != ':'){
						cad_doc += resto[i++];
					}
					i++; // para saltarme los :
					cad_veces = "";
					while(i < resto.length() && resto[i] != '|'){
						cad_veces += resto[i++];
					}
					i++; // me la salto aunque no este
					p = atoi(cad_doc.c_str());
					veces = atoi(cad_veces.c_str());	
					fichDocs.seekg(p * sizeof(Documento));
					fichDocs.read(( char *) &documentoSel, sizeof(documentoSel));
					total = documentoSel.length;			
					frec =  (float) veces / total;
					if(frec > mayorFrec){
						mayorFrec = frec;
						posdoc = p;
					}
				}
				fichDocs.seekg(posdoc * sizeof(Documento));
				fichDocs.read(( char *) &documentoSel, sizeof(documentoSel));

				cout << documentoSel.title;
				cout << "(" << documentoSel.url << ") [";
				cout << mayorFrec << "]\n";
				fichDocs.close();
			}
		}
	}

}



int main(int argc, char *argv[]){
	if(argc != 2){
		cout << "Error en los argumetnos" << endl;
	}
	else{
		buscarFrecuencia(argv[1]);
	}
}







