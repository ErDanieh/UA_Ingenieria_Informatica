#ifndef _MOVIE_
#define _MOVIE_
#include <iostream>
using namespace std;

enum Genre{Action = 1, SciFi, Drama, Comedy};

class Movie{
	friend ostream &operator<<(ostream &os, const Movie &movie);
	private:
		string title;
		int score;
		Genre genre;
	public:
		static const int NS;
		Movie(string title, Genre genre, int score = NS);
		string getTitle() const;
		int getScore() const;
		Genre getGenre() const;
		static string genreToString(Genre genre);
};

#endif
