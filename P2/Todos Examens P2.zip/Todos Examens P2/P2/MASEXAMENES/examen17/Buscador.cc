#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

struct Entrada{
	int doc;
	int veces;
};

struct Documento{
	char title[50];
	char url[50];
	int length;
};

bool leerDocumentos(vector<Documento> &docs){
	bool leidos = false;
	ifstream fich;
	Documento leido;

	fich.open("documents.bin", ios::binary);
	if(fich.is_open()){
		leidos = true;
		fich.read((char *) &leido, sizeof(leido));
		while(!fich.eof()){
			docs.push_back(leido);
			fich.read((char *) &leido, sizeof(leido));
		}
		fich.close();
	}
	return leidos;
}

// 0:3|3:5|4:2
void procesarLinea(vector<Entrada> &entradas, string resto){
	string cad_id, cad_pal;	
	int i;
	i = 0;
	while(i < resto.length()){
		cad_id = "";
		while(resto[i] != ':'){
			cad_id += resto[i++];
		}
		i++; // para saltarme los :
		cad_pal = "";
		while(i < resto.length() && resto[i] != '|'){
			cad_pal += resto[i++];
		}
		i++; // me la salto aunque no este
		Entrada nueva = {atoi(cad_id.c_str()), 
				atoi(cad_pal.c_str())};
		entradas.push_back(nueva);
	}
}

bool leerPalabra(vector<Entrada> &entradas, string buscada){
	// buscar la linea que empiece por la palabra que me pasaron 
	ifstream fich;
	bool leido = false;
	bool encontrada = false;
	string leida, resto;	


	fich.open("index.txt");
	if(fich.is_open()){
		leido = true;
		getline(fich, leida, '|');
		while(!fich.eof() && !encontrada){
			getline(fich, resto);
			if(buscada == leida){
				encontrada = true;
				procesarLinea(entradas, resto);
			}
			else{
				getline(fich, leida, '|');
			}
		}
		fich.close();
	}	
	return leido;
}


void buscarFrecuencia(string palabra){
	vector<Entrada> entradas;
	vector<Documento> documentos;
	double mayorFrec, frec;
	int posdoc, total;

	if(leerPalabra(entradas, palabra)){
		if(leerDocumentos(documentos)){
			// tenemos que recorrer las entradas y ver
			// cual de las entradas tiene mayor frecuencia.
			for(int i = 0; i < entradas.size(); i++){
				total = documentos[entradas[i].doc].length;			
				frec =  (float) entradas[i].veces / total;
				if(i == 0 || frec > mayorFrec){
					mayorFrec = frec;
					posdoc = i;
				}
			}
			cout << documentos[posdoc].title;
			cout << "(" << documentos[posdoc].url << ") [";
			cout << mayorFrec << "]\n";
		}
	}

}



int main(int argc, char *argv[]){
	if(argc != 2){
		cout << "Error en los argumetnos" << endl;
	}
	else{
		buscarFrecuencia(argv[1]);
	}
}







