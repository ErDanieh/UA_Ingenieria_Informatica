#include <iostream>
#include <fstream>
#include <cctype>
#include <vector>
using namespace std;


struct Pelicula{
	string title;
	string director;
	int year;
};

void leerFichero(const char filename[]){
	ifstream fich;
	vector<Pelicula> peliculas;
	Pelicula nueva;
	int year, pos;
	string linea;
	
	fich.open(filename);
	if(!fich.is_open()){
		cout << "Fichero no encontrado " << filename << endl;	
	}
	else{
		getline(fich, linea);
		while(!fich.eof()){
			pos = linea.find(":");
			nueva.title = linea.substr(pos + 2);
			getline(fich, linea);
			pos = linea.find(":");
			nueva.director = linea.substr(pos + 2);
			getline(fich, linea);
			pos = linea.find(":");
			nueva.year = atoi(linea.substr(pos + 2).c_str());
			peliculas.push_back(nueva);
			
			getline(fich, linea);			
		}
		fich.close();
		for(int i = 0; i < peliculas.size(); i++){
			for(int j = peliculas.size() - 1; j >= i; j--){
				if(peliculas[j].year < peliculas[j-1].year){			
					Pelicula aux = peliculas[j];
					peliculas[j] = peliculas[j-1];
					peliculas[j-1] = aux;
				}
			}
		}
		for(int i = 0; i < peliculas.size(); i++){
			cout << peliculas[i].year << ", ";
			cout << peliculas[i].title << ", " << peliculas[i].director << endl;
		}
	}

}



int main(int argc, char *argv[]){
	if(argc == 2){
		leerFichero(argv[1]);
	}
	else{
		cout << "Error en parametros" << endl;
	}
	return 0;
}
