#include "Cancion.h"

int main(){
	Cancion can("shutup", "josea12", 4);

	cout << can << endl;

	return 0;
}


