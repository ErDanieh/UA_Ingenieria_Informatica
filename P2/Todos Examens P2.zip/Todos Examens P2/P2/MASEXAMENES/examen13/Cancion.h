#ifndef _CANCION_
#define _CANCION_
#include <iostream>
using namespace std;


class Cancion{
	friend ostream &operator<<(ostream &os, const Cancion &cancion);
	private:
		
		string nombre;
		string artista;
		int puntuacion;
	public:
		static const int SP;
		Cancion(string nombre, string artista, int punt = SP);
		string getNombre() const;
		string getArtista() const;
		int getPuntuacion() const;
		void setPuntuacion(int puntuacion);
};

#endif
