#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
using namespace std;

struct Politico{
	string nombre;
	int total, encontrados;
};

bool leerPoliticos(string fichero, vector<Politico> &politicos){
	ifstream fich;
	string linea;
	Politico nuevo;
	bool leido = false;

	fich.open(fichero.c_str());
	if(fich.is_open()){
		leido = true;
		getline(fich, linea);
		while(!fich.eof()){
			nuevo.nombre = linea;
			politicos.push_back(nuevo);
			getline(fich, linea);
		}
		fich.close();
	}
	return leido;
}

bool buscarPalabraLinea(string linea, string clave){
	bool encontrada = false;
	string aux;
	stringstream ss(linea);
	while(ss >> aux && !encontrada){
		if(clave == aux){
			encontrada = true;
		}
	}
	return encontrada;
}

int buscarPolitico(vector<Politico> politicos, string politico){
	int i, pos;
	pos = -1;
	for(i = 0; i < politicos.size() && pos == -1; i++){
		if(politicos[i].nombre == politico){
			pos = i;
		}
	}
	return pos;
} 

void actualizar(vector<Politico> &politicos, string linea, string clave){
	bool encontrada;
	stringstream ss(linea);
	string aux;
	int pos;

	encontrada = buscarPalabraLinea(linea, clave);
	while(ss >> aux){
		if(aux[0] == '@'){
			pos = buscarPolitico(politicos, aux);
			if(pos != -1){
				politicos[pos].total++;
				if(encontrada){
					politicos[pos].encontrados++;
				}
			}
		}
	}
}

void procesarTweets(string ficheroPol, string ficheroTwe, string clave){
	ifstream fich;
	string linea;
 	vector<Politico> politicos;
	double ratio;
	
	// si consigo procesar el fichero de politicos
	if(leerPoliticos(ficheroPol, politicos)){
		// empezamos a procesar los tweets
		fich.open(ficheroTwe.c_str());
		if(fich.is_open()){
			getline(fich, linea);
			while(!fich.eof()){
				actualizar(politicos, linea, clave);
				getline(fich, linea);
			}
			fich.close();
			for(int i = 0; i < politicos.size(); i++){
				cout << politicos[i].nombre << " (Total=" << politicos[i].total << ", encontrados=" << politicos[i].encontrados;
				cout << " ratio=";
				if(politicos[i].total != 0){
					ratio = (double) politicos[i].encontrados / politicos[i].total * 100;
				}	
				else{
					ratio = 0;
				}
				cout << ratio << "%)"  << endl;
			
			}
		}
	}
}

int main(int argc, char * argv[]){
	if(argc == 4){
		procesarTweets(argv[2], argv[1], argv[3]);
	}

}


