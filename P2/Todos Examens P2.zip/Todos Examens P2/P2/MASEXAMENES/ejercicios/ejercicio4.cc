/*Programa que lee dos ficheros de texto y crea un nuevo fichero de texto intercalando
las lineas de ambos ficheros:
	
	fich1		fich2		resultado
	lin1		l1		lin1
	lin2		l2		l1
	lin3		l3		lin2
	lin4				l2
	lin5				lin3
					l3
					lin4
					lin5
*/
