/*
	realizar un programa de menciones.
	Hemos recibido una conversacion de un grupo de whatsapp y queremos saber quien menciono
	a quien en cada whatsapp. El formato del fichero sera:

	athar said: el puto @juan esta loco y es muy facha
	juan said: mediciona @julia jaa ja ja @dani negro es
	nico said: @josea12 @pacomoreno se aman
	jose said: @juan @julia @nico estais todos locos si muy locos

	El programa debera mostrar para cada usuario a quien nombre
	@athar -> @juan
	@nico -> @josea12 @pacomoreno
	@jose -> @juan @julia @nico

	suponer que es un whatsapp por linea.
*/
