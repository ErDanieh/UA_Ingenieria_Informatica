#include <iostream>
#include <fstream>
using namespace std;


/*
	2. Dada la definicion de la siguiente estructura. Pedir
	numeros al usuario hasta que el usuario meta un numero negativo
	El programa debera mostrar para cada numero introducido
	por el usuario, la informacion del Documento que ocupa
	dicha posicion en el fichero binario.
	
	documento: 0
	<title, url, length>   muestra el primer documento del fichero binario

	documento: 3
	<title, url, lenght>   muestra el cuarto documento del fichero binario

	documento: 8
	Numero maximo de documentos es 5 <que lo se yo porque lo se, vosotros lo teneis que averiguar>

	NO LEER EL FICHERO BINARIO Y CARGARLO EN UN VECTOR DE ESTRUCTURAS!!!!!
*/
struct Documento{
	char title[50];
	char url[50];
	int length;
};

int main(){
	Documento leido;
	ifstream fich;
	int ndocs, totalDocs;
	
	fich.open("documents.bin", ios::binary);
	if(fich.is_open()){
		fich.seekg(0, ios::end);
		totalDocs = fich.tellg() / sizeof(Documento);
		cout << "Total Documentos Almacenados: " << totalDocs << endl;
		cout << "documento: ";
		cin >> ndocs;
		cin.get();
		while(ndocs >= 0){
			if(ndocs >= totalDocs){
				cout << "El documento existe" << endl;
			}
			else{
				// posiciona el puntero de lectura en el byte
				// donde yo quiera.
				fich.seekg(sizeof(Documento) * ndocs);
				fich.read((char *) &leido, sizeof(leido));
				cout << "Title: " << leido.title << endl;
				cout << "Url: " << leido.url << endl;
				cout << "Length: " << leido.length << endl;
			}
			cout << "documento: ";			
			cin >> ndocs;
			cin.get();
		}
		fich.close();
	}
	return 0;
}




// EJEMPLO DE AYUDA DE USO SEEKG
// -----------------------------
// C++ program to Read a record from a File 
// using seekg() and tellg() 
/*
#include <bits/stdio.h> 
using namespace std; 

class student { 
	int id; 
	char Name[20]; 

public: 
	void display(int K); 
}; 


void student::display(int K) 
{ 
	fstream fs; 
	fs.open("student.dat", ios::in | ios::binary); 

	// using seekg(pos) method 
	// to place pointer at 7th record 
	fs.seekg(K * sizeof(student)); 

	// reading Kth record 
	fs.read((char*)this, sizeof(student)); 

	// using tellg() to display current position 
	cout << "Current Position: "
		<< "student no: "
		<< fs.tellg() / sizeof(student) + 1; 

	// using seekg()place pointer at end of file 
	fs.seekg(0, ios::end); 

	cout << " of "
		<< fs.tellg() / sizeof(student) 
		<< endl; 
	fs.close(); 
} 

// Driver code 
int main() 
{ 

	// Record number of the student to be read 
	int K = 7; 

	student s; 
	s.display(K); 

	return 0; 
} 
*/
