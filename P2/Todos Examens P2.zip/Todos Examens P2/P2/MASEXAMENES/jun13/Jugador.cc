#include "Jugador.h"


Jugador::Jugador(){
	puntuacion = 0;
}

int Jugador::getPuntuacion() const{
	return puntuacion;
}

// palabra = "ALAS"  rack = "P---C-SCA"

bool Jugador::mover(string palabra, string rack){
	bool realizada = true;
	
	string aux = rack; // marcamos los caracteres con -

	

	return realizada;
}
