#include <iostream>
#include <cstring>
#include <fstream>
#include <sstream>

using namespace std;

int main(){
    string linea1;
    string linea2;

    ifstream fich1("f1.txt");
    ifstream fich2("f2.txt");

    if(fich1.is_open() && fich2.is_open()){
        while(getline(fich1,linea1)&& getline(fich2,linea2)){
            if(linea1==linea2){
                cout<<linea1<<"....."<<linea2<<endl;
            }else{
                cout<<linea1<<"XXXXX"<<linea2<<endl;
            }
        }
    }
}