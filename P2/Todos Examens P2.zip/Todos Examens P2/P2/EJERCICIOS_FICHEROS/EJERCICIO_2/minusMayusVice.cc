#include <cstring>
#include <vector>
#include <fstream>
#include <iostream>

using namespace std;

int main(){
    char caracter;
    
    ifstream fich("fichero.txt"); //Fichero de entrada
    ofstream salid("FICHERO.txt");//Fichero de salida

    if(fich.is_open()){
        while(fich.get(caracter)){//Lee el fichero caracter a caracter 
            if(islower(caracter)!=0){
                salid <<(char)toupper(caracter);
            }
            else{
                salid <<(char)tolower(caracter);
            }

        }
    }
    fich.close();
}
    
