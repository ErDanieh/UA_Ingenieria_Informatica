#include <cstring>
#include <vector>
#include <fstream>
#include <iostream>
#include <sstream> 


using namespace std;

int main(){
    string linea;
    string transform="";
    string palabra;

    ifstream fich("fichero.txt");
    ofstream salida("FACHERO.txt");

    if(fich.is_open()){
        while(getline(fich,linea)){
            transform="";
            stringstream proces(linea);
            while(proces>>palabra){
                palabra[0]=toupper(palabra[0]);
                transform=transform+" ";
                transform=transform+palabra;
            }
            salida<<transform<<endl;
        }
    }
}