#include <vector>
#include <iostream>
#include <sstream>
#include <fstream>

using namespace std;

int main(){
    vector<string> frases;
    string palabra;
    unsigned cont=0;
    string linea;
    string buscada;

    cout<<"Introduce la palabra que deseas buscar: ";
    getline(cin,buscada);

    ifstream fich("fichero.txt");

    if(fich.is_open()){
        while(getline(fich,linea)){
            cont=0;
            stringstream proces(linea);
            while(proces>>palabra){
                if(buscada==palabra){
                    cont++;
                }
            }
            if(cont!=0){
                frases.push_back(linea);
            }
        }
    }
    fich.close();

    for(unsigned i = 0; i < frases.size(); i++){
        cout<<frases[i]<<endl;
    }

}