#include <string>
#include <iostream>
#include <vector>
#include <sstream>
#include <cstring>
#include <fstream>

using namespace std;
const string palabra_buscar = "Navidad";

int main() {
  string a;
  int repeticiones = 0;

  ifstream fl("fichero.txt");
  if(fl.is_open()){
    string s; // Podríamos leer int, float, ...
    while(getline(fl,s)){ // Lee fila a fila mientras queden
      stringstream frase(s); 
      while(frase>>a){ // Lee palabra a palabra mientras queden
        if(a==palabra_buscar && repeticiones == 0){
          cout << s << endl;
          repeticiones++;
        }
      }
      repeticiones = 0;
  }
  fl.close();
  }
  else{
    cout << "Error al abrir el fichero" << endl;
  }

}