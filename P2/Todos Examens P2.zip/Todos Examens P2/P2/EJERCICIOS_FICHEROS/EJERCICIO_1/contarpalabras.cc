#include <vector>
#include <iostream>
#include <sstream>
#include <fstream>

using namespace std;

int main(){
    string a;
    unsigned cont=0;

    ifstream fich("fichero.txt");

    if(fich.is_open()){
        string s;
        while(getline(fich,s)){
            stringstream frase(s);
            while(frase>>a){
                cont++;
            }
        }
    }
    fich.close();
    cout<<cont;

}

void PalabraporPalabra(string fichero)
{
    string palabra;
    string linea;

    ifstream fich(fichero);

    if(fich.is_open())
    {
        while(getline(fich,linea))
        {
            stringstream proce(linea);//La pasamos al buffer

            while(proce>>palabra)
            {
                //CODE
                //Anotacion: Las palabras se pueden recorrer letra a letra;
            }
        }
    }
}