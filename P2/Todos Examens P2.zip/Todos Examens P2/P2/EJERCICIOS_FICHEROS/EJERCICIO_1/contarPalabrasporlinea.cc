#include <vector>
#include <iostream>
#include <sstream>
#include <fstream>

using namespace std;

int main(){
    string a;
    unsigned contlinea=1;
    unsigned cont=0;
    string s;

    ifstream fich("fichero.txt");

    if(fich.is_open()){
        while(getline(fich,s)){//Leeremos el fichero hasta que nos quedemos sin lineas
            cont=0;
            stringstream frase(s);
            while(frase>>a){//Leemos palabra a palabra
                cont++;
            }
            cout<<s<<endl;
            cout<<"Linea "<<contlinea<<": "<<cont<<endl;
            contlinea++;
        }
    }
    fich.close();
}