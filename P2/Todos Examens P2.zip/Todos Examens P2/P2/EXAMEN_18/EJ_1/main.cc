#include <iostream>
#include <string>
#include <vector>

#include "User.h"
#include "Tweet.h"


using namespace std;

int main(){

  vector <string> users;

  User juan("juan","john666@google.com");
  users.push_back(juan.getName());

  User arya("arya12","aryaPulova@hotmail.es");
  users.push_back(arya.getName());

  juan.writeTweet("just saw @arya12 at the supermarket!",users);
  arya.writeTweet("are you sure it was me, @juan?",users);
  Tweet t1("good morning, world",users);
  arya.addTweet(t1);
  Tweet t2("good afternon, world", users);
  juan.addTweet(t2);

  cout << juan << endl;
  cout << arya << endl;

  return 0;
}



