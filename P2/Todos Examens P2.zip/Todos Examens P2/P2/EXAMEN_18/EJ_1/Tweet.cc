#include "Tweet.h"


unsigned int Tweet::nextId = 1;

Tweet::Tweet(string text, const vector <string> &user){
  
  bool mencion = true;
  unsigned i = 0;
  string palabra;
  string usuarioEncontrado;
  string usuarioEncontradoCorregido;

  stringstream texto(text);

  while(texto>>palabra){
    
    if(palabra[0] == '@'){
      mencion = false;
      usuarioEncontrado = palabra.substr(1);

      while (i < usuarioEncontrado.length() && isalnum(usuarioEncontrado[i]))
      {
        usuarioEncontradoCorregido += usuarioEncontrado[i];
        i++;
      }
      
      usuarioEncontrado = usuarioEncontradoCorregido;

      for(unsigned i = 0; i < user.size() && mencion == false; i++){
        if(user[i] == usuarioEncontrado){
          mencion = true;
        }
      }
    }

    if(mencion == false){
      cin.get();
      throw Exception(exception_mention);
    }
  }
  

  this->text=text;
  id = nextId;
  nextId++;

}

vector <string> Tweet::getMentions() const{

  bool existeMencion = false;
  vector <string> usuariosMencionados;

  string palabra;
  string usuarioEncontrado;

  stringstream texto(text);

  while(texto>>palabra){
    
    if(palabra[0] == '@'){
      usuarioEncontrado = palabra.substr(1);

      for(unsigned i = 0; i < usuariosMencionados.size() && existeMencion == false; i++){
        if(usuarioEncontrado == usuariosMencionados[i]){
          existeMencion = true;
        }
      }

      if(existeMencion == false){
        usuariosMencionados.push_back(usuarioEncontrado);
      }

      else
      {
        existeMencion = false;
      }

    }

  }

  return usuariosMencionados;
}

ostream &operator<<(ostream &os, const Tweet &t){
  cout << "[" << t.getId() << "] " << t.getText() << endl;
  return os;
}