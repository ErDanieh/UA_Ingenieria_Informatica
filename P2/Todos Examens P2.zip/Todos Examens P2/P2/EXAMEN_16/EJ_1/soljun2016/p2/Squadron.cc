
#include <iostream>
#include <fstream>

using namespace std;

#include "Squadron.h"

Squadron::Squadron(string filename,string name)
{
  ifstream f(filename.c_str());

  this->name=name;
  wins=0;
  losses=0;

  if (f.is_open())
  {
    string typeFighter;
    int attack,shield;

    // lectura de datos sueltos con >> (como en transparencia "Lectura de más de una variable")
    while (f>>typeFighter)
    {
      f >> attack >> shield;  // si hay 'typeFighter', los otros datos están
      try {
        Fighter fighter(typeFighter,attack,shield);  // si attack/shield están mal se lanza una excepción
        fighters.push_back(fighter);
      }
      catch(...)
      {
        cout << "Wrong fighter data" << endl;
      }
    }
    f.close();
  }
  else
    cout << "Error, can't open file" << endl;
}

void Squadron::fight(Squadron &enemy)
{
  do
  {
    int nfighter=Fighter::getRandomNumber(fighters.size());
    int nfenemy=Fighter::getRandomNumber(enemy.fighters.size());

    Fighter fighter=fighters[nfighter];
    fighters.erase(fighters.begin()+nfighter);  // como en la práctica 2, se borra del escuadrón

    Fighter fenemy=enemy.fighters[nfenemy];
    enemy.fighters.erase(enemy.fighters.begin()+nfenemy);

    while (fighter.getShield()>0 && fenemy.getShield()>0)  // mientras los cazas no se hayan destruído...
    {
      if (!fighter.fight(fenemy))
        fenemy.fight(fighter);  // si el primer ataque no acaba con el enemigo, el caza enemigo ataca al caza actual (fighter)
    }

    if (fighter.getShield()>0) {   // gana el primer caza
      fighters.push_back(fighter); // devolver el caza al final del escuadrón, como en la práctica 2
      wins++;
      enemy.losses++;
    }
    if (fenemy.getShield()>0) {   // gana el segundo caza (enemigo)
      enemy.fighters.push_back(fenemy);
      losses++;
      enemy.wins++;
    }

  } while (fighters.size() > 0 && enemy.fighters.size() > 0);
}

ostream &operator<<(ostream &os,const Squadron &sq)
{
  os << sq.name << ": Wins=" << sq.wins << " Losses=" << sq.losses ;
  for (unsigned int i=0;i<sq.fighters.size();i++)
    os << " " << sq.fighters[i];
  return os;
}
