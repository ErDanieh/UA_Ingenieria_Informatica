#include "Squadron.h"
int main()
{
    Squadron a("first.txt","Imperial"), b("second.txt","Rebel");

    cout << "---" << endl << a << endl;

    a.fight(b);

    cout << "---" << endl << a << endl << b << endl;
}
