#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <vector>
#include <cstring>


using namespace std;

struct Relaciones{
    char nombre1[40];
    int relacion;
    char nombre2[40];
};


void leerfichero(string filename, vector <Relaciones> todasRelaciones){
    Relaciones relaciones;

    ifstream ficheroBinario(filename, ios::binary); //Abrimos el fichero

    if(ficheroBinario.is_open()){
        while(ficheroBinario.read((char*)&relaciones, sizeof(relaciones))){
            todasRelaciones.push_back(relaciones);
        }
        ficheroBinario.close();//Importante cerrar el fichero;
    }
    else{
        cout<<"El fichero no se puede abrir. "<<endl;
    }

}
/*
int buscador(vector<string> &mostrados, string nombre){
    int pos=-1;
    if(mostrados.size()==0){
        mostrados.push_back(nombre);
    }
    else{
        for(unsigned i = 0; i < mostrados.size(); i++){
            if(strcmp(mostrados[i], nombre)==0){
                pos=i;
            }
        }
    }
    return pos;
}
*/

void devolverInformacion(vector <Relaciones> todasRelaciones){
    for(unsigned i = 0; i < todasRelaciones.size(); i++){
        cout<<todasRelaciones[i].nombre1<<endl;
    }
}




//Se pasa el nombre del fichero por argumentos
int main(int args, char *argv[]){
    vector<Relaciones>todasRelaciones;
    string filename;
    vector<string>mostrados;

    if(args!=2){ //Comprabamos la cantidad de argumentos que nos pasan
        cout<<"Error arguments. "<<endl;
    }
    else{
        filename=argv[1];//el argumento 0 es el nombre del programa
        leerfichero(filename, todasRelaciones);
        devolverInformacion(todasRelaciones);
    }
}

