#include "Fighter.h"


Fighter::Fighter(string type, int attack, int shield){
  this->type = type;
  this->attack = attack;
  this->shield = shield;
}

int Fighter::getRandomNumber(int n){

  int randomNumber;
  randomNumber =  rand()%n;


  return randomNumber;
}

bool Fighter::fight(Fighter &enemy){
  
  bool cazaDerribado = false;

  int valorAtaque = Fighter::getRandomNumber(99);
  enemy.setShield(enemy.getShield()- (attack * valorAtaque));

  if(enemy.getShield() <= 0){
    cazaDerribado = true;
  }


} 

void Fighter::setAttack(int attack){
  this->attack=attack;
}

void Fighter::setShield(int shield){
  this->shield = shield;
}


ostream& operator<<(ostream &os, const Fighter &f){
  cout << 

}
