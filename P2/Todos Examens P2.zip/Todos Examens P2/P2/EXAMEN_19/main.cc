#include <iostream>
#include <string>

using namespace std;


enum Familias{}



int main(){


  return 0;
}