#ifndef _REGION_H_
#define _REGION_H_

#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include "Station.h"


using namespace std;


class Region
{
  private:
    string name;
    vector <Station> stations;
  public:
    Region(string name);
    bool addStation(string filename);
    int findStation(string name) const;
    float getValue(string name, Value v, Month m) const;
    float getAvgTemp(Month m) const;
    string getWarmestStation(Month m) const;    
};


#endif