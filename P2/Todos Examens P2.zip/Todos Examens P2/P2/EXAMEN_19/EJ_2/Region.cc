#include "Region.h"


Region::Region(string name){
  this->name=name;
}

bool Region::addStation(string filename){
  bool anyadido = false;
  string stationName;
  int pos;

  try
  {
    ifstream ficheroEntrada;
    ficheroEntrada.open(filename);

    if(ficheroEntrada.is_open()){
      getline(ficheroEntrada,stationName);
      pos = findStation(stationName);

      if(pos != -1){
        throw exception();
      }

      Station st(filename);
      stations.push_back(st);
      anyadido = true;
    }

    else
    {
      cout << "Error opening file" << endl;
    }
  }

  catch(const std::exception& e)
  {
    cout << "Wrong station name" << endl;
  }

  return anyadido;
}

int Region::findStation(string name) const{
  int pos = -1;

  for(unsigned i = 0; i < stations.size() && pos == -1; i++){
    if(stations[i].getName() == name){
      pos = i;
    }
  }

  return pos;
}

float Region::getValue(string name, Value v, Month m) const{
  int pos = findStation(name);
  return stations[pos].getValue(v,m);
}

float Region::getAvgTemp(Month m) const{
  float sumatorioTemperaturas = 0;
  float temperaturaMedia = 0;

  for(unsigned i = 0; i < stations.size(); i++){
    sumatorioTemperaturas = sumatorioTemperaturas + stations[i].getValue(T,m);
  }

  temperaturaMedia = sumatorioTemperaturas/stations.size();
  return temperaturaMedia;
}

string Region::getWarmestStation(Month m) const{
  float temperaturaMaxima = 0;
  float temperaturaLeida = 0;
  string warmestStation = "";

  for(unsigned i = 0; i < stations.size(); i++){
  
    temperaturaLeida = stations[i].getValue(TM,m);
    if(temperaturaLeida > temperaturaMaxima){
      temperaturaMaxima = temperaturaLeida;
      warmestStation = stations[i].getName();    
    }
  }

  return warmestStation;
}