#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <vector>
#include <string>
#include <cstring>

using namespace std;

struct TCapi
{
    int cap;
    vector<string>frase;
    vector<int>puntuacion;
};



void imprimir(vector<TCapi>capitulos)
{
    for(unsigned i =0; i < capitulos.size(); i++)
    {
        cout<<"Capitulo "<<capitulos[i].cap<<endl;
        for(unsigned j = 0; j < capitulos[i].frase.size(); j++)
        {
            cout<<capitulos[i].frase[j]<<endl;
        }
    }
}

void actualizar(vector<TCapi>&capitulos, int cap, int intpuntuacion, string cita)
{
    TCapi nuevo;
    int pos=-1;

    for(unsigned i = 0; i < capitulos.size(); i++)
    {
        if(capitulos[i].cap==cap)
        {
            pos=i;
        }
    }
    if(pos==-1)
    {
        nuevo.cap=cap;
        nuevo.puntuacion.push_back(intpuntuacion);
        nuevo.frase.push_back(cita);
        capitulos.push_back(nuevo);
    }
    else{
        capitulos[pos].puntuacion.push_back(intpuntuacion);
        capitulos[pos].frase.push_back(cita);
    }
}


/*Funcion Para leer un fichero de texto y meter su información dentro de un vector*/
void leerFichero(string ficheroTexto, vector<TCapi> &capitulos)
{
    string cita, numcap, puntuacion;
    string linea;
    int intpuntuacion,cap;
    
    ifstream fich(ficheroTexto);
    if(fich.is_open())
    {
        while(getline(fich,linea))
        {
            stringstream proce(linea);

            getline(proce,cita,'$');
            getline(proce,numcap,'$');
            getline(proce,puntuacion);
            
            intpuntuacion=atoi(puntuacion.c_str());
            cap=atoi(numcap.c_str());

            actualizar(capitulos,cap,intpuntuacion,cita);
        }
        fich.close();
    }
    else
    {
        cout<<"Error al abrir el fichero"<<endl;
    }

    imprimir(capitulos);
}


int main(int args, char *argv[])
{
    string ficherotexto;
    vector<TCapi> capitulos;

    if(args!=2){
        cout<<"Error de argumentos"<<endl;
    }
    else
    {
        ficherotexto=argv[1];
        leerFichero(ficherotexto,capitulos);

    }
}
