#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <fstream>

using namespace std;

struct TDocumento
{
    char title[50];
    char url[50];
    int length;
};

void leerFichero(string palabraBuscar, int &posDoc,int &cantReps)
{

    ifstream fich("index.txt");
    string linea;
    string palabra;
    string valorleido;
    int posleido;
    int posMayor=0;
    int cantLeido;
    int cantMayor=0;
    bool palabraEncontrada=false;

    if(fich.is_open()){
        while(getline(fich,linea)&&palabraEncontrada==false)
        {
            stringstream proce(linea);
            
            //Cogemos hasta la barra que es donde se encuntra la palabra
            getline(proce,palabra,'|');

            if(palabra==palabraBuscar)
            { //si hemos encontrado la palabra entonces
                palabraEncontrada=true;//Pasamos a procesar sus valores

                //Mientras quede información de la linea en el buffer
                while(!proce.eof())
                {
                    getline(proce,valorleido,':');
                    posleido=stoi(valorleido);
                    getline(proce,valorleido,'|');
                    cantLeido=stoi(valorleido);

                    //solo se queda con la mayor frecuencia y su posición
                    if(cantLeido>cantMayor)
                    {
                        posMayor=posleido;
                        cantMayor=cantLeido;
                    }
                }
            }
        }
        fich.close();
        if(palabraEncontrada==false)
        {
            cout<<"No se ha encontrado la palabra"<<endl;
        }
        else
        {
            posDoc=posMayor;
            cantReps=cantMayor;
        } 
    }
    else{
        cout<<"No se ha podido abrir el fichero"<<endl;
    }


}

/*
void leerFichero(string filename, vector <Relaciones> &todasRelaciones){

  Relaciones relaciones;

  ifstream ficheroBinario(filename,ios::binary);

  if(ficheroBinario.is_open()){
    while (ficheroBinario.read((char*)&relaciones,sizeof(relaciones))){
      todasRelaciones.push_back(relaciones);
    }

    ficheroBinario.close();
  }
  else
  {
    cout << "El fichero no se puede abrir. " << endl;
  }
}
*/

void cargarbinario(vector<TDocumento>&doc){
    TDocumento documento;

    ifstream ficheroBinario("documents.bin", ios::binary);
    //Abrimos el fichero binario

    if(ficheroBinario.is_open())
    {
        //Este while siempre es igual, lo único que cambia es el nombre
        //De la variable donde almacenamos la información;
        while(ficheroBinario.read((char*)&documento,sizeof(documento)))
        {
            doc.push_back(documento);
        }
        ficheroBinario.close();
    }
    else
    {
        cout<<"No se ha podido abrir el fichero binario"<<endl;
    }

}

void mostrarInfo(vector<TDocumento>doc,int posDoc,int cantReps){

    cout<<doc[posDoc].title<<" "<<doc[posDoc].url<<" "<<doc[posDoc].length/cantReps;
}

int main(int args, char *argv[]){
    string palabraBuscar;
    vector<TDocumento> doc;
    int posDoc;
    int cantReps;

    if(args!=2)
    {
        cout<<"Error de argumentos..."<<endl;
    }else
    {
        palabraBuscar=argv[1];

        leerFichero(palabraBuscar,posDoc,cantReps);
        cargarbinario(doc);
        mostrarInfo(doc,posDoc,cantReps);
    }

}