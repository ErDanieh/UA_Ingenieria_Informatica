// EJE 1.
// -----
// 1.1 devuelve cierto si el autor ha escrito el libro.
bool Author::isAuthor(string bookTitle) const
{
    bool escrito=false;
    
    for(unsigned i = 0; i < book.size(); i++)
    {
        if(books[i]==bookTitle)
        {
            escrito=true;
        }
    }
    return escrito;
	
}

//Devuelve cierto si el autor ha escrito el libro
bool Author::isAuthor(string bookTitle)const
{
    vector<string>libros;
    bool found=false;

    for(unsigned i = 0; i < author.size() && found ==false; i++)
    {
        //Recorremos el vector de autores y vamos sacando esos libros
        libros=author[i].getBooks();
        //Recorremos los libros, y si encontramos el libro pasamos el found a true
        for(unsigned j = 0; j < libros.size()&& found==false; j++)
        {
            //Paramos los bucles si lo encontramos
            if(libros[i]==bookTitle)
            {
                found=true;

            }
        }
    }
    return found;
}

// 1.2 devuelve la posicion del autor del libro pasado como parametro.
int Library::getAuthorName(string bookTitle) const
{
    int pos=-1;
    vector<string>libros;

    //Recorremos el vector de autores

    for(unsigned i= 0; i < author.size() && pos==-1; i++)
    {
        //sacamos los libros del autor
        libros=author[i].getBooks();
        for(unsigned j = 0; i < libros.size() && pos==-1; j++)
        {
            //Recorriendo los libros, comprobamos si alguno es 
            //igual al pasado como parametro
            if(libros[j]==bookTitle)
            {
                pos = i;
            }
            //Si coincide devolvemos la posición del autor;
        }

    }
    return pos;
}
// 1.3 devuelve la cantidad de libros premiados del autor
// pasado como parametro
int Library::getPremiados(int posAuthor) const
{
    vector<string>libros;
    int cont=0;

    //Sacamos los libros del autor que pasamos como parametro desde la posicion
    libros=author[posAuthor].getBooks();

    //Recorremos su vector de libros, y comprobamos si ha sido premiado
    for(unsigned i= 0; i < libros.size(); i++)
    {
        //si el libro ha sido premiado lo incrementamos
        if(libros[i].isPrized()==true)
        {
            cont++;
        }
    }
    return cont;
}




//Devuelve un vector con los nombres de los libros que ha leido la persona
vector<Lending> Reader::getLendings() const
{
    return lendings;
}





// 1.4 vector de string de las personas que han cogido libros de autores que tengan  mas de dos premios.
vector<string> Library::report() const
{
	vector<string> personas;
    vector<string>libros;
    int cont=0;

    for(unsigned i = 0; i < readers.size();i++)
    {
        libros=readers[i].lendings();//sacamos en un vector de string los libros que ha sacado
        for(unsigned j = 0; j < libros[j].size(); j++)
        {
            pos=getAuthorName(libros[j].getBookTitle());
            //Sacamos la posicion del autor que tiene ese libro;
            //si eser autor tiene más de dos libros premiados, entonces añadimis la persona
            if(author[pos].getPremiados()>2)
            {
                personas.push_back(readers[i].getName());
            }
        }
    }   


}

// EJE 2.
// ------
// 2.1 Devuelve en un vector los autores que tengan la cantidad de libros más premiada 
vector<string> Library::getMasPremiados() const
{
    int maxPremiados, cantPremiados;
    vector<string>nombre;

    for(unsigned i = 0; i < author.size(); i++)
    {
        cantPremiados=getPremiados(i);//a get premiados le pasamos la posicion del autor

        if(i == 0 || cantPremiados>maxPremiados)
        {
            maxPremiados=cantPremiados;
        }
    }
    //El autor que coincida con el maximo de premios encontrado se mete en el vector
    for(unsigned i = 0; i < author.size(); i++)
    {
        cantPremiados=getPremiados(i);

        if(maxPremiados==cantPremiados)
        {
            nombres.push_back(author[i].getName());
        }
    }
}

// 2.2 Nombres de los usuarios que hayan alquilado libros de los autores más premiados
vector<string> Library::getCommons() const
{
    vector<string> personas;
    vector<string>lendings;
    vector<string>MasPremiados=getMasPremiados();
    string autor;

    for(unsigned i = 0; i <readers.size(); i++)
    {
        //Recorremos el vector de lectores sacamos los libros que han leido
        lendings=readers[i].getLendings();
        
        for(unsigned j = 0; j < lendings.size(); j++)
        {
            //De cada libro leido sacamos el autor 
            pos=getAuthorName(lendings[j].getBookTitle());
            author=author[pos].getName();
            
            for(unsigned k =0; k < MasPremiados.size(); k++)
            {
                //De cada autor comprobamos si esta en el vector de autores más premiados 
                if(MasPremiados[k]==autor)
                {
                    personas.push_back(readers[i].getName());
                }
            }
        }
    }
}








