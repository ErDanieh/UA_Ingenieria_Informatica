#include "Youtuber.h"


Youtuber::Youtuber(string nick, string url)
{
    if(nick=="")
    {
        throw 1;
    }
    if(url.find("http://www.youtube.com/channel/")!=0)
    {
        throw 2;
    }
    //Los podemos poner fuera de un else
    //porque si se genera expecion no se ejecuta el programa

    this->nick=nick;
    this->url=url;
    penalized=false;
    profits=0;
}

string Youtuber::getNick() const
{
    return nick;
}

string Youtuber::url() const
{
    return url;
}

bool Youtuber::isPenalized() const
{
    return penalized;
}

void Youtuber::setPenalized(bool penalized)
{
    this->penalized=penalized;
}

void Youtuber::addProfits(float profits)
{
    this-> profits+=profits;
}