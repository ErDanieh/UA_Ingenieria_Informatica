#include "Category.h"
using namespace std;

Category::Category(string description, int percetage)
{
    this->description=description;
    this->percetage=percetage;

}

void Category::addForbiddenNick(string nick)
{
    forbiddenNick.push_back(nick);
}

void Category::addYoutuber(string nick, string url)
{
    bool found=false;

    try
    {
        Youtuber nuevo(nick,url);

        for(unsigned i =0; i < forbiddenNick.size() && found==false;i++)
        {
            if(forbiddenNick[i]==nick)
            {
                found=true;
            }
        }

        if(found==false)
        {
            youtubers.push_back(nuevo);
        }
        else
        {
            cout<<"FORBIDDEN NICK"
        }
    }
    catch(int &e)
    {
        if(e==1)
        {
            cout<<"Error missing Data"<<endl;
        }
        else{
            cout<<"Error: Wrong URL "<<url<<endl;
        }
    }
}

void Category::penalize(string nick)
{
    int pos=-1;

    for(unsigned i = 0; i < youtubers.size(); i++)
    {
        if(youtubers[i].getNick()==nick)
        {
            pos=i;
        }
    }
    if(pos==-1)
    {
        cout<<"Wrong Nick"<<endl;
    }
    else{
        if(youtubers[pos].isPenalized()==true)
        {
            youtubers.erase(youtubers.begin()+pos);
        }
        else
        {
            youtubers[i].setPenalized(true);
        }
    }
}

void Category::shareProfits(float profits)
{
    if(youtubers.size()>0)
    {
        for(unsigned i = 0; i < youtubers.size();i++)
        {
            youtubers[i].addProfits(profits/youtubers.size());
        }
    }
}