#ifndef _CATEGORY_
#define _CATEGORY_

#include "Youtuber.h"
#include <iostream>
#include <cstring>

using namespace std;

class Category
{
    friend ostream& operator<<(ostream &os, Category &q);

    private:
    //Si esta subrayado hay que ponerle static delante
    vector<Youtuber> youtubers;
    string description;
    vector<string>forbiddenNicks;


    public:
    Category(string description, int percentage);
    void addForbidden(string nick);
    void addYoutuber(string nick, string url);
    void penalized(string nick);
    void shareProfits(float profits);

};

#endif