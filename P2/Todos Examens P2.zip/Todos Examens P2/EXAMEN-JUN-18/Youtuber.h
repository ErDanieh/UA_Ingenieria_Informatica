#ifndef _YOUTUBER_
#define _YOUTUBER_

#include <iostream>
#include <cstring>

using namespace std;

class Youtuber
{
    friend ostream& operator<<(ostream &os, Youtuber &q);

    private:
      //Si esta subrayado hay que ponerle static delante
        string nick;
        string url;
        bool penalized;
        float profits;

    public:
        Youtuber(string nick, string url);
        string getNick()const;
        string getUrl()const;
        bool isPenalized()const;
        void setPenalized(bool penalized);
        void addProfits(float profits);

};

#endif