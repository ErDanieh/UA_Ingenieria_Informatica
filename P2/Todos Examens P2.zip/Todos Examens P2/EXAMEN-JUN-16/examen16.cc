#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <vector>
#include <string>
#include <cstring>

using namespace std;

#define KNombre 40

struct TRelacion
{
    char nombre1[KNombre];
    int relacion;
    char nombre2[KNombre];
};

struct TPersonaje
{
    string nombre;
    vector<string>amigos;
    vector<string>enemigo;
    vector<string>neutral;
};

int buscar(vector<TPersonaje>&personajes,string nombre)
{
    TPersonaje nuevo;
    int pos=-1;
    for(unsigned i = 0; i < personajes.size();i++)
    {
        if(personajes[i].nombre==nombre)
        {
            pos=i;
        }
    }

    return pos;
}



void anadir(vector<TPersonaje>&personajes,string nombre1,string nombre2, unsigned relacion)
{
    int pos1, pos2;
    TPersonaje nuevo;

    pos1=buscar(personajes,nombre1);
    pos2=buscar(personajes,nombre2);

    if(pos1==-1)
    {
        nuevo.nombre=nombre1;
        //nuevo.amigos={""};
        //nuevo.enemigo={""};
        //nuevo.neutral={""};
        personajes.push_back(nuevo);
        pos1=buscar(personajes,nombre1);
    }
    if(pos2==-1)
    {
        nuevo.nombre=nombre2;
        //nuevo.amigos={""};
        //nuevo.enemigo={""};
        //nuevo.neutral={""};
        personajes.push_back(nuevo);
        pos2=buscar(personajes,nombre2);
    }

    if(pos1!=-1)
    {
        switch(relacion)
        {
            case 0:
                personajes[pos1].neutral.push_back(nombre2);
                break;
            case 1:
                personajes[pos1].enemigo.push_back(nombre2);

                break;
            case 2:
                personajes[pos1].amigos.push_back(nombre2);

                break;
        }
    }
    
    if(pos2!=-1)
    {
        switch(relacion)
        {
            case 0:
                personajes[pos2].neutral.push_back(nombre1);
                break;
            case 1:
                personajes[pos2].enemigo.push_back(nombre1);

                break;
            case 2:
                personajes[pos2].amigos.push_back(nombre1);

                break;
        }
    }   

}


void leerFicheroBinario(string ficheroBin, vector<TRelacion>&relaciones,vector<TPersonaje>&personajes)
{
    TRelacion relacion;
    int relacionnum;
    string nombre2,nombre1;

    ifstream fich(ficheroBin,ios::binary);

    if(fich.is_open())
    {
        while(fich.read((char* )&relacion,sizeof(relacion))){
            relaciones.push_back(relacion);
        }
        fich.close();

        for(unsigned i = 0; i < relaciones.size();i++)
        {
            relacionnum=relaciones[i].relacion;
            nombre1=relaciones[i].nombre1;
            nombre2=relaciones[i].nombre2;
            anadir(personajes,nombre1,nombre2,relacionnum);
        }
    }
    else
    {
        cout<<"No se ha podido abrir el bin"<<endl;
    }
}

/*

void imprimir(vector<TRelacion>relaciones)
{
    for(unsigned i = 0; i < relaciones.size(); i++){
        cout<<relaciones[i].nombre1<<endl;
        switch(relaciones[i].relacion){
            case 0:
                cout<<"Friend: ";
                break;
            case 1:
                cout<<"Enemy: ";
                break;
            case 2:
                cout<<"relative: ";
                break;
            default:
                break;
        }
        cout<<relaciones[i].nombre2<<endl;
        cout<<endl;
    }

}
*/

void imprimirPersonajes(vector<TPersonaje>personajes)
{
    for(unsigned i =0 ; i < personajes.size(); i++)
    {
        cout<<personajes[i].nombre<<" "<<endl;
        if(personajes[i].neutral.size()!=0){
            cout<<"Relatives: ";
            for(unsigned j = 0; j < personajes[i].neutral.size();j++)
            {
                cout<<personajes[i].neutral[j]<<" ";
            }
            cout<<endl;
        }

        if(personajes[i].enemigo.size()!=0){
            cout<<"Enemigos: ";
        
            for(unsigned j = 0; j < personajes[i].enemigo.size();j++)
            {
                cout<<personajes[i].enemigo[j]<<" ";
            }
            cout<<endl;
        }
        if(personajes[i].amigos.size()!=0){
            cout<<"Amigos: ";
            for(unsigned j = 0; j < personajes[i].amigos.size();j++)
            {
                cout<<personajes[i].amigos[j]<<" ";
            }
            cout<<endl;
        }
        cout<<endl;
    }
}


int main(int args, char *argv[]){
  vector<TRelacion> relaciones;
  string ficherobin;
  vector<TPersonaje> personajes;

  if(args!=2)
  {
      cout<<"Error de argumentos..."<<endl;
  }
  else{
      ficherobin=argv[1];

      leerFicheroBinario(ficherobin,relaciones,personajes);
      //imprimir(relaciones);
      imprimirPersonajes(personajes);
  }

}