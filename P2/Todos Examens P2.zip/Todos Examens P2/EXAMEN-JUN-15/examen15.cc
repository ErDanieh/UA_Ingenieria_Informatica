#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <vector>
#include <string>
#include <cstring>

using namespace std;


struct TPoliticos
{
    string nombre;
    int total;
    int encontrados;
};


void leerFichero(string ficheroPoliticos, vector<TPoliticos> &politicos)
{
    TPoliticos nuevo;
    string linea;
    string nombre;

    ifstream fich(ficheroPoliticos);

    if(fich.is_open())
    {
        while(getline(fich,linea))
        {
            stringstream proce(linea);

            getline(proce,nombre);

            nuevo.nombre=nombre;
            nuevo.total=0;
            nuevo.encontrados=0;

            politicos.push_back(nuevo);
        }
        fich.close();
    }
    else{
        cout<<"No se ha podido abrir el fichero"<<endl;
    }
}

bool encontrada(string linea, string palabra)
{
    stringstream proce(linea);
    string palabralinea;
    bool encontrada=false;

    while(proce>>palabralinea)
    {
        if(palabralinea==palabra){
            encontrada=true;
        }
    }
    return encontrada;
}

void procesarTweets(string ficheroTweets, vector<TPoliticos>&politicos, string palabra)
{
    string palabralinea, palabralinea2;
    string linea;

    ifstream fich(ficheroTweets);

    if(fich.is_open())
    {
        while(getline(fich,linea))
        {
            stringstream proce(linea);

            while(proce>>palabralinea)
            {
                if(palabralinea[0]=='@')
                {
                    for(unsigned i = 0; i < politicos.size(); i++)
                    {
                        if(politicos[i].nombre==palabralinea)
                        {
                            politicos[i].total++;
                        }
                    }
                }
            }

            if(encontrada(linea,palabra)==true)
            {
                stringstream proce2 (linea);

                while(proce2>>palabralinea2)
                {
                    if(palabralinea2[0]=='@')
                    {
                        for(unsigned j = 0; j < politicos.size();j++)
                        {
                            if(politicos[j].nombre==palabralinea2)
                            {
                                politicos[j].encontrados++;
                            }
                        }
                    }
                }

            }

        }
        fich.close();
    }
    else
    {
        cout<<"Error al abrir el fichero"<<endl;
    }

}

void imprimir(vector<TPoliticos>politicos)
{
    double ratio;
    for(unsigned i = 0; i < politicos.size(); i++){
        cout<<politicos[i].nombre<<" "<<politicos[i].total<<" "<<politicos[i].encontrados;
        ratio=(double)politicos[i].total/politicos[i].encontrados*100;
        cout<<" "<<"Ratio: "<<ratio<<"%";
        cout<<endl;
    }

}



int main(int args, char *argv[])
{
    vector<TPoliticos> politicos;
    string ficheroPoliticos;
    string ficheroTweets;
    string palabra;

    if(args!=4)
    {
        cout<<"Error de argumentos..."<<endl;
    }
    else{
        ficheroTweets=argv[1];
        ficheroPoliticos=argv[2];
        palabra=argv[3];

        leerFichero(ficheroPoliticos,politicos);
        procesarTweets(ficheroTweets,politicos,palabra);
        imprimir(politicos);
        
    }
}