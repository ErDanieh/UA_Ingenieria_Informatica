#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <vector>
#include <string>
#include <cstring>

using namespace std;

struct TPal
{
    int cont;
    string pal;
};

string normalizarNombre(string Nombre)
{
    string NombreNomalizado;

    for(unsigned i = 0 ; i < Nombre.length(); i++){
        if(i==0){
            NombreNomalizado+=tolower(Nombre[i]);
        }
        else if(isalnum(Nombre[i]) && Nombre[i-1]==' '){
            NombreNomalizado+=tolower(Nombre[i]);
        }
        else{
            NombreNomalizado+=tolower(Nombre[i]);
        }
    }
    return NombreNomalizado;
}

string eliminarSimbolos(string text)
{
  unsigned textLen = text.length();

  for (unsigned i = 0; i < textLen; i++)
  {
    if (isalnum(text[i]) == 0 && text[i] != ' ')
    {
      text.erase(i, 1);
      i--;
      textLen = text.length();
    }
  }

  return text;
}


void actualizar(vector<TPal>&palabras, string palabra)
{
    TPal nueva;

    int pos =-1;

    for(unsigned i =0; i < palabras.size(); i++)
    {
        if(palabras[i].pal==palabra)
        {
            pos=i;
        }
    }

    if(pos==-1)
    {
        nueva.pal=palabra;
        nueva.cont=1;
        palabras.push_back(nueva);
    }
    else
    {
        palabras[pos].cont++;
    }
}


void leerFichero(string ficheroTexto, vector<TPal> &palabras)
{
    string palabra;
    TPal nueva;
    string linea;
    int conti=0;
    
    ifstream fich(ficheroTexto);

    if(fich.is_open())
    {
        while(getline(fich,linea))
        {
            conti=0;
            stringstream proce(linea);

            while(proce>>palabra)
            {
                palabra=eliminarSimbolos(palabra);
                palabra=normalizarNombre(palabra);
                actualizar(palabras,palabra);
            }

            for(unsigned i = 0; i < palabras.size(); i++)
            {
                if(palabras[i].cont!=1)
                {
                    conti++;
                }
            }

            cout<<palabras.size() - conti<<" "<<linea<<endl;

            palabras.clear(); //Para limpiar todo el contenido de un vector
        }
        fich.close();
    }
    else
    {
        cout<<"Error al abrir el fichero"<<endl;
    }
}



int main(int args, char *argv[])
{
    string ficheroTexto;
    vector<TPal>palabras;
    if(args!=2)
    {
        cout<<"Error en los argumentos";
    }
    else
    {
        ficheroTexto=argv[1];
        leerFichero(ficheroTexto,palabras);
    }
}