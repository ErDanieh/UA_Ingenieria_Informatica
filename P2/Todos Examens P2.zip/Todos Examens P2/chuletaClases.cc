/*
        ARCHIVO.h
*/

#ifndef _NOMBRE_
#define _NOMBRE_

#include <iostream>
#include <cstring>

using namespace std;

class NOMBRE
{
    friend ostream& operator<<(ostream &os, NOMBRE &q);

    private:
    //Si esta subrayado hay que ponerle static delante

    public:

};
//Si un archivo dentro del diagrama esta señalado con una flecha negra es que hay que añadir un vector

#endif


/*
        ARCHIVO.cc
*/

#include "Archivo.h"
using namespace std;

//Si aparece un static hay que declararla también en el .cc


//Ejemplo de constructor
NOMBRE::NOMBRE()
{

}

int NOMBRE::funcion()const
{
    return algodelaparteprivada
}

/*
    Imaginemos que nos pasan valores como parametro que tenemos que asignar
    lo que debemos de hacer es lo siguiente
*/

int NOMBRE::funcion2(int valorAsignado)
{
    this->valorAsignado=dondeQuieroAsignardelPrivate;
}

vector<string> NOMBRE::funcion3(string nombre)
{
    for(unsigned i = 0; i < vector.size();i++)
    {
        if(nombre==vector[i].getName())
        {
            
        }
    }
}
