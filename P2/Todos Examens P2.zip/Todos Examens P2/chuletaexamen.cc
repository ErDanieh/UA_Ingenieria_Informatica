/*

    CHULETA PARA EL EXAMEN DE FICHEROS 


*/

/*
    LIBRERIAS
*/
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <vector>
#include <string>
#include <cstring>



/*Funcion Para leer un fichero de texto y meter su información dentro de un vector*/
void leerFichero(string ficheroTexto, vector<TRelacion> &relaciones)
{
    string guardar;
    TRelacion nueva;
    string linea;
    
    ifstream fich(ficheroTexto);
    if(fich.is_open())
    {
        while(getline(fich,linea))
        {
            stringstream proce(linea);

            getline(proce,guardar,'*condición*');

            nueva.loquesea=guardar;

            relaciones.push_back(nueva);

            /*
            //Para hacer algo mientras quede información en el buffer
            while(!proce.eof()) 
            {
                getline(proce,actividad,',');
                anadir(nombre,actividad,actividades);
            }
            */

            
        }
        fich.close();
    }
    else
    {
        cout<<"Error al abrir el fichero"<<endl;
    }
}


/*Funcio que pasado un fichero de texto lo recorre palabra por palabra*/
void PalabraporPalabra(string fichero)
{
    string palabra;
    string linea;

    ifstream fich(fichero);

    if(fich.is_open())
    {
        while(getline(fich,linea))
        {
            stringstream proce(linea);//La pasamos al buffer

            while(proce>>palabra)
            {
                //CODE
                //Anotacion: Las palabras se pueden recorrer letra a letra;
            }
        }
    }
}

/////////////BINARIOS////////////////////////////////////////////////////////////////////////

/*Con esta función pasaremos la información de un vector a un fichero binario*/
void exportarBinario(string ficheroBin, vector<TRelacion>relaciones){

    TBinRelacion binNueva; //La estructura no puede contener strings, se sustituyen por char[KLongitud]
    
    ofstream fich;

    fich.open(ficheroBin, ios::binary);

    if(fich.is_open()){
        
        for(unsigned i = 0; i < relaciones.size(); i++)
        {
            //Para copiar número enteros o floats se utiliza el '='
            binPersona.numero=relaciones[i].numero;

            //Para copiar strings de un vector a un vector binario se utliza 

            //strncpy(Destino, origen, longitud)
            //Destino[longitud]='\0'

            strncpy(binNueva.Nombre,relaciones[i].Nombre.c_str(),kNOMBRE);
            binNueva.Nombre[kNOMBRE]='\0';


            fich.write((const char *)&binNueva, sizeof(binNueva));
        }
        fich.close();
    }
    else{
        cout<<"Error al abrir el fichero"<<endl;
    }
    
}



//Un fichero binario no tiene strings
struct BinLeido{
    unsigned dni;
    char Nombre[kNOMBRE];
    float paga;
    char servicio[kNOMBRE];
    char fechaAlta[kNOMBRE];
};
/*Funcion para leer un fichero binario*/
void leerFicheroBinario(string ficheroBin, vector<BinLeido>&cosasdelbin)
{
    BinLeido cosa;

    ifstream fich(ficheroBin,ios::binary);

    if(fich.is_open())
    {
        while(fich.read((char* )&cosa,sizeof(cosa))){
            cosasdelbin.push_back(cosa);
        }
        fich.close();
    }
    else
    {
        cout<<"No se ha podido abrir el bin"<<endl;
    }
}



/////////Funciones Varias////////////

string normalizarFecha(string fecha){
    string fechaEstand="";

    for(unsigned i = 0; i < fecha.length(); i++)
    {
        if(fecha[i]!='-')
        {
            fechaEstand=fechaEstand+fecha[i];
        }
    }
    return fechaEstand;
}

/*Funcion para pasar las primeras letras de una cadena de caracteres a mayusculas*/
string normalizarNombre(string Nombre)
{
    string NombreNomalizado;

    for(unsigned i = 0 ; i < Nombre.length(); i++){
        if(i==0){
            NombreNomalizado+=toupper(Nombre[i]);
        }
        else if(isalnum(Nombre[i]) && Nombre[i-1]==' '){
            NombreNomalizado+=toupper(Nombre[i]);
        }
        else{
            NombreNomalizado+=Nombre[i];
        }
    }
    return NombreNomalizado;
}

string TodoMinusculas(string Nombre)
{
    string NombreNomalizado;

    for(unsigned i = 0 ; i < Nombre.length(); i++){
        if(i==0){
            NombreNomalizado+=tolower(Nombre[i]);
        }
        else if(isalnum(Nombre[i]) && Nombre[i-1]==' '){
            NombreNomalizado+=tolower(Nombre[i]);
        }
        else{
            NombreNomalizado+=tolower(Nombre[i]);
        }
    }
    return NombreNomalizado;
}


./*
  función que devuelve text sin los caracteres no alfanumericos
*/
string eliminarSimbolos(string text)
{
  unsigned textLen = text.length();

  for (unsigned i = 0; i < textLen; i++)
  {
    if (isalnum(text[i]) == 0 && text[i] != ' ')
    {
      text.erase(i, 1);
      i--;
      textLen = text.length();
    }
  }

  return text;
}


string eliminarSignos(string Nombre)
{
    string nombreNormalizado="";
    
    for(unsigned i = 0; i < Nombre.length(); i++)
    {
        if(Nombre[i]!='?' && Nombre[i]!=',' && Nombre[i]!='!'&&Nombre[i]!='<'&& Nombre[i]!='-'&& Nombre[i]!=')' && Nombre[i]!='"'&& Nombre[i]!='+'&& Nombre[i]!=':'&& Nombre[i]!=';'&& Nombre[i]!='&'&& Nombre[i]!='.')
        {
            nombreNormalizado+=Nombre[i];
        }
    }
    
    return nombreNormalizado;
}