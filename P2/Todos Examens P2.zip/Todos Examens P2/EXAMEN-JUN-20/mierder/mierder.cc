#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <vector>
#include <string>
#include <cstring>

#define kNOMBRE 100

using namespace std;
//Estructura donde guardaremos los datos de la persona
//que se pasan por el fichero de texto
struct TPersona{
    unsigned dni;
    string Nombre;
    float paga;
    string servicio;
    string fechaAlta;
};


/*Funcion Para leer un fichero de texto y meter su información dentro de un vector*/
void leerFichero(string ficheroTexto, vector<TPersona> &personas)
{
    TPersona nueva;
    string linea;
    string guardar;
    int i =0;
    
    ifstream fich(ficheroTexto);
    if(fich.is_open())
    {
        while(getline(fich,linea))
        {
            stringstream proce(linea);
            i = 0;

            while(proce[i]!='|')
            {
                guardar+=proce[i];
                i++;
            }
            nueva.dni=atoi(guardar.c_str());
            i++;
            guardar="";

            while(proce[i]!='|')
            {
                guardar+=proce[i];
                i++;
            }
            nueva.Nombre=guardar;
            i++;
            guardar="";

            while(proce[i]!='|')
            {
                guardar=proce[i];
                i++;
            }
            nueva.paga=atof(guardar.c_str());
            i++;

            while(proce[i]!='|')
            {
                guardar=proce[i];
                i++;
            }
            nueva.servicio=guardar;
            i++;
            guardar="";

             while(proce[i]!='|')
            {
                guardar=proce[i];
                i++;
            }
            nueva.fechaAlta=guardar;

            relaciones.push_back(nueva);

        }
        fich.close();
    }
    else
    {
        cout<<"Error al abrir el fichero"<<endl;
    }

    for(unsigned i = 0; i < personas.size();i++)
    {
        cout<<personas[i].Nombre<<" "<<personas[i].dni;
    }
}


int main(int args, char *argv[])
{
    string ficheroTexto;
    vector<TPersona>personas;
    
    if(args!=2)
    {
        cout<<"Error de argumentos"<<endl;
    }
    else
    {
        ficheroTexto=argv[1];
        leerFichero(ficheroTexto,personas);


    }
}