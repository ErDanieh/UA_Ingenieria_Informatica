#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <fstream>
#include <cstring>

using namespace std;

struct TPersona{
    unsigned dni;
    string Nombre;
    float paga;
    string servicio;
    string fechaAlta;
};

struct BinPersona{
    unsigned dni;
    string Nombre;
    float paga;
    string servicio;
    string fechaAlta;
};

string normalizarFecha(string fecha){
    string fechaEstand="";

    for(unsigned i = 0; i < fecha.length(); i++){
        if(fecha[i]!='-'){
            fechaEstand=fechaEstand+fecha[i];
        }
    }
    return fechaEstand;
}

string normalizarNombre(string Nombre)
{
    string NombreNomalizado;

    for(unsigned i = 0 ; i < Nombre.length(); i++){
        if(i==0){
            NombreNomalizado+=toupper(Nombre[i]);
        }
        else if(isalnum(Nombre[i])&& Nombre[i-1]==' '){
            NombreNomalizado+=toupper(Nombre[i]);
        }
        else{
            NombreNomalizado+=Nombre[i];
        }
    }
    return NombreNomalizado;
}


void leerFichero(string ficheroTexto, vector<TPersona> &Personas)
{
    TPersona nueva;
    string linea;
    string dni,Nombre,paga,servicio,fechaAlta;
    
    ifstream fich(ficheroTexto);
    if(fich.is_open())
    {
        while(getline(fich,linea))
        {
            stringstream proce(linea);

            getline(proce,dni,'|');
            getline(proce,Nombre,'|');
            getline(proce,paga,'|');
            getline(proce,servicio,'|');
            getline(proce,fechaAlta,'|');

            nueva.dni=atoi(dni.c_str());
            nueva.Nombre=normalizarNombre(Nombre);
            nueva.paga=atof(paga.c_str());
            nueva.servicio=servicio;
            nueva.fechaAlta=normalizarFecha(fechaAlta);

            if(nueva.dni!=47859201 && nueva.dni!=72436512 && nueva.dni!=23749802)
            {
                Personas.push_back(nueva);
            }

            
        }
        fich.close();
    }
    else
    {
        cout<<"Error al abrir el fichero"<<endl;
    }
}



int main(int args, char *argv[]){
    string fichero;
    vector<TPersona>Personas;
    if(args!=2){
        cout<<"Error de argumentos..."<<endl;
    }
    else{
        fichero=argv[1];
        leerFichero(fichero,Personas);
        for(unsigned i = 0; i < Personas.size(); i++){
            cout<<Personas[i].Nombre<<endl;
            cout<<Personas[i].fechaAlta<<endl;
        }
    }
}