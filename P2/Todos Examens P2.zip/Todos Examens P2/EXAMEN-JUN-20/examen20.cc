#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <vector>
#include <string>
#include <cstring>

#define kNOMBRE 100

using namespace std;
//Estructura donde guardaremos los datos de la persona
//que se pasan por el fichero de texto
struct TPersona{
    unsigned dni;
    string Nombre;
    float paga;
    string servicio;
    string fechaAlta;
};
/*Estrucutura a la que pasaremos los datos leidos 
transformandolos a formato binario es decir que
no tendra strings */
struct TBinPersona{
    unsigned dni;
    char Nombre[kNOMBRE];
    float paga;
    char servicio[kNOMBRE];
    char fechaAlta[kNOMBRE];
};
/* Estructura de datos donde guardaremos los datos leido 
desde un fichero binario*/
struct BinLeido{
    unsigned dni;
    char Nombre[kNOMBRE];
    float paga;
    char servicio[kNOMBRE];
    char fechaAlta[kNOMBRE];
};
/*Función que elimina los guiones de una fecha, para dejarla
en el formato estandart ddmmaa*/
string normalizarFecha(string fecha){
    string fechaEstand="";

    for(unsigned i = 0; i < fecha.length(); i++)
    {
        if(fecha[i]!='-')
        {
            fechaEstand=fechaEstand+fecha[i];
        }
    }
    return fechaEstand;
}

/*Funcion para pasar las primeras letras de una cadena de caracteres a mayusculas*/
string normalizarNombre(string Nombre)
{
    string NombreNomalizado;

    for(unsigned i = 0 ; i < Nombre.length(); i++){
        if(i==0){
            NombreNomalizado+=toupper(Nombre[i]);
        }
        else if(isalnum(Nombre[i]) && Nombre[i-1]==' '){
            NombreNomalizado+=toupper(Nombre[i]);
        }
        else{
            NombreNomalizado+=Nombre[i];
        }
    }
    return NombreNomalizado;
}


/*Funcion Para leer un fichero de texto y meter su información dentro de un vector*/
void leerFichero(string ficheroTexto, vector<TPersona> &Personas)
{
    TPersona nueva;//Donde guardamos la información de la persona nueva
    string linea;
    string dni,Nombre,paga,servicio,fechaAlta;
    
    ifstream fich(ficheroTexto);//Abrimos el fichero
    if(fich.is_open())
    {
        while(getline(fich,linea))//Mientras queden lineas en el fichero 
        {
            stringstream proce(linea);//La pasamos al buffer

            getline(proce,dni,'|');
            getline(proce,Nombre,'|');
            getline(proce,paga,'|');
            getline(proce,servicio,'|');
            getline(proce,fechaAlta,'|');
            //Guardamos toda la información en forma de strings

            //Asignamos la información y los números los pasamos a enteros y floats
            nueva.dni=atoi(dni.c_str());
            nueva.Nombre=normalizarNombre(Nombre);
            nueva.paga=atof(paga.c_str());
            nueva.servicio=servicio;
            nueva.fechaAlta=normalizarFecha(fechaAlta);


            //Comprobamos los dnis
            if(nueva.dni!=47859201 && nueva.dni!=72436512 && nueva.dni!=23749802)
            {
                Personas.push_back(nueva);
            }

            
        }
        fich.close();
    }
    else
    {
        cout<<"Error al abrir el fichero"<<endl;
    }
}




/*void txt2bin(const TCliente &cliente, TClienteBin &clienteBin){
	strncpy(clienteBin.nombre, cliente.nombre.c_str(), kNOMBRE);
	clienteBin.nombre[kNOMBRE] = '\0';
	clienteBin.dni = cliente.dni;
	clienteBin.precio = cliente.precio;
	strcpy(clienteBin.ip, cliente.ip);
	clienteBin.alta = cliente.alta;
}
*/


/*Con esta función pasaremos la información de un vector a un fichero binario*/
void exportarBinario(string ficheroBin, vector<TPersona>Personas){
    TBinPersona binPersona;
    
    ofstream fich;

    fich.open(ficheroBin, ios::binary);//Abrimos el fichero binario

    if(fich.is_open()){
        
        for(unsigned i = 0; i < Personas.size(); i++)
        {

            //Los valores numericos podemos asignarlos tal cual dentro de la estructura binaria pero...
            binPersona.dni=Personas[i].dni;

            binPersona.paga=Personas[i].paga;
            
            /*Para copiar strings tendremos que transformalas a
             char añadiendoles el '\0' y además asignandoles 
            una longitud*/
            strncpy(binPersona.Nombre,Personas[i].Nombre.c_str(),kNOMBRE);
            binPersona.Nombre[kNOMBRE]='\0';

            strncpy(binPersona.servicio,Personas[i].servicio.c_str(),kNOMBRE);
            binPersona.servicio[kNOMBRE]='\0';

            strncpy(binPersona.fechaAlta,Personas[i].fechaAlta.c_str(),kNOMBRE);
            binPersona.fechaAlta[kNOMBRE]='\0';

            fich.write((const char *)&binPersona, sizeof(binPersona));
        }
        fich.close();
    }
    else{
        cout<<"Error al abrir el fichero"<<endl;
    }
    
}




/*Funcion para leer un fichero binario*/
//SIEMPRE ES IGUAL//
void leerFicheroBinario(string ficheroBin, vector<BinLeido>&cosasdelbin)
{
    BinLeido cosa;

    ifstream fich(ficheroBin,ios::binary);

    if(fich.is_open())
    {
        while(fich.read((char* )&cosa,sizeof(cosa))){
            cosasdelbin.push_back(cosa);
        }
        fich.close();
    }
    else
    {
        cout<<"No se ha podido abrir el bin"<<endl;
    }
}


void imprimircosasdelBin(vector<BinLeido>cosasdelbin)
{
    for(unsigned i = 0; i < cosasdelbin.size(); i++){
        cout<<cosasdelbin[i].Nombre<<endl;
        cout<<cosasdelbin[i].servicio<<endl;
    }
}




int main(int args, char *argv[]){
    string ficheroBin;
    string ficheroTexto;
    vector<TPersona> Personas;
    vector<TBinPersona>binPersona;
    vector<BinLeido>cosasdelbin;

    if(args!=5){
        cout<<"Error argumentos..."<<endl;
    }
    else{
        if(strcmp(argv[1],"-i")==0)
        {
            ficheroTexto=argv[2];

            if(strcmp(argv[3],"-o")==0)
            {
                ficheroBin=argv[4];
            }
            else{
                cout<<"Error argumentos"<<endl;
            }
        }
        else if(strcmp(argv[1],"-o")==0)
        {
            ficheroBin=argv[2];
            
            if(strcmp(argv[3],"-i")==0)
            {
                ficheroTexto=argv[4];

            }
            else{
                cout<<"Error argumentos"<<endl;
            }
        }

        leerFichero(ficheroTexto,Personas);//Leemos el fichero y guardamos la información
        exportarBinario(ficheroBin,Personas);//La copiamos al fichero binario
        leerFicheroBinario(ficheroBin,cosasdelbin);//La leemos del fichero binario
        imprimircosasdelBin(cosasdelbin);//La imprimimos
    }
    
}