#include <iostream>
#include <cstring>
#include <vector>
#include <fstrema>


using namespace std;

struct comentario{
    string texto;
    int valoracion;
}

struct ciudad{
    string ciudad;
    int valoracion;
    vector<comentario> comentarios;
}

//Leeremos un fichero ciudades.txt y almacenamos la información de dicho fichero
//y la almacenaremos en el vector de ciudades;
//2. Escribimos en el fichero binario el vector de ciudade
//3.Leemos el fichero binario y lo metemos en el vector


void extraerInfo(string linea, string &nc, Comentario &com){
    stringstream ss(linea);
    string svaloracion;

    getline(ss, com.texto,';');
    getline(ss, svaloracion, ';');
    com.valoracion=atoi(svaloracion.c_str());
    getline(ss, nc); //te lo guarda en nc

}

int buscarCiudad(vector<ciudad> &ciudadesm str){
    int i , pos;
    pos=-1;
    for(i =0; i < ciudades.size(); i++){
        if()
    }
}

int main(){
    vector<ciudad>ciudades;
    string linea;
    ifstream fichtext;
    string nombreCiudad;
    comentario nuevoCom;

    if(fichtext.is_open()){
        while(!fichtext.eof()){//Lo va a hacer mientras queden lineas en el fichero
            
        }
        fichtext.close();
    }
    else{
        cout<<"error";
    }

}