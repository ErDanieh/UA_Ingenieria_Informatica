//DNI 48776120C  Asensi Roch, Daniel
#include <iostream>
#include <cstring>
#include <vector>
#include <cctype>
#include <cstdlib>
#include <sstream>
#include <algorithm>
#include <fstream>


using namespace std;

const string INTENTNAME="Intent name: ";
const string NEWEXAMPLE="New example: ";
const string ESPERAR="<< ";
const string SALIDA="q";
const char SALIDAMENU='b';
const int KMAXTEXTS=15;
const int  KMAXTEXTL=1000;
const string PREGUNTA="Confirm [Y/N]?: ";
const string SAVEALL="Save all intents [Y/N]?: ";
const string FILENAME="Enter filename: ";
const string JACCARD="Similarity: Jaccard";
const string NGRAM="Similarity: N-grams";
const string EXAMPLEID="Example id: ";
const string NEWRESPONSE="New response: ";
const string THRES="Threshold: ";
const string INTENT="Intent: ";
const string RESPO="Response: ";
const string TOTALIN="Total intents: ";
const string ENTERTHRES="Enter threshold: ";
const string ENTERALGO="Enter algorithm: ";
const string TOTALEX="Total examples: ";
const string EXAPERIN="Examples per intent: ";
const string RESPU=">>";
const int GRAM=3;



struct Example{
  int id; 
  string text; 
  vector<string> tokens; 
};


struct Intent{
  string name; 
  vector<Example> examples;
  string response;  
};

struct Chatbot{
  int nextId; 
  float threshold; 
  char similarity[3];
  vector<Intent> intents; 
};

struct BinIntent{
	char name[KMAXTEXTS];
	unsigned numExamples;
	char response[KMAXTEXTL];
};

struct BinChatbot{
	float threshold;
	char similarity[3];
	unsigned numIntents;
};


void showMainMenu();
void showTrainMenu();
int intentSearch(Chatbot megabot, string name);
void addIntent(Chatbot &megabot);
void deleteIntent(Chatbot &megabot);
string limpiacadenas(string cadena);
string limpiadorEses(string cadena);
string limpiadortotal(string cadena);
vector<string> tokenizador(string cadena);
void addExample(Chatbot &megabot);
void deleteExample(Chatbot &megabot);
void addResponse(Chatbot &megabot);
void train(Chatbot &megabot);
vector<string> PalabrasCompartidas(vector<string> cad1, vector<string> cad2);
double algoritmoJaccard(string cad1, string cad2);
void busquedaConsulta(const Chatbot &megabot, string consulta);
void test(const Chatbot &megabot);
void impresorTokens(vector<string> tokens);
void report(const Chatbot &megabot);
bool comprobarArgumentos(int argc, char *argv[], string &argu1, string &argu2, bool &t);
void configure(Chatbot &megabot);
Intent SacarLaInfodeLaLine(string lineas);
void importarInfo(Chatbot &megabot, string nombreFichero);
void exportarInfo(Chatbot megabot);
void cargarBot(Chatbot &megabot, string nombreFichero);
void salvarBot(Chatbot megabot);

string cleanString(string);

enum Error{
  ERR_OPTION,
  ERR_INTENT,
  ERR_EXAMPLE,
  ERR_RESPONSE,
  ERR_FILE,
  ERR_THRESHOLD,
  ERR_SIMILARITY,
  ERR_ARGS
}; 

const int KSIZE=10;

const string greetings[KSIZE]=
{
  "Hola, ¿en qué puedo ayudarte?",
  "¿Qué puedo hacer hoy por ti?",
  "Oh, gran prócer de los bits, ¿cuál es tu deseo?",
  "Buenas",
  "¿Qué quieres?",
  "¿Otra vez necesitas ayuda?",
  "¡Hola! Soy Megabot 3000. ¿En qué puedo ayudarte?",
  "Bonito día para ser Megabot 3000",
  "Pregunta sin miedo",
  "Soy todo oídos"
};

void error(Error n){
  switch(n){
    case ERR_OPTION:
      cout << "ERROR: wrong menu option" << endl;
      break;
    case ERR_INTENT:
      cout << "ERROR: wrong intent name" << endl;
      break;
    case ERR_EXAMPLE:
      cout << "ERROR: wrong example id" << endl;
      break;
    case ERR_RESPONSE:
      cout << "Lo siento, pero no tengo respuesta para eso" << endl;
      break;
    case ERR_FILE:
      cout << "ERROR: cannot open file" << endl;
      break;
    case ERR_THRESHOLD:
      cout << "ERROR: the threshold value must be between 0 and 1" << endl;
      break;
    case ERR_SIMILARITY:
      cout << "ERROR: valid values are \"jc\" (Jaccard) and \"ng\" (n-grams)" << endl;
      break;
    case ERR_ARGS:
      cout << "ERROR: invalid arguments" << endl;
  }
}

void showMainMenu()
{
  cout << "1- Train" << endl
       << "2- Test" << endl
       << "3- Report" << endl
       << "4- Configure" << endl
       << "5- Import data"<<endl
       << "6- Export data"<<endl
       << "7- Load chatbot" << endl
       << "8- Save chatbot" << endl
       << "q- Quit" <<endl
       << "Option: ";
}

void showTrainMenu()
{
  cout << "1- Add intent" << endl
       << "2- Delete intent" << endl
       << "3- Add example" << endl
       << "4- Delete example" << endl
       << "5- Add response" << endl
       << "b- Back to main menu" << endl
       << "Option: ";
}




int intentSearch(Chatbot megabot, string name)
{ 
int pos;
int tamanyo;
tamanyo=megabot.intents.size();
pos=-1;

for (int i =0; i < tamanyo && pos == -1; i++){
  if(megabot.intents[i].name==name){
    pos=i;
  }
}
return pos;

}


void addIntent(Chatbot &megabot)
{
  Intent nuevo; //Donde se introducen los valores del usuario
  int pos;

  cout<<INTENTNAME;
  getline(cin, nuevo.name);

  pos=intentSearch(megabot, nuevo.name);
  
  if(pos == -1){
    megabot.intents.push_back(nuevo);
  }else{
   error(ERR_INTENT); 
  }
}

void deleteIntent(Chatbot &megabot)
{
  string name;
  char siono;
  int pos;
  pos=0;

  cout<<INTENTNAME;
  getline(cin, name);

  pos=intentSearch(megabot, name);

  if (pos==-1){
    error(ERR_INTENT);
  }else{
  do{
      cout<<PREGUNTA;
      cin>>siono;
      if(siono=='y' || siono=='Y'){
        megabot.intents.erase(megabot.intents.begin()+pos); //elimina la intención que se encuentra en pos
      }
    } while (siono!='y' && siono !='Y' && siono != 'n' && siono!='N');

  }
}

string limpiacadenas(string cadena)
{
  string limpia;
  int tamanyo;
  limpia = "";
  tamanyo=cadena.length();

  for (int i = 0; i < tamanyo; i++){
    if(isalnum(cadena[i]) != 0 || cadena[i]== ' '){ 

        limpia=limpia + (char) tolower(cadena[i]);

    }
  }
  return limpia;
}

string limpiadorEses(string cadena)
{ 
  string eses="";
  int tamanyo;

  tamanyo=cadena.length();
  for(int i = 0; i < tamanyo; i++){
    if(cadena[i]=='s'){
      if(i+1 < tamanyo){
        if(cadena[i + 1]!=' '){
          eses=eses+cadena[i];
        }

      }
    }
    else{
      eses=eses+cadena[i];
    }
  }
  return eses;
}

string limpiadortotal(string cadena)
{
  cadena=cleanString(cadena);
  cadena=limpiacadenas(cadena); 
  cadena=limpiadorEses(cadena);

  return cadena;
}


vector<string> tokenizador(string cadena)
{
  string aux;
  vector<string> tokenizada;
  stringstream ss (cadena);
  while (ss >> aux)
  {
    tokenizada.push_back(aux);
  }
  return tokenizada;
  
}


void addExample(Chatbot &megabot)
{

  string Asignar, cleantext;
  Example nuevoExample;
  int pos;
  vector <string>toks;

  cout<<INTENTNAME;
  getline(cin, Asignar);

  pos=intentSearch(megabot,Asignar); 

  if(pos == -1){

    error(ERR_INTENT); 
  }
	else{
		cout << NEWEXAMPLE;
		getline(cin, cleantext);
		do{
			nuevoExample.id = megabot.nextId;
			nuevoExample.text = cleantext;

      cleantext=limpiadortotal(cleantext);
      toks.clear();
      toks=tokenizador(cleantext);
      
      if(toks.size()!=0){
        nuevoExample.tokens=toks;
        megabot.intents[pos].examples.push_back(nuevoExample);
        megabot.nextId++;
      }
			cout << NEWEXAMPLE;
			getline(cin, cleantext);

		}while(cleantext != SALIDA);
	}
}



void deleteExample(Chatbot &megabot)
{
  int posi, posj;
  int aborrar;
  int tamanyo, tamanyo2;
  tamanyo=megabot.intents.size();
  posi=-1;
  posj=-1;

  cout<<EXAMPLEID;
  cin>>aborrar;
  cin.get();
  
  for (int i = 0; i < tamanyo; i++){
    tamanyo2=megabot.intents[i].examples.size();
    for(int j = 0; j < tamanyo2 ;j++){
      if(aborrar == megabot.intents[i].examples[j].id){
        posi=i;
        posj=j;
      }
    }
  }
  if(posi!=-1 && posj!=-1){
    megabot.intents[posi].examples.erase(megabot.intents[posi].examples.begin()+posj);
  }
  else{
    error(ERR_EXAMPLE);
  }

}

void addResponse(Chatbot &megabot)
{
  string wantAdd;
  int pos;

  cout<<INTENTNAME;
  getline(cin, wantAdd);
  
  pos=intentSearch(megabot, wantAdd);

  if(pos==-1){
    error(ERR_INTENT); 
  }
  else{
    cout<<NEWRESPONSE;
    getline(cin,megabot.intents[pos].response); //Se sobreescribe el valor de response
  }
}



void train(Chatbot &megabot)
{ 
  char opcion;

  do{
    showTrainMenu();
    cin>>opcion;
    cin.get();
    switch (opcion)
    {
    case '1':
    addIntent(megabot);
      break;
    case '2':
    deleteIntent(megabot);
      break;
    case '3':
    addExample(megabot);
      break;
    case '4':
    deleteExample(megabot);
      break;
    case '5':
    addResponse(megabot);
      break;
    case 'b':
      break;
    default:
    error(ERR_OPTION);
      break;
    }
  }while(opcion!=SALIDAMENU);

}


vector<string> limpiaDuplicados(const vector<string> &tokens)
{
	vector<string> noDupli;
	bool find;
  int tam, tam2;
  tam=tokens.size();
  tam2=noDupli.size();

	for(int i = 0; i < tam; i++){
		find = false;
		for(int j = 0; j < tam2 && !find; j++){
			if(noDupli[j] == tokens[i]){
				find = true;
			}
		}
		if(!find){	
			noDupli.push_back(tokens[i]);
		}
	}
	return noDupli;
}


vector<string> PalabrasCompartidas(vector<string> cad1, vector<string> cad2)
{
  vector<string>intersec;
  int tam1;
  tam1=cad1.size();

  for(int i = 0; i < tam1; i++ ){
    if(find(cad2.begin(),cad2.end(), cad1[i]) != cad2.end()){
      intersec.push_back(cad1[i]);
    }
  }
  return intersec;
}




vector<string> tresGramas(vector<string> palabras)
{
  vector <string> tresgramitas;
  string grama;
  
  for (int i = 0 ; i < (int)palabras.size(); i++){
    if(palabras[i].length()>= GRAM){
      for(int j= 0; j <=(int) palabras[i].length()-GRAM;j++){
        tresgramitas.push_back(palabras[i].substr(j,GRAM));
      }
    }
  }
  return tresgramitas;
}



double algoritmoJaccard(Chatbot megabot,string cad1, string cad2)
{
  double jaccard;
  vector<string> tok1;
  vector<string> tok2;
  vector<string> intersec;
  vector<string> ngrams1;
  vector<string> ngrams2;

  //Limpiamos y tokenizamos la primera vez
  cad1=limpiadortotal(cad1);
  cad2=limpiadortotal(cad2);
  tok1=tokenizador(cad1);
  tok2=tokenizador(cad2);
  tok1=limpiaDuplicados(tok1);
  tok2=limpiaDuplicados(tok2);

  if(strcmp(megabot.similarity,"jc")==0){
  intersec=PalabrasCompartidas(tok1, tok2);
  jaccard=(double) intersec.size()/ (tok1.size()+tok2.size()-intersec.size());
  } //Si tres gramas esta activado tokenizamos lo tokenizado en Ngramas
  else{
    ngrams1=tresGramas(tok1);
    ngrams2=tresGramas(tok2);
    ngrams1=limpiaDuplicados(ngrams1);
    ngrams2=limpiaDuplicados(ngrams2);
    intersec=PalabrasCompartidas(ngrams1, ngrams2);
    jaccard=(double) intersec.size()/ (ngrams1.size()+ngrams2.size()-intersec.size());

  }
  //Ecuación de Jaccard Segun la cantidad de palabras

  return jaccard;
}

void busquedaConsulta(const Chatbot &megabot, string consulta)
{
  double actual;
  double mejor;
  string respuesta;
  int tamanyo;
  int tam2;
  string aux;


  tamanyo=megabot.intents.size();
  mejor=0;

  for(int i = 0; i < tamanyo; i++){

    tam2=megabot.intents[i].examples.size();

    for(int j=0; j < tam2; j++){
      actual=algoritmoJaccard(megabot,consulta, megabot.intents[i].examples[j].text); //Asignamos el valor actual de similitud

      if(actual>mejor){
        mejor=actual;
        respuesta=megabot.intents[i].response; //Vamos asignando las respuestas según la similitud, recorriendo el vector
      }
    }
  }
  if(mejor< megabot.threshold){
    error(ERR_RESPONSE);
  }
  else{
    cout<<RESPU<<respuesta<<endl;
  }
}


//Test Del Megabot
void test(const Chatbot &megabot)
{
  int position;
  string consulta, respuesta;
  
  string aux;

  position=rand()% KSIZE;
  cout<<RESPU<<greetings[position]<<endl;
  cout<<ESPERAR;
  getline(cin, consulta);
  while(consulta != SALIDA){
      busquedaConsulta(megabot, consulta);
      cout<<ESPERAR;
      getline(cin, consulta);
  }

}

//Función para imprimir los tokens por pantalla no tiene otra utilidad
void impresorTokens(vector<string> tokens)
{
  int tam;
  tam=tokens.size();

  for (int i = 0; i < tam; i++){
    cout<<"<"<<tokens[i]<<"> ";
    if(i != tam-1){
      cout<<" ";
    }
  }
}




void report(const Chatbot &megabot)
{
  int tam2;
  int tamnyo=megabot.intents.size();
  int numExamples;
  numExamples=0;
  if(strcmp(megabot.similarity, "jc")==0){
    cout <<JACCARD<< endl;
  }else
  {
    cout<<NGRAM<<endl;
  }
  
  cout <<THRES<<megabot.threshold << endl;

  for(int i = 0; i < tamnyo; i++){
    cout<<INTENT<< megabot.intents[i].name<<endl;
    cout<<RESPO<<megabot.intents[i].response<<endl;
    tam2=megabot.intents[i].examples.size();

    for(int j = 0; j < tam2; j++){
      numExamples++;
      cout<<"Example ";
      cout<<megabot.intents[i].examples[j].id<<": ";
      cout<<megabot.intents[i].examples[j].text<<endl;
      cout<<"Tokens "<<megabot.intents[i].examples[j].id<<": ";
      impresorTokens(megabot.intents[i].examples[j].tokens);
      cout<<endl;
    }
    cout<<endl;
  }
  cout<<TOTALIN<<tamnyo<<endl;
  cout<<TOTALEX<<numExamples<<endl;
  cout<<EXAPERIN;

  if(tamnyo != 0){
    cout<<(double) numExamples / tamnyo <<endl;
  }
  else {
    cout<< 0.0 <<endl;
  }

}

bool comprobarArgumentos(int argc, char *argv[], string &argu1, string &argu2, bool &t)
{
  bool correctos;
  int contadort=0;
  int contadori=0;
  int contadorl=0;
  argu1="";
  argu2="";
  t=false;
  correctos=true;

  for(int i = 1; i < argc ; i++){//Lo inicializamos en 1 para saltarnos el nombre del ejecutable
    if(strcmp(argv[i],"-t")==0){
      t=true;
      contadort++;
    }
    else{
      if(strcmp(argv[i],"-i")==0){
        argu2=argv[i+1];
        i++;
        contadori++;
      }
      else{
        if(strcmp(argv[i],"-l")==0){
          argu1= argv[i+1];
          i++;
          contadorl++;
        }
      }
    }
  }
  if (contadorl>1 || contadort>1 || contadori>1){ //si se introduce más de una vez un argumento pasa a false
    correctos=false;
  }
  return correctos;
}



void configure(Chatbot &megabot)
{
  string algorit;
  double umbral;

  cout << ENTERTHRES;
  cin>>umbral;
  cin.get();
  if(umbral <= 1 && umbral >= 0){
    megabot.threshold=umbral;
  }
  else
  {
    error(ERR_THRESHOLD);

  }

  cout<<ENTERALGO;

  getline(cin, algorit); //Si el que introduce es diferente de ng o jc el programa da error
  if((algorit != "jc") && (algorit !="ng")){
    error(ERR_SIMILARITY);
  }
  else{
    strcpy(megabot.similarity, algorit.c_str());//Si es uno de los dos copiamos la cadena

  }
}



Intent SacarLaInfodeLaLine(string lineas)
{
  Intent sacado;
  stringstream tt(lineas);
  //No quiero almacenar el primer caracter de la linea entonces me lo salto
  tt.get();
  getline(tt, sacado.name, '#');
  getline(tt, sacado.response);

  return sacado;
}


void importarInfo(Chatbot &megabot, string nombreFichero)
{
  ifstream fichero;
  string linea;
  Intent extraido;
  Example nuevo;
  int pos;

if(nombreFichero==""){
  cout<<FILENAME;
  getline(cin,nombreFichero);
}

  fichero.open(nombreFichero.c_str());

  if(fichero.is_open()==true){
    getline(fichero, linea);

    while(fichero.eof()==false){
      extraido=SacarLaInfodeLaLine(linea);
      getline(fichero, linea);
      pos=intentSearch(megabot, extraido.name);

      while(!fichero.eof() && linea[0] != '#'){
        if (pos==-1){
          nuevo.id=megabot.nextId;
          nuevo.text=linea;

          linea=limpiadortotal(linea);
          nuevo.tokens.clear();
          nuevo.tokens=tokenizador(linea);

          if(nuevo.tokens.size()!= 0){
            extraido.examples.push_back(nuevo);
            megabot.nextId++;
          }

        }
        getline(fichero, linea);
      }
    if(pos==-1){
      megabot.intents.push_back(extraido);//Si no encuentra el intent lo crea metiendolo al final
    }
    else{
    error(ERR_INTENT);
    }

    }   
    fichero.close();
  }
  else{ //Si no consigue abrir el fichero da error 
    error(ERR_FILE);
  }

}

void exportarInfo(Chatbot megabot)
{
  ofstream fichero;
  string nombreFichero;
  char SioNo;
  int pos;
  string buscado;


  do{
    cout<<SAVEALL;
    cin>>SioNo;
    cin.get();
  }while(SioNo!='y' && SioNo!='Y' && SioNo!='N' && SioNo!='n');

  if(SioNo=='Y' || SioNo=='y'){
    cout<<FILENAME;
    getline(cin,nombreFichero);

    fichero.open(nombreFichero.c_str());
    
    if(fichero.is_open()==true){
      for(int j= 0; j <(int) megabot.intents.size();j++){
        fichero<<"#"<<megabot.intents[j].name<<"#"<<megabot.intents[j].response<<endl;
        for(int k=0; k < (int)megabot.intents[j].examples.size(); k++){
          fichero<< megabot.intents[j].examples[k].text<<endl;
        }
      }
      fichero.close();
    }
    else{
      error(ERR_FILE);
    }

  }
  else{
    cout<<INTENTNAME;
    getline(cin, buscado);
    pos=intentSearch(megabot,buscado);

    if(pos != -1){
      cout<<FILENAME;
      getline(cin, nombreFichero);
      fichero.open(nombreFichero.c_str());

      if(fichero.is_open()){
        fichero.open(nombreFichero.c_str());
        //Crea o sobreescribe ficheros
        //Ahora los escribimos en el formato que se nos indica 
        fichero<< "#"<<megabot.intents[pos].name<<"#"<<megabot.intents[pos].response<<endl;

        for(int i = 0; i < (int)megabot.intents[pos].examples.size();i++){
          fichero<< megabot.intents[pos].examples[i].text<<endl;
        }
        fichero.close();
      }
    }
    else{
      error(ERR_INTENT);
    }


  }
}



void salvarBot(Chatbot megabot)
{
  ofstream fichero;
  string nombreFichero;
  BinChatbot binBot;
  BinIntent binInfo;
  char texto[KMAXTEXTL];

  cout<<FILENAME;
  getline(cin,nombreFichero);

  fichero.open(nombreFichero.c_str(), ios::binary);

  if(fichero.is_open()==false){
    error(ERR_FILE);
  }
  else{
    //Importamos los valores
    binBot.numIntents=megabot.intents.size();
    binBot.threshold=megabot.threshold;
    strcpy(binBot.similarity,megabot.similarity);

    fichero.write((const char *) &binBot, sizeof(binBot));

    for(int i=0; i <(int) megabot.intents.size(); i++){
      binInfo.numExamples=megabot.intents[i].examples.size();
      strncpy(binInfo.name, megabot.intents[i].name.c_str(),KMAXTEXTS);
      binInfo.name[KMAXTEXTS-1]='\0';

      strncpy(binInfo.response, megabot.intents[i].response.c_str() ,KMAXTEXTL);
      binInfo.response[KMAXTEXTL-1]='\0';
      fichero.write((const char *)&binInfo, sizeof(binInfo));

      for(int j=0; j <(int) megabot.intents[i].examples.size();j++){
        strncpy(texto, megabot.intents[i].examples[j].text.c_str(), KMAXTEXTL);
        texto[KMAXTEXTL-1]='\0';
        fichero.write((const char *)texto, sizeof(char) * KMAXTEXTL);
      }
    }
    fichero.close();
  }
}



void cargarBot(Chatbot &megabot, string nombreFichero)
{
  char SioNo;
  ifstream fichero;
  bool on;
  BinChatbot binBot;
  BinIntent binInfo;
  string line;
  char texto[KMAXTEXTL];
  vector<string> tokens;
  Intent newIntent;
  Example newExample;

  if(nombreFichero==""){
    cout<<FILENAME;
    getline(cin, nombreFichero);
    on=true;
  }
  else{
    on=false;
  }

  fichero.open(nombreFichero.c_str(), ios::binary);

  if(fichero.is_open()==true){
    if(on==true){
      do{
        cout<<PREGUNTA;
        cin>>SioNo;
        cin.get();
      }while(SioNo != 'y' && SioNo != 'Y' && SioNo !='n' && SioNo != 'N');
    }
    else{
      SioNo='Y';
    }

    if(SioNo=='Y'||SioNo=='y'){
      megabot.intents.clear();
      fichero.read((char *)&binBot, sizeof(binBot));
      megabot.threshold=binBot.threshold;
      megabot.nextId=1;
      strcpy(megabot.similarity,binBot.similarity);

      for(int i =0;i < (int)binBot.numIntents; i++){
        fichero.read((char *)&binInfo,sizeof(binInfo));
        newIntent.examples.clear();
        newIntent.name=binInfo.name;
        newIntent.response=binInfo.response;

          for(int j= 0; j < (int)binInfo.numExamples; j++){
            fichero.read((char *) texto,sizeof(char)*KMAXTEXTL);
            newExample.text=texto;
            newExample.id=megabot.nextId++;
            newExample.tokens.clear();

            line=limpiadortotal(texto);
            tokens=tokenizador(line);
            newExample.tokens=tokens;

            newIntent.examples.push_back(newExample);

          }
          megabot.intents.push_back(newIntent);
      }
      fichero.close();
    }
  }
  else{
  error(ERR_FILE);
  }
}


int main(int argc, char *argv[])
{
  Chatbot megabot;
  megabot.nextId=1;
  megabot.threshold=0.25;
  strcpy(megabot.similarity,"jc");
  bool correctargs;
  bool t; //Para el argumento del test
  string argu2;
  string argu1;
  char option;

  srand(666);


//Llamamos a las funciones utilizando los argumentos y pasando el nombre del fichero
  correctargs=comprobarArgumentos(argc, argv, argu1, argu2, t);
  if(correctargs==false){
    error(ERR_ARGS);
  }
  else{
    if(argu1 != ""){
      cargarBot(megabot, argu1);
    }
    if(argu2!= ""){
      importarInfo(megabot,argu2);
    }
    if(t==true){
      test(megabot);
    }
//No pasamos los argumentos y el nombre de los fichero es una cadena vacia
    do{
      showMainMenu();
      cin >> option;
      cin.get();
        
      switch (option){ 
        case '1':
         train(megabot);
          break;
        case '2':
          test(megabot);
          break;
        case '3':
          report(megabot);
          break;
        case '4':
          configure(megabot);
          break;
        case '5':
          importarInfo(megabot,"");//El conjunto vacio es el fichero
          break;
        case '6':
          exportarInfo(megabot);
          break;
        case '7':
          cargarBot(megabot,"");
          break;
        case '8':
          salvarBot(megabot);
        case 'q':
          break;
        default:
          error(ERR_OPTION);
      }
    }while(option!='q');

  }
    
  return 0;
}