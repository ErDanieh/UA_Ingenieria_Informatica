#!/bin/bash

MAXTIME=10 	   # Tiempo máximo de ejecución (en segundos) de una prueba
PRINCIPAL=./prac2	# Nombre del ejecutable de la práctica
ENT=pruebas	   # Directorio con los ficheros de pruebas de entrada
SAL=salida-correcta-esperada	   # Directorio con los ficheros de salidas correctas
OBT=salida-obtenida       # Directorio con los ficheros obtenidos tras la ejecución de la práctica
VAL="valgrind -q"  # Si valgrind no está instalado, quitar "valgrind -q" de esta linea (quedaría VAL=""). Ojo: La práctica debe probarse siempre con valgrind antes de la entrega.
mata=./mata
comparefiles=./comparefiles
cmpBin=./cmpBin

npruebasa=$(ls -1 pruebas/p2_[^z]* | wc -l)     # Número de pruebas a ejecutar del autocorrector
valorpruebasa=0.223         # Valor de las pruebas del autocorrector

npruebasc=$(ls -1 pruebas/p2_z* 2>/dev/null | wc -l)               # Número de pruebas del corrector final
valorpruebasc=0.25   # Valor de las pruebas del corrector


# -------------- generar y compilar los ficheros auxiliares mata.c, comparefiles.cc y cmpBinPlanet.cc -----
function genMata() {

if ! test -x mata ; then  # si ya existe no se genera
echo "#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <signal.h>
#include <unistd.h>

const int TAMMAXFICH=300000;
int f;int segundos,st;
int segejec=0;
char *nfsal=NULL;
void SeAcabo(int i){  
  fprintf(stderr,\"ERROR, tiempo de ejecución agotado... (%d segundos)\\n\",segundos);
  fflush(stderr); 
  kill(f,SIGKILL);  
  exit(-1); 
}
void SeAcaboFich(int i){  
  fprintf(stderr,\"ERROR, fichero de salida muy grande (cuelgue?)... \\n\");
  fflush(stderr); 
  kill(f,SIGKILL);  
  exit(-1); 
}
int FicheroGrande() {  
  struct stat s;  int ret=0;
  if (nfsal != NULL) {   
    stat(nfsal,&s);    
    if (s.st_size > TAMMAXFICH) ret = 1;  
  }  
  return ret;
}
void Control(int i){ 
  segejec++; 
  if (segejec >= segundos) SeAcabo(i); 
  else if (FicheroGrande()) SeAcaboFich(i); 
  else alarm(1); 
}
void Salir(int i){exit(1);}
int main(int argc,char *argv[]){ 
  if (argc < 4) exit(1);  
  segundos = atoi(argv[1]);  
  nfsal = argv[2]; 
  signal(SIGALRM,Control);  
  signal(SIGCHLD,Salir);  
  alarm(1);  
  if ((f = fork()) == 0) execvp(argv[3],&argv[3]);   
  else wait(&st);
}
" > mata.c
gcc -o mata mata.c
fi
}

function genComparefiles() {

if ! test -x comparefiles ; then # si ya existe no se genera
echo "#include <iostream>
#include <fstream>
#include <stdlib.h>

using namespace std;

int main(int argc, char *argv[])
{
  int salida=0;
  if (argc!=3) cout << \"Sintaxis: \" << argv[0] << \" <obtenido.txt> <correcto.txt>\" << endl;
  else 
  {
    ifstream fo(argv[1]);
    ifstream fc(argv[2]);
    if (fo.is_open() && fc.is_open())
    {
      string so,sc,tmp;

      fo >> tmp;
      while (!fo.eof() || tmp.length()!=0)
      {
        so=so+tmp;
        tmp=\"\";
        fo >> tmp;
      }
      fc >> tmp;
      while (!fc.eof() || tmp.length()!=0)
      {
        sc=sc+tmp;
        tmp=\"\";
        fc >> tmp;
      }

      // ignorar los '-' en las líneas
      string scok, sook;
      for (unsigned int i=0; i<so.length(); i++)
        if (so[i]!='-') sook=sook+so[i];
      for (unsigned int i=0; i<sc.length(); i++)
        if (sc[i]!='-') scok=scok+sc[i];
                                 
      if (sook!=scok) {
        exit(-1);
      }
    }
    else {
      cout << \"Fichero \" << argv[1] << \" o \" << argv[2] << \" no encontrado\" << endl;
      exit(-1);
    }
  }
  exit(0);
  return salida;
}
" > comparefiles.cc

g++ -o comparefiles comparefiles.cc

fi
}

function genCmpBin() {

if ! test -x cmpBin ; then # si ya existe no se genera
echo "#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

// ------------------------------------------------------

const int MAXTEXTS=15;
const int MAXTEXTL=1000;


struct BinChatbot {
   float threshold;
   char similarity[3];
   unsigned numIntents;
};

struct BinIntent {
  char name[MAXTEXTS];
  unsigned numExamples;
  char response[MAXTEXTL];
};


bool readBinIntent(const BinIntent&, const BinIntent &, unsigned int);

// ------------------------------------------------------
int cmpData(string filename,string fnref)
{

  ifstream fb,fbr;

  fb.open(filename.c_str(),ios::in|ios::binary);
  fbr.open(fnref.c_str(),ios::in|ios::binary);
  if (fb.is_open() && fbr.is_open())
  {
      BinChatbot bb,bbr;
      bool error=false;

      fb.read((char *)&bb,sizeof(bb));
      fbr.read((char *)&bbr,sizeof(bbr));

      if (strcmp(bb.similarity,bbr.similarity)) {
        cerr << \"Error BinChatbot.similarity, (\" << bb.similarity << \")[\" << bbr.similarity << \"]\" << endl;
        error=true;
      }
      else if (bb.numIntents != bbr.numIntents) {
        cerr << \"Error BinChatbot.numIntents, (\" << bb.numIntents << \")[\" << bbr.numIntents << \"]\" << endl;
        error=true;
      }
      else if (bb.threshold != bbr.threshold) {
        cerr << \"Error BinChatbot.threshold, (\" << bb.threshold << \")[\" << bbr.threshold << \"]\" << endl;
        error=true;
      }
      
      if (!error)
      {
        BinIntent c,cr;
        char bs[MAXTEXTL];
        char bsr[MAXTEXTL];
        for (unsigned i=0;i<bb.numIntents && !error;i++)
        {
          fb.read((char *)&c,sizeof(c));
          fbr.read((char *)&cr,sizeof(cr));
          
          error = readBinIntent(c, cr, i);
 	  if (!error)
          {
   	   for (unsigned j=0; j<c.numExamples && !error; j++) {
		fb.read((char *)&bs,sizeof(bs));
                fbr.read((char *)&bsr,sizeof(bsr));
		if (strcmp(bs,bsr)) {
         	   cerr << \"Error Example.text{\"<<j<<\"}.name (\" << bs << \")[\" << bsr << \"]\" << endl;
                   error=true;
                } //del if
	   } //del for
	  } //del if !error
	}//del for
        /*if ( (!fb.eof()) || (!fbr.eof()) ){
            	cerr << \"Error ficheros con numero de registros distintos\" << endl;
             	error=true; 
        }*/
       } //del if !error
       fb.close();
       fbr.close();
       if (error) return -1;
       else       return 0;
    } //del if opens
    else
      cerr << \"Error abriendo ficheros (\" << filename << \")[\" << fnref << \"]\" << endl;
    return -1;
}

bool readBinIntent (const BinIntent &c, const BinIntent &cr, unsigned int i) {
         bool error=false;
         if (strcmp(c.name,cr.name)) {
            cerr << \"Error BinIntent{\"<<i<<\"}.name (\" << c.name << \")[\" << cr.name << \"]\" << endl;
            error=true;
          }
          else  if (strcmp(c.response,cr.response)) {
            cerr << \"Error BinIntent{\"<<i<<\"}.response (\" << c.response << \")[\" << cr.response << \"]\" << endl;
            error=true;
          }
          else if (c.numExamples != cr.numExamples) {
            cerr << \"Error BinIntent{\"<<i<<\"}.numExamples (\" << c.numExamples << \")[\" << cr.numExamples << \"]\" << endl;
            error=true;
          }
	return error;
}

int main(int argc,char *argv[])
{
  if (argc == 3) 
    return cmpData(argv[1],argv[2]);
  else
    cerr << \"Uso: cmpBin binBase.bin binBaseCorrecto.bin\" << endl;
  return -1;
}

" > cmpBin.cc

g++ -o cmpBin cmpBin.cc

fi
}




echo "*********************************************************"
echo "Corrector P2p2 "


# Comprobar si está valgrind instalado
hayValgrind=$(which valgrind)
if test "$hayValgrind" == "" ; then
  echo "AVISO: El corrector se ejecutará sin valgrind, por lo que es posible que"
  echo "el resultado de la corrección no sea fiable. Para comprobar realmente que la"
  echo "práctica es correcta, debes probar el corrector en un ordenador Linux"
  echo "con valgrind instalado antes de la entrega."
  echo 
  read -p "Pulsa [Enter] para continuar"
  VAL=""
fi


echo " Generando ficheros auxiliares... "
genMata
genComparefiles
genCmpBin
rm -f mata.c
rm -f comparefiles.cc
rm -f cmpBin.cc


# función que prepara los argumentos y el fichero binario, si es necesario
function prepArgsBin ()
{
  args=""
  VAL="valgrind -q" 
  TIME=$MAXTIME
  
  if test "$1" == "p2_06_save" ; then
    VAL="" # desactivar valgrind para esta prueba
  elif test "$1" == "p2_07_param_import" ; then
    args="-i pruebas/file-import01"
  elif test "$1" == "p2_08_param_load" ; then
    args="-l pruebas/file-load01.bin"
  elif test "$1" == "p2_09_param_test" ; then
    args="-t"
  elif test "$1" == "p2_z-20_save_empty" ; then
    VAL="" # desactivar valgrind para esta prueba
  elif test "$1" == "p2_z-21_save_onlyIntents" ; then
    VAL="" # desactivar valgrind para esta prueba
  elif test "$1" == "p2_z-22_save_response_example_very_long" ; then
    VAL="" # desactivar valgrind para esta prueba
  elif test "$1" == "p2_z-23_save_big" ; then
    VAL="" # desactivar valgrind para esta prueba
  elif test "$1" == "p2_z-24_paramOk1" ; then
    args="-i pruebas/file-import05 -l pruebas/file-load01.bin -t"
  elif test "$1" == "p2_z-25_paramOk2" ; then
    args="-l /tmp/file-not-found -i pruebas/file-import01"
  elif test "$1" == "p2_z-26_paramOk3" ; then
    args="-l pruebas/file-load01.bin -i /tmp/file-not-found"
  elif test "$1" == "p2_z-27_paramOk4" ; then
    args=" -i -i -l -l -t"
   elif test "$1" == "p2_z-28_paramError1" ; then
     args="-i"
  elif test "$1" == "p2_z-29_paramError2" ; then
    args="-t pruebas/file-import01"
  elif test "$1" == "p2_z-30_paramError3" ; then
     args="-I pruebas/file-import01 -t"
  elif test "$1" == "p2_z-31_paramError4" ; then
    args="-i pruebas/file-import01 -i pruebas/file-import05 -t"
  elif test "$1" == "p2_z-32_paramError5" ; then
    args="-t -i pruebas/file-import05 -l pruebas/file-load01.bin -t"
   #cp $ENT/-b .
  fi
}


function postPrueba()
{
  if test "$1" == "zzp2cp2-importall" ; then
    rm -f ./-b
  fi
}

let npruebas=$npruebasa+$npruebasc
pok=0
nota=0


function sumarNota() # $1 es $j, el número de prueba
{
  let pok++
  if [ $1 -le $npruebasa ]; then
    nota=`echo - | awk -v K=$nota -v M=$valorpruebasa '{printf("%.4g",K+M)}'`
    #echo $nota
  else 
    nota=`echo - | awk -v K=$nota -v M=$valorpruebasc '{printf("%.4g",K+M)}'`
    #echo $nota
  fi
}


# Compilacion
echo
echo "*********************************************************"
echo " Compilando..."
echo "*********************************************************"
find . -name "*.o" ! -name converter.o -type f -delete
rm -rf $PRINCIPAL
tempfile=`mktemp /tmp/prog2iiXXXXX`
g++ -Wall -g -std=c++11 converter.o $PRINCIPAL.cc -o $PRINCIPAL 2>&1
if [ $? -ne 0 ]; then
	echo "LA PRACTICA NO COMPILA"
else
  # aviso warnings
  nlineasWarnings=$(wc --lines $tempfile | cut -f 1 -d ' ')
  if [ $nlineasWarnings -ne 0 ]; then
     cat $tempfile
     echo 
     echo "LA PRACTICA COMPILA, PERO TIENE WARNINGS, DEBES QUITARLOS"
     read -p "Pulsa [Enter] para continuar"
     echo
  fi
  

  # Ejecucion y comprobacion de la salida
  echo
  echo "*********************************************************"
  echo " Ejecutando y comprobando salida a la vez..."
  echo "*********************************************************"
#  chmod +x $mata
#  chmod +x $comparefiles

  let j=0
  for i in `ls $ENT`  
  do
       # if test "aa$i" = "aa-b" ; then   # saltar el fichero -b
       #   continue
       # fi
        bn=$(basename "$i" .txt)
        if test "$bn" = "$i" ; then 
          continue  # si no es un .txt no es un fichero de entrada
        fi

	echo -n "Prueba $bn" 

        prepArgsBin $bn

        if test "$args" != "" ; then
          echo " (argumentos:$args)"
        else
          echo 
        fi
	# Ejecucion del programa
	
#	echo "$mata $TIME $OBT/${bn}.salida-obtenida $VAL $PRINCIPAL $args < $ENT/$i > $OBT/${bn}.salida-obtenida 2> $tempfile"
	
	$mata $TIME $OBT/${bn}.salida-obtenida $VAL $PRINCIPAL $args < $ENT/$i > $OBT/${bn}.salida-obtenida 2> $tempfile
        let j++

	if test -s $tempfile; then
		echo "ERROR DE EJECUCION..."
		cat $tempfile
		rm -rf $OBT/${bn}.salida-obtenida $tempfile
	else 
		$comparefiles $OBT/${bn}.salida-obtenida $SAL/${bn}.salida-esperada
		if [ $? -ne 0 ]; then
			diff -EwB $OBT/${bn}.salida-obtenida $SAL/${bn}.salida-esperada 2>&1
		else 
                  if test "$bn" == "p2_04_export"; then
 			  $comparefiles $OBT/file-export01 $SAL/file-export01
			if [ $? -ne 0 ]; then
				diff -EwB $OBT/file-export01 $SAL/file-export01 2>&1
			else
 	  		 	echo "OK"
	   			sumarNota $j
			fi
		  elif test "$bn" == "p2_06_save"; then
 			   $cmpBin $OBT/file-save01.bin $SAL/file-save01.bin 2>&1
			if [ $? -eq 0 ]; then
 		          echo "OK"
 		          sumarNota $j
		        fi
      		  elif test "$bn" == "p2_z-13_export_intent"; then
 			  $comparefiles $OBT/file-export02 $SAL/file-export02
			if [ $? -ne 0 ]; then
				diff -EwB $OBT/file-export02 $SAL/file-export02 2>&1
			else
 		          echo "OK"
 		          sumarNota $j
		        fi
		  elif test "$bn" == "p2_z-14_export_big"; then
 			  $comparefiles $OBT/file-export03 $SAL/file-export03
			if [ $? -ne 0 ]; then
				diff -EwB $OBT/file-export03  $SAL/file-export03 2>&1
			else
 		          echo "OK"
 		          sumarNota $j
		        fi
		  elif test "$bn" == "p2_z-15_export_empty"; then
 			  $comparefiles $OBT/file-export04-empty $SAL/file-export04-empty
			if [ $? -ne 0 ]; then
				diff -EwB $OBT/file-export04-empty $SAL/file-export04-empty 2>&1
			else
 		          echo "OK"
 		          sumarNota $j
		        fi
		  elif test "$bn" == "p2_z-20_save_empty"; then
 			  $cmpBin $OBT/file-save02-empty.bin $SAL/file-save02-empty.bin
			if [ $? -eq 0 ]; then
 		          echo "OK"
 		          sumarNota $j
		        fi
		  elif test "$bn" == "p2_z-21_save_onlyIntents"; then
 			  $cmpBin $OBT/file-save03-onlyIntents.bin   $SAL/file-save03-onlyIntents.bin 2>&1
			if [ $? -eq 0 ]; then
 		          echo "OK"
 		          sumarNota $j
		        fi
		  elif test "$bn" == "p2_z-22_save_response_example_very_long"; then
 			  $cmpBin $OBT/file-save04-solution-example-verylong.bin $SAL/file-save04-solution-example-verylong.bin 2>&1
			if [ $? -eq 0 ]; then
 		          echo "OK"
 		          sumarNota $j
		        fi
		  elif test "$bn" == "p2_z-23_save_big"; then
 			  $cmpBin $OBT/file-save05-big.bin $SAL/file-save05-big.bin 2>&1
			if [ $? -eq 0 ]; then
 		          echo "OK"
 		          sumarNota $j
		        fi
	          else 
		    echo "OK"
 		    sumarNota $j
		  fi
	    fi
	fi
	postPrueba $bn
	echo "--------------------------"
  done

fi;

echo "**********************************************************"
echo " Nota final..."
echo "**********************************************************"
echo $(printf "%.4s" $(echo "scale=2; $nota" | bc -l))
#echo "scale=2; $nota" | bc -l
rm -f $tempfile
