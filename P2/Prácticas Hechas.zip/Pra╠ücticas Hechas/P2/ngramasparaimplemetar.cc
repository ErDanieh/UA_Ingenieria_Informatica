#include <iostream>
#include <cstring>

using namespace std;

int main(){ //Esto tengo que hacerlo con los tokens de cada intent para poder
            //hacerlo bien;
    string palabra;
    cout<<"Introduce la palabra: ";

    getline(cin, palabra);

    for(int i =0; i < palabra.length()-3 ; i++){
        cout<<palabra.substr(i,3)<<endl;
    }
    return 0;
}

