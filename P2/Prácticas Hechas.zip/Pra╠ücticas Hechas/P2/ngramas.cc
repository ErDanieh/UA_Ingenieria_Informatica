#include <iostream>
#include <vector>
using namespace std;

vector<string> tokenizador(string cadena)
{
  string aux;
  vector<string> tokenizada;
  stringstream ss (cadena);
  while (ss >> aux)
  {
    tokenizada.push_back(aux);
  }
  return tokenizada;
  
}

int main(){
	string cadena;
	vector<string> anas;
	
	cout << "introduce una cadena: ";
	getline(cin, cadena);

	for(int i = 0; i <= cadena.length() - 3; i++){
		// 3 caracteres desde la posicion i		
		cout << cadena.substr(i, 3) << endl;
		anas.push_back(cadena.substr(i, 3));	
	} 

	cout << "los anagramas: " << endl;
	for(int i = 0; i < anas.size(); i++){
		cout << anas[i] << endl;
	}

	return 0;
}
