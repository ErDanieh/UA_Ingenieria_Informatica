#include <iostream>
#include <cstring>
#include <vector>
#include <cctype>
#include <cstdlib>
#include <sstream>
#include <algorithm>
#include <fstream>

using namespace std;

const int KMAXTEXTS = 15;
const int KMAXTEXTL = 1000;

struct BinIntent{
	char name[KMAXTEXTS];
	unsigned numExamples;
	char response[KMAXTEXTL];
};

struct BinChatbot{
	float threshold;
	char similarity[3];
	unsigned numIntents;
};

struct Example{				// - pregunta
	int id;
	string text;			// - texto de la pregunta
	vector<string> tokens;		// - palabras que forman la pregunta
					// separadas en un vector
};

struct Intent{
	string name;			// -
	vector<Example> examples;	// - vector de preguntas...
	string response;		// - esto es la respuesta
};

struct Chatbot{
	int nextId;// id que se asignara a la siguiente
			// pregunta inicialmente 1.
	float threshold;			// umbral de similitud
	char similarity[3];			// algoritmo de similitud
	vector<Intent> intents;		// vector de respuestas.
};

string cleanString(string);

enum Error{
  ERR_OPTION,
  ERR_INTENT,
  ERR_EXAMPLE,
  ERR_RESPONSE,
  ERR_FILE,
  ERR_THRESHOLD,
  ERR_SIMILARITY,
  ERR_ARGS
}; 

const int KSIZE=10;
const string greetings[KSIZE]={
  "Hola, ¿en qué puedo ayudarte?",
  "¿Qué puedo hacer hoy por ti?",
  "Oh, gran prócer de los bits, ¿cuál es tu deseo?",
  "Buenas",
  "¿Qué quieres?",
  "¿Otra vez necesitas ayuda?",
  "¡Hola! Soy Megabot 3000. ¿En qué puedo ayudarte?",
  "Bonito día para ser Megabot 3000",
  "Pregunta sin miedo",
  "Soy todo oídos"
};


void error(Error n){
  switch(n){
    case ERR_OPTION:
      cout << "ERROR: wrong menu option" << endl;
      break;
    case ERR_INTENT:
      cout << "ERROR: wrong intent name" << endl;
      break;
    case ERR_EXAMPLE:
      cout << "ERROR: wrong example id" << endl;
      break;
    case ERR_RESPONSE:
      cout << "Lo siento, pero no tengo respuesta para eso" << endl;
      break;
    case ERR_FILE:
      cout << "ERROR: cannot open file" << endl;
      break;
    case ERR_THRESHOLD:
      cout << "ERROR: the threshold value must be between 0 and 1" << endl;
      break;
    case ERR_SIMILARITY:
      cout << "ERROR: valid values are \"jc\" (Jaccard) and \"ng\" (n-grams)" << endl;
      break;
    case ERR_ARGS:
      cout << "ERROR: invalid arguments" << endl;
  }
}

void showMainMenu(){
  cout << "1- Train" << endl
       << "2- Test" << endl
       << "3- Report" << endl
       << "4- Configure" << endl
       << "5- Import data" << endl
       << "6- Export data" << endl
       << "7- Load chatbot" << endl
       << "8- Save chatbot" << endl
       << "q- Quit" << endl
       << "Option: ";
}

void showTrainMenu(){
  cout << "1- Add intent" << endl
       << "2- Delete intent" << endl
       << "3- Add example" << endl
       << "4- Delete example" << endl
       << "5- Add response" << endl
       << "b- Back to main menu" << endl
       << "Option: ";
}

// buscamos la posicion del intent cuyo nombre sea el que le pasamos
// como parametro.
int buscarIntent(Chatbot megabot, string n){
	int pos, i;
	pos = -1;
	for(i = 0; i < (int) megabot.intents.size(); i++){
		if(megabot.intents[i].name == n){
			pos = i;
		}
	}
	return pos;
}

// 
void addIntent(Chatbot &megabot){
	string name;
	Intent nuevo;
	int pos;

	cout << "Intent name: ";
	getline(cin, name);
	nuevo.name = name;
	pos = buscarIntent(megabot, nuevo.name);
	if(pos == -1){
		megabot.intents.push_back(nuevo);
	}
	else{
		error(ERR_INTENT);
	}

}

char preguntar(){
	char r;
	do{
		cout << "Confirm [Y/N]?: ";
		cin >> r;
		cin.get();
	}while(r != 'y' && r != 'n' && r != 'Y' && r != 'N');
	return r;
}

void deleteIntent(Chatbot &megabot){
	string name;
	int pos = -1;
	char respuesta;

	cout << "Intent name: ";
	getline(cin, name);

	// Buscar el intent cuyo nombre sea name (el nombre seleccionado 
	// por el usuario)
	pos = buscarIntent(megabot, name);

	if(pos == -1){
		error(ERR_INTENT);
	}
	else{
		do{
			respuesta = preguntar();
		}while(respuesta != 'y' && respuesta != 'Y' && respuesta != 'n' && respuesta != 'N');		
		if(respuesta == 'y' || respuesta == 'Y'){
			megabot.intents.erase(megabot.intents.begin() + pos);
		}
	}
}

string soloLetrasDigitos(string text){
	string s = "";
	int i, tam;
	tam = text.length();
	for(i = 0; i < tam; i++){
		if(isalnum(text[i]) != 0 || text[i] == ' '){
			s = s + (char) tolower(text[i]);		
		}
	}
	return s;
}

string quitarEses(string text){
	int i, tam;
	string s = "";
	tam = text.length();
	for(i = 0; i < tam; i++){
		if(text[i] == 's'){
			if(i + 1 < tam){
				if(text[i + 1] != ' '){
					s = s + text[i];
				}
			}
		}
		else{
			s = s + text[i];
		}
	}
	return s;
}

void addExample(Chatbot &megabot){
	string name, text, palabra;
	Example nuevo;
	int pos;

	cout << "Intent name: ";
	getline(cin, name);
	// buscar el intent y si no esta dar error!!!
	pos = buscarIntent(megabot, name);
	if(pos == -1){
		error(ERR_INTENT);
	}	
	else{
		cout << "New example: ";
		getline(cin, text);
		while(text != "q"){
			nuevo.id = megabot.nextId;
			nuevo.text = text; // lo guardo en el example.

			text = cleanString(text); 
			text = soloLetrasDigitos(text);
			text = quitarEses(text);

			nuevo.tokens.clear(); // para quitar los del anterior example.
			stringstream ss(text);
			while(ss >> palabra){
				nuevo.tokens.push_back(palabra);
			}
			if(nuevo.tokens.size() != 0){
				megabot.intents[pos].examples.push_back(nuevo);
				megabot.nextId++;
			}
			cout << "New example: ";
			getline(cin, text);
		}
	}
}

void deleteExample(Chatbot &megabot){
	int id;
	bool enc;

	cout << "Example id: ";
	cin >> id;
	cin.get();
	enc = false;
	for(int i = 0; i  < megabot.intents.size() && !enc; i++){
		for(int j = 0; j < megabot.intents[i].examples.size() && !enc; j++){
			if(megabot.intents[i].examples[j].id == id){
				megabot.intents[i].examples.erase(megabot.intents[i].examples.begin() + j);
				enc = true;
			}
		}
	}
	if(enc == false){
		error(ERR_EXAMPLE);
	}
}

void deleteExample2(Chatbot &megabot){
	int id, pos, i, j;

	cout << "Example id: ";
	cin >> id;
	cin.get();
	pos = -1;
	for(int i = 0; i  < megabot.intents.size() && pos == -1; i++){
		for(int j = 0; j < megabot.intents[i].examples.size() && pos == -1; j++){
			if(megabot.intents[i].examples[j].id == id){
				pos = j;
			}	
		}
		if(pos != -1){
			megabot.intents[i].examples.erase(megabot.intents[i].examples.begin() + pos);
		}	
	}
	if(pos == -1){
		error(ERR_EXAMPLE);
	}
}


void addResponse(Chatbot &megabot){
	string name;
	string response;
	int pos;
	cout << "Intent name: ";
	getline(cin, name);

	pos = buscarIntent(megabot, name);
	if(pos == -1){
		error(ERR_INTENT);
	}
	else{
		cout << "New response: ";
		getline(cin, megabot.intents[pos].response);
	}
}

// g++ -g -o prac1 prac1.cc converter.o

void train(Chatbot &megabot){
	char option;
	do{
		showTrainMenu();
		cin >> option;
		cin.get();
		switch (option){ 
			case '1':
				addIntent(megabot);
			break;
			case '2':
				deleteIntent(megabot);
			break;
			case '3':
				addExample(megabot);
			break;
			case '4':
				deleteExample(megabot);
			break;
			case '5':
				addResponse(megabot);
			break;
			case 'b':
			
			break;
			default:
				error(ERR_OPTION);
		}
	}while(option!='b');
}

string limpiarCadena(string cadena){
	string text = cadena;
	text = cleanString(text); 
	text = soloLetrasDigitos(text);
	text = quitarEses(text);
	return text;
}

vector<string> extraerTokens(string cadena){
	string aux;
	stringstream ss(cadena);
	vector<string> tokens;
	while(ss >> aux){
		if(find(tokens.begin(), tokens.end(), aux) == tokens.end()){
			tokens.push_back(aux);
		}
	}
	return tokens;
}

vector<string> intersectar(vector<string> t1, vector<string> t2){
	vector<string> comunes;
	for(int i = 0; i < t1.size(); i++){
		if(find(t2.begin(), t2.end(), t1[i]) != t2.end()){
			comunes.push_back(t1[i]);
		}
	}
	return comunes;
}

// 0123
// cola

// para la posicion 0 => col
// para la posicion 1 => ola

// 4 - 3 = 1 



// "<cola, paco>" => <col, ola, pac, aco>
vector<string> tokens2ngramas(vector<string> tokens){
	// en un vector nuevo añadimos n-gramas de cada token
	vector<string> ngramas;
	string ngrama;
	// PARA CADA TOKEN
	for(int i = 0; i < tokens.size(); i++){
		// SI LA LONGITUD ES MAYOR QUE 3
		if(tokens[i].length() >= 3){
			// PARA CADA POSICION DEL TOKEN.
			for(int j = 0; j <= tokens[i].length() - 3; j++){
				// SACO UNA CADENA QUE COGE DESDE ESA POSICION 3 CARACTERES.
				ngrama = tokens[i].substr(j, 3);
				// si no estaba lo añado
				// SI NO ESTABA AUN EN EL VECTOR DE NGRAMAS, LO AÑADO AL VECTOR.
				// PODEIS USAR UNA DE LAS FUNCION QUE TENGAIS O HACER UN BUCLE A MANO
				// SI NO QUEREIS USAR find DE algorithm.
				if(find(ngramas.begin(), ngramas.end(), ngrama) == ngramas.end()){
					ngramas.push_back(ngrama);			
				} 
			}
		}
	}
	return ngramas;
}

// cadena1 = this->text
// cadena2 = text
double jaccard(string cadena1, string cadena2, string similarity){
	double s;
	string aux;
	vector<string> t1, t2, interseccion;
	cadena1 = limpiarCadena(cadena1);
	cadena2 = limpiarCadena(cadena2);
	t1 = extraerTokens(cadena1); // conjunto de palabras.
	t2 = extraerTokens(cadena2); // conjunto de palabras.
	// cuando tengo ya los tokens limpios, si es el algoritmo n-gramas convertir los tokens a N-grams
	// ANTES DE HACER LA INTERSECCION Y DESPUES DE TENER YA LOS TOKENS SIN DUPLICADOS.
	if(similarity == "ng"){
		t1 = tokens2ngramas(t1);
		t2 = tokens2ngramas(t2);
	}
	// si el algoritmo es n-gramas tenemos que hacer otra transformacion a los tokens.!!!!!!
	// si el algoritmo es n-gramas
	// t1 = tokens2ngramas(t1);
	// t2 = tokens2ngramas(t2);

	interseccion = intersectar(t1, t2);
	s = (double) interseccion.size() / (t1.size() + t2.size() - interseccion.size());
	return s;
}

void preguntar(const Chatbot &megabot, string pregunta){
	double coefActual, coefMejor;
	string response;	

	coefMejor = 0;
	for(int i = 0; i < megabot.intents.size(); i++){
		for(int j = 0; j < megabot.intents[i].examples.size(); j++){
			// se puede copiar la funcion jaccard, llamarla ngramas y añadir las lineas de los ngramas o
			// hacer lo que he hecho aqui que es añadirle un parametro y que cambie su comportamiento.
			coefActual = jaccard(pregunta, megabot.intents[i].examples[j].text, megabot.similarity);
			if(coefActual > coefMejor){
				coefMejor = coefActual;
				response = megabot.intents[i].response;			
			}
		}
	}
	if(coefMejor < megabot.threshold){
		error(ERR_RESPONSE);
	}
	else{
		if(response != ""){
			cout << ">> " << response << endl;
		}
	}

}

void test(const Chatbot &megabot){
	int position;
	string pregunta, respuesta;

	position = rand() % KSIZE;
	cout << ">> " << greetings[position] << endl;
	cout << "<< ";
	getline(cin, pregunta);
	while(pregunta != "q"){
		/// ----------------------

		preguntar(megabot, pregunta);

		// -------------------------
		cout << "<< ";	
		getline(cin, pregunta);
	}
}

// imprime la informacion almacenada....
void report(const Chatbot &megabot){
	int nExamples = 0;
	if(strcmp(megabot.similarity, "jc") == 0){
		cout << "Similarity: Jaccard" << endl;
	}
	else{
		cout << "Similarity: N-grams" << endl;
	}
	cout << "Threshold: " << megabot.threshold << endl;
	// for para imprimir los nombres de los Intents que hay en 
	// el vector megabot.intents
	for(int i = 0; i < megabot.intents.size(); i++){
		cout << "Intent: " << megabot.intents[i].name << endl;
		cout << "Response: " << megabot.intents[i].response << endl;
		for(int j = 0; j < megabot.intents[i].examples.size(); j++){
			nExamples++;			
			cout << "Example ";
			cout << megabot.intents[i].examples[j].id << ": ";
			cout << megabot.intents[i].examples[j].text << endl;
			cout << "Tokens ";
			cout << megabot.intents[i].examples[j].id << ": ";
			for(int k = 0; k < megabot.intents[i].examples[j].tokens.size(); k++){
				cout << "<" << megabot.intents[i].examples[j].tokens[k] << ">";
				if(k != megabot.intents[i].examples[j].tokens.size() - 1){
					cout << " ";
				}
			}
			cout << endl;								
		}
		// nExamples += megabot.intents[i].examples.size();
	}
	cout << "Total intents: " << megabot.intents.size() << endl;
	cout << "Total examples: " << nExamples << endl;
	cout << "Examples per intent: ";
	if(megabot.intents.size() != 0){
		cout << (double) nExamples / megabot.intents.size() << endl;
	}
	else{
		cout << 0.0 << endl;
	}
}

void configure(Chatbot &megabot){
	double halls;
	string algorithm;;
	char valhala[10];;;;


	cout << "Enter threshold: ";
	// cin >> megabot.thershold; FATAL
	cin >> halls;
	cin.get();
	if(halls >= 0 && halls <= 1){
		megabot.threshold = halls;
	}
	else{
		error(ERR_THRESHOLD);
	}

	// TODO comprobar que esta bien y si esta bien lo meteis
	// megabot.threshold, si no error
	// NO HACER DO WHILE
/*
	cout << "Enter algorithm: ";
	cin.getline(valhala, 10); // que pasa si mete mas de 10
	while(cin.get() != '\n'); // para quitar el resto de caracteres
	if(strcmp(valhala, "jc") != 0 && strcmp(valhala, "ng") != 0){
		error(ERR_SIMILARITY);
	}
	else{
		strcpy(megabot.similarity, valhala);
		// char [] => char []
	}
*/
	cout << "Enter algorithm: ";
	getline(cin, algorithm);
	if(algorithm != "jc" && algorithm != "ng"){
		error(ERR_SIMILARITY);
	}
	else{
		strcpy(megabot.similarity, algorithm.c_str());
	}
/*
	if(algorithm == "jc" || algorithm == "ng"){
		strpcy(megabot.similarity, algorithm.c_str());
		// megabot.similarity = algorithm; //char[]<=stringMAL	
	}
	else{
		error(ERR_SIMILARITY);
	}
*/
}



/*
	LEO UNA LINEA
	MIENTRAS QUEDEN LINEAS
		LEO UNA LINEA 
		MIENTRAS QUEDEN LINEAS Y LINEA[0] != '#'
			PROCESOR
			LEO UNA LINEA
		ALMACENO EL INTENT.		
*/
	
/*
	LEO UNA LINEA
	MIENTRAS QUEDEN LINEAS
		IF ES UN INTENT
			SI TENGO INTENT GUARDARLO Y CAMBIAR

		SI NO ES UN INTENT
			SI NO ES UN INTENT AÑADIRLO AL EXAMPLE

	SI TENGO UN INTENT LO GUARDO A MANO
*/

/*
// EL MAS BASICO!!
void importData(Chatbot &megabot){
	ifstream fich;
	string linea, nombreFichero;
	
	cout << "Enter filename: ";
	getline(fich, nombreFichero);
	fich.open(nombreFichero.c_str());
	if(fich.is_open()){
		// leemos la primera linea (es un intent)
		// mientras no lleguemos a final fichero
		//	- extraer la informacion del intent (name/response)
		//	- leer una linea
		//	mientras no llegue al final de fichero y no llegues a #
		//		- procesar el example
		//		- añadirlo al intent
		//		- leer una linea mas
		//	- si el intent no existe añadirlo al vector.
		//	- si el intent ya existe mostrar error.

	}
	else{
		error(ERR_FILE);
	}
}
*/

/*
void importData(Chatbot &megabot){
	ifstream fich;
	string linea, nombreFichero;
	
	cout << "Enter filename: ";
	getline(fich, nombreFichero);
	fich.open(nombreFichero.c_str());
	if(fich.is_open()){
		// leemos la primera linea (es un intent)
		// mientras no lleguemos a final fichero
		//	- extraer la informacion del intent (name/response)
		//	- comprobar si el intent ya esta.
		//	- si el intent no esta:
		//		- leer una linea
		//		mientras no llegue al final de fichero y no llegues a #
		//			- procesar el example (*)
		//			- añadirlo al intent (*)
		//			- leer una linea mas
		//		lo añadimos al vector de intents
		//	- si el intent esta:
		//		mostramos el error
		//		leer una linea
		//		mientras no llegue a final de fichero y no llegues a #
		//			leer otra linea mas
		//

	}
	else{
		error(ERR_FILE);
	}
}
*/
// con whiles.
//           iiiiiiiiiiiiiiiiiii
// linea = "#vacaciones navidad#El 24 de diciembre"
// resultado
//	iname = "vacaciones navidad"
//	iresponse = "El 24 de diciembre"
// OPCION 1.
void extraerIntent(string linea, string &iname, string &iresponse){
	int i;
	iname = "";
	i = 1;
	while(linea[i] != '#'){
		iname = iname + linea[i];
		i++;
	}
	i++; // me tengo que saltar la #
	iresponse = "";
	while(i < linea.length()){
		iresponse += linea[i];
		i++;
	}
}

// OPCION 2.
// linea = "#vacaciones navidad#El 24 de diciembre"
Intent sacarInfo(string linea){
	Intent nuevo;
	stringstream ss(linea);

	ss.get(); // leo un caracter, me salto la #
	getline(ss, nuevo.name, '#'); // esto lee hasta la # y quita la #
	getline(ss, nuevo.response);
	
	return nuevo;
}

// OPCION 3.
//	    01234x
// linea = "#vaca#El 24 de diciembre"
void sacarInfoLinea(string linea, Intent &intento){
	int x;

	x = linea.find(1, '#'); 	// devuelve la posicion de la # a partir de la posicion 1.
					// x = 5	
	intento.name = linea.substr(1, x - 1);
	intento.response = linea.substr(x + 1); // extrae desde x + 1 hasta el final :).
}

Example extraerExample(Chatbot megabot, string linea){
	Example nuevo;
	// saco la informacion de la linea
	nuevo.text = linea;
	// relleno los tokens
	// .... esto es mi codigo de addExample.

	return nuevo;
}
// OPCION 1 DE IMPORT
/*
void importData(Chatbot &megabot){
	ifstream fich;
	string linea, nombreFichero;
	string intentName, intentResponse;	
	Intent leido;
	Example example;

	// pedimos el nombre del fichero.
	cout << "Enter filename: ";
	getline(cin, nombreFichero);
	// abrimos el fichero para leer del fichero.
	fich.open(nombreFichero.c_str());
	// comprobamos si el fichero se ha abierto.
	if(fich.is_open()){
		// leemos la primera linea (es un intent)
		getline(fich, linea);
		// mientras no lleguemos a final fichero
		while(!fich.eof()){ // while(fich.eof() == false){
		//	- extraer la informacion del intent (name/response)
			extraerIntent(linea, intentName, intentResponse); // OPCION 1
			leido = sacarInfo(linea); // OPCION 2
			sacarInfoLinea(linea, leido); // OPCION 3
		//	comprobamos si el intent ya existe.
			pos = buscarIntent(megabot, intentName);
			pos = buscarIntent(megabot, leido.name); // OPCION 2
			// leemos el primer example o otro intent
			if(pos != -1){	// si ya existe el intent
				error(ERR_INTENT);
				// leer hasta el siguiente Intent
				getline(fich, linea);
				while(!fich.eof() && linea[0] != '#'){
					getline(fich, linea);
				}
			}			
			else{ // no existe el intent hay que procesar las lineas.
				getline(fich, linea);
				while(!fich.eof() && linea[0] != '#'){
					// extraerExample devuelve un Example con la informacion de la linea.
					example = extraerExample(megabot, linea); // para asignarle el id al example
										// addExample...
					if(example.tokens.size() !=  0){
						leido.examples.push_back(example);
					}
					getline(fich, linea);	
				}
				megabot.intents.push_back(leido);	
			}
			
		}
		fich.close();
	}
	else{
		error(ERR_FILE);
	}
}
*/

void importData(Chatbot &megabot){
	ifstream fich;
	string linea, nombreFichero;
	string intentName, intentResponse, palabra;	
	Intent leido;
	Example nuevo;
	int pos;

	// pedimos el nombre del fichero.
	cout << "Enter filename: ";
	getline(cin, nombreFichero);	// el nombre del fichero se lee desde consola.
	// abrimos el fichero para leer del fichero.
	fich.open(nombreFichero.c_str());
	// comprobamos si el fichero se ha abierto.
	if(!fich.is_open()){
		error(ERR_FILE);
	}
	else{	
		// leemos la primera linea (es un intent)
		getline(fich, linea);
		// mientras no lleguemos a final fichero
		while(!fich.eof()){ // while(fich.eof() == false){
			leido = sacarInfo(linea); // OPCION 2
			// leemos el primer example o otro intent
			getline(fich, linea);
			pos = buscarIntent(megabot, leido.name); 
			while(!fich.eof() && linea[0] != '#'){
				if(pos == -1){ // si no lo he encontrado los examples SI me interesan.
					// ------- copiar vuestro codigo de addExample --------- //
					nuevo.id = megabot.nextId;
					nuevo.text = linea; // lo guardo en el example.

					linea = cleanString(linea); 
					linea = soloLetrasDigitos(linea);
					linea = quitarEses(linea);

					nuevo.tokens.clear(); // para quitar los del anterior example.
					stringstream ss(linea);
					while(ss >> palabra){
						nuevo.tokens.push_back(palabra);
					}
					if(nuevo.tokens.size() != 0){
						leido.examples.push_back(nuevo);
						megabot.nextId++;
					}
				}
				// ------- fin de vuestro codigo de addExample ---------- //
				getline(fich, linea);	
			}
			// 
			// pos = buscarIntent(megabot, leido.name); 
			if(pos == -1){
				megabot.intents.push_back(leido);	
			}
			else{
				error(ERR_INTENT);
			}
			
		}
		fich.close();
	}
}


void importDataPaco(Chatbot &megabot, string nombreFichero){
	ifstream fich;
	string linea;
	string intentName, intentResponse, palabra;	
	Intent leido;
	Example nuevo;
	int pos;

	if(nombreFichero == ""){
		cout << "Enter filename: ";
		getline(cin, nombreFichero);
	}
	// abrimos el fichero para leer del fichero.
	fich.open(nombreFichero.c_str());
	// comprobamos si el fichero se ha abierto.
	if(!fich.is_open()){
		error(ERR_FILE);
	}
	else{	
		// leemos la primera linea (es un intent)
		getline(fich, linea);
		// mientras no lleguemos a final fichero
		while(!fich.eof()){ // while(fich.eof() == false){
			leido = sacarInfo(linea); // OPCION 2
			// leemos el primer example o otro intent
			getline(fich, linea);
			pos = buscarIntent(megabot, leido.name); 
			while(!fich.eof() && linea[0] != '#'){
				if(pos == -1){ // si no lo he encontrado los examples SI me interesan.
					// ------- copiar vuestro codigo de addExample --------- //
					nuevo.id = megabot.nextId;
					nuevo.text = linea; // lo guardo en el example.

					linea = cleanString(linea); 
					linea = soloLetrasDigitos(linea);
					linea = quitarEses(linea);

					nuevo.tokens.clear(); // para quitar los del anterior example.
					stringstream ss(linea);
					while(ss >> palabra){
						nuevo.tokens.push_back(palabra);
					}
					if(nuevo.tokens.size() != 0){
						leido.examples.push_back(nuevo);
						megabot.nextId++;
					}
				}
				// ------- fin de vuestro codigo de addExample ---------- //
				getline(fich, linea);	
			}
			// 
			// pos = buscarIntent(megabot, leido.name); 
			if(pos == -1){
				megabot.intents.push_back(leido);	
			}
			else{
				error(ERR_INTENT);
			}
			
		}
		fich.close();
	}
}



void importDataFile(Chatbot &megabot, string nombreFichero){
	ifstream fich;
	string linea;
	string intentName, intentResponse, palabra;	
	Intent leido;
	Example nuevo;
	int pos;

	// abrimos el fichero para leer del fichero.
	fich.open(nombreFichero.c_str());
	// comprobamos si el fichero se ha abierto.
	if(!fich.is_open()){
		error(ERR_FILE);
	}
	else{	
		// leemos la primera linea (es un intent)
		getline(fich, linea);
		// mientras no lleguemos a final fichero
		while(!fich.eof()){ // while(fich.eof() == false){
			leido = sacarInfo(linea); // OPCION 2
			// leemos el primer example o otro intent
			getline(fich, linea);
			pos = buscarIntent(megabot, leido.name); 
			while(!fich.eof() && linea[0] != '#'){
				if(pos == -1){ // si no lo he encontrado los examples SI me interesan.
					// ------- copiar vuestro codigo de addExample --------- //
					nuevo.id = megabot.nextId;
					nuevo.text = linea; // lo guardo en el example.

					linea = cleanString(linea); 
					linea = soloLetrasDigitos(linea);
					linea = quitarEses(linea);

					nuevo.tokens.clear(); // para quitar los del anterior example.
					stringstream ss(linea);
					while(ss >> palabra){
						nuevo.tokens.push_back(palabra);
					}
					if(nuevo.tokens.size() != 0){
						leido.examples.push_back(nuevo);
						megabot.nextId++;
					}
				}
				// ------- fin de vuestro codigo de addExample ---------- //
				getline(fich, linea);	
			}
			// 
			// pos = buscarIntent(megabot, leido.name); 
			if(pos == -1){
				megabot.intents.push_back(leido);	
			}
			else{
				error(ERR_INTENT);
			}
			
		}
		fich.close();
	}
}
void exportData(Chatbot megabot){
	int nExamples = 0;
	ofstream fich;
	string nombreFichero;
	char respuesta;
	string name;
	int pos;
	do{	
		cout << "Save all intents [Y/N]?: ";
		cin >> respuesta;
		cin.get();
	}while(respuesta != 'y' && respuesta != 'Y' && respuesta != 'n' && respuesta != 'N');	

	if(respuesta == 'N' || respuesta == 'n'){
		cout << "Intent name: ";
		getline(cin, name);
		pos = buscarIntent(megabot, name);
		if(pos == -1){
			error(ERR_INTENT);
		}
		else{
			// DE ESTA PARTE NO TENEIS PRUEBA.
			cout << "Enter filename: ";
			getline(cin, nombreFichero);
			fich.open(nombreFichero.c_str());	
			if(fich.is_open()){		
				fich.open(nombreFichero.c_str()); // si no existe lo crea y si existe lo sobrescribe. :)
				fich <<  "#" << megabot.intents[pos].name << "#" <<  megabot.intents[pos].response << endl;
				for(int j = 0; j < megabot.intents[pos].examples.size(); j++){
					fich << megabot.intents[pos].examples[j].text << endl;								
				}
				fich.close();
			}
			else{
				error(ERR_FILE);
			}
		}
	}
	else{
		cout << "Enter filename: ";
		getline(cin, nombreFichero);	
		fich.open(nombreFichero.c_str()); // si no existe lo crea y si existe lo sobrescribe. :)
		if(fich.is_open()){
			for(int i = 0; i < megabot.intents.size(); i++){
				fich <<  "#" << megabot.intents[i].name << "#";
				fich <<  megabot.intents[i].response << endl;
				for(int j = 0; j < megabot.intents[i].examples.size(); j++){
					fich << megabot.intents[i].examples[j].text << endl;								
				}
			}
			fich.close();
		}
		else{
			error(ERR_FILE);
		}
	}
}
//         i           i           i
// ./prac2 -l data.bin -i data.txt -t
// ./prac2 -i data.txt -t
// ./prac2 -i data.txt -t -l data.bin


string limpiarStr(string text){
	string strLimpio = "";
	int i, tam;
	tam = text.length();
	for(i = 0; i < tam; i++){
		if(text[i] == ' ' || isalnum(text[i])){
			if(text[i] == 's'){
				if((i + 1) < tam){
					if(isalnum(text[i + 1]) != 0){
						strLimpio += (char)tolower(text[i]);
					}
				}
			}
			else{
				strLimpio += (char)tolower(text[i]);
			}		
		}
	}
	return strLimpio;
}


// TODO
// comprobar que las opciones son correctas, -i -l -t
// comprobar que no se repiten (no puede aparacer una opcion mas de una vez)
// comprobar que el nombre de fichero esta.......
// ./prac2 -t -t -i pruebas/file-import0
bool procesarArgumentos(int argc, char *argv[], string &nb, string &nt, bool &t){
	bool correctos;
	int i;

	// para comprobar si los argumentos estan repetidos.
/*	int vecest, vecesi, vecesl, otras;
	vecest = 0;
	vecesi = 0;
	vecesl = 0;
	otras = 0;
	for(i = 1; i < argc; i++){
		if(strcmp(argv[i], "-t") == 0){
			vecest++;
		}
		else{
			if(strcmp(argv[i], "-l") == 0){
				vecesl++;
				i++;
			}
			else{
				if(strcmp(argv[i], "-i") == 0){
					vecesi++;
					i++;
				}
				else{
					otras++;
				}
			}
		}
	}
	if(vecest > 1 || vecesi > 1 || vecesl > 1 || otras != 0){
		correctos = false;	
	}
*/
	nb = "";	// si no cambian es que no estaba la opcion.
	nt = "";	// si no cambian es que no estaba la opcion.
	t = false;
	correctos = true;
	for(i = 1; i < argc; i++){
		if(strcmp(argv[i], "-t") == 0){
			if(t == true){ // ya la he encontrado otra vez.
				correctos = false;
			}
			else{
				t = true;
			}
		}
		else{
			if(strcmp(argv[i], "-i") == 0){
				if(nt != ""){
					correctos = false;
				}			
				else{	
					if(i + 1 < argc){
						nt = argv[i+1];
						i++;
					}
					else{
						correctos = false;
					}
				}
			}
			else{
				if(strcmp(argv[i], "-l") == 0){
					if(nb != ""){
						correctos = false;
					}			
					else{	
						if(i + 1 < argc){
							nb = argv[i+1];
							i++;
						}
						else{
							correctos = false;
						}
					}
				}
				else{
					correctos = false;
				}
			}
		}

	}

	return correctos;
}

void saveChatbot(Chatbot megabot){
	BinChatbot bcb;
	BinIntent bi;
	ofstream fich;
	string name;
	char texto[KMAXTEXTL];
	
	cout << "Enter filename: ";
	getline(cin, name);

	fich.open(name.c_str(), ios::binary);
	if(fich.is_open()){
		bcb.numIntents = megabot.intents.size();
		bcb.threshold = megabot.threshold;
		strcpy(bcb.similarity, megabot.similarity); 
		fich.write((const char *) &bcb, sizeof(bcb));
		for(int i = 0; i < megabot.intents.size(); i++){
			bi.numExamples = megabot.intents[i].examples.size();
			strncpy(bi.name, megabot.intents[i].name.c_str(), KMAXTEXTS);
			bi.name[KMAXTEXTS - 1] = '\0';
			strncpy(bi.response, megabot.intents[i].response.c_str(), KMAXTEXTL);
			bi.response[KMAXTEXTL - 1] = '\0';
			fich.write((const char *) &bi, sizeof(bi));
			for(int j = 0; j < megabot.intents[i].examples.size(); j++){
				strncpy(texto, megabot.intents[i].examples[j].text.c_str(), KMAXTEXTL);
				texto[KMAXTEXTL - 1] = '\0';
				fich.write((const char *) texto, sizeof(char) * KMAXTEXTL);
			}
		}
		fich.close();
	}
	else{
		error(ERR_FILE);
	}

}

void loadChatbot(Chatbot &megabot, string nombreFichero){
	char respuesta;
	ifstream fich;
	bool p;	
	BinChatbot bcb;
	BinIntent bi;
	Intent nuevoIntent;
	Example nuevoExample;
	char texto[KMAXTEXTL];
	string palabra;
	
	if(nombreFichero == ""){
		// vengo desde el menu principal
		cout << "Enter filename: ";
		getline(cin, nombreFichero);
		p = true;	
	}
	else{
		p = false;
	}
	fich.open(nombreFichero.c_str(), ios::binary);
	if(fich.is_open()){
		if(p == true){
			respuesta = preguntar();
		}
		else{
			respuesta = 'y';
		}
		if(respuesta == 'y' || respuesta == 'Y'){
			megabot.intents.clear();
			fich.read((char *) &bcb, sizeof(bcb));
			megabot.threshold = bcb.threshold;
			megabot.nextId = 1;
			strcpy(megabot.similarity, bcb.similarity);
			for(int i = 0; i < bcb.numIntents; i++){
				fich.read((char *) &bi, sizeof(bi));
				nuevoIntent.examples.clear();
				nuevoIntent.name = bi.name; // string = char[]
				nuevoIntent.response = bi.response; // string = char []
				for(int j = 0; j < bi.numExamples; j++){
					fich.read((char *) texto, sizeof(char) * KMAXTEXTL);
					nuevoExample.text = texto; // string = char []
					nuevoExample.id = megabot.nextId++;
					nuevoExample.tokens.clear();
					// copiar el codigo de addExample o de importFile que tokeniza
					string linea = cleanString(texto); 
					linea = soloLetrasDigitos(linea);
					linea = quitarEses(linea);
					stringstream ss(linea);
					while(ss >> palabra){
						nuevoExample.tokens.push_back(palabra);
					}
					///////////////////////////////////////////
					nuevoIntent.examples.push_back(nuevoExample);
				}
				megabot.intents.push_back(nuevoIntent);
			}
			fich.close();
		}
	}
	else{
		error(ERR_FILE);	
	}
	
}

int main(int argc, char *argv[]){
	Chatbot megabot;
	megabot.nextId=1;
	megabot.threshold=0.25;
	strcpy(megabot.similarity,"jc");
	bool correcto, t;
	string nt, nb;
	srand(666);
	char option;

	correcto = procesarArgumentos(argc, argv, nb, nt, t);
	if(!correcto){
		error(ERR_ARGS);
	}
	else{
		// como se si tengo que leer el fichero binario
		if(nb != ""){
			loadChatbot(megabot, nb);		
		}
		// como se si tengo que leer el fichero de texto
		if(nt != ""){
			// importData(megabot); //??¿?¿?¿?¿?¿
			// importDataFile(megabot, nt);
			importDataPaco(megabot, nt);
		}
		// como se si tengo activada -t
		if(t == true){
			test(megabot);
		}
		do{
			showMainMenu();
			cin >> option;
			cin.get();
			switch (option){ 
				case '1':
					train(megabot);
				break;
				case '2':
					test(megabot);
				break;
				case '3':
					report(megabot);
				break;
				case '4':
					configure(megabot);
				break;
				case '5':
					// importData(megabot);
					importDataPaco(megabot, "");
				break;
				case '6':
					exportData(megabot);
				break;
				case '7':
					loadChatbot(megabot, "");
				break;
				case '8':
					saveChatbot(megabot);
				break;
				case 'q':
				break;
				default:
			error(ERR_OPTION);
			}
		}while(option!='q');
	}
	return 0;
}

