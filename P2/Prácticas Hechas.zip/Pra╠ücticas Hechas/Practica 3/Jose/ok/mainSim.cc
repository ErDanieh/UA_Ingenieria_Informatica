#include <iostream>
#include "Intent.h"
#include "Example.h"
using namespace std;


int main(){
	Intent intento("tengo sueño");

	intento.addExample(Example("las cosas de las negras"));
	intento.addExample(Example("las cosas son azules"));
	intento.addExample(Example("los costos de los buenos"));
	intento.addExample(Example("la maria es de flores"));

	cout << intento << endl;
	
	float s = intento.calculateSimilarity("las cosas negras", "jc"); // 3/(4 + 3 - 3) = 0.75
	cout << s << endl;

	s = intento.calculateSimilarity("la maria es mia", "jc"); // 3/(5 + 4 - 3) => 0.5
	cout << s << endl;	

	
	return 0;
}
