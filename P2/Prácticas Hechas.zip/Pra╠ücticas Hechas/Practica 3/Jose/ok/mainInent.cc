#include "Example.h"
#include "Intent.h"
#include "Util.h"

int main(){
	Example examples[] = {	Example("las cosas del amor"),
				Example("el atharito esta loco"),
				Example("vivan las cosas azules"),
				Example("las cosicas de clases")
				};
	cout << "-------------------------" << endl;
	for(int i = 0; i < 4; i++){
		cout << examples[i] << endl;
	}
	cout << "-------------------------" << endl;


	Intent intento1("lunes");
	cout << intento1 << endl; // llama al operador salida

	intento1.addResponse("es porque es lunes");
	
	cout << intento1 << endl;


	for(int i = 0; i < 4; i++){
		intento1.addExample(examples[i]); //this = &intento1
	}

	Intent intento2("martes");
	intento2.addExample(examples[0]);	// this = &intento2

	Example otros[] = {
		Example("Cual es el mejor lenguaje?"),
		Example("Que lenguaje es mejor?"),
		Example("En que programo para empezar?"),
		Example("Cual es el mejor lenguaje en C++"),
		Example("Que es mejor el pollo o la ternera?"),
		Example("Si me deprimo en que programo?"),
		Example("Este no va a entrar")
	};
	for(int i = 0; i < 7; i++){
		try{
			intento1.addExample(otros[i]);
			cout << "Añadido example: " << otros[i].getId()	<< endl;	
		}
		catch(Error &e){ // e = ERR_MAXEXAMPLES
			// Esta dentro de la clase Util y es static.
			Util::error(e); // imprime el error del valor lanzado.
		}
	}
	cout << intento1 << endl;


	intento1.deleteExample(3);
	cout << intento1 << endl;

	int borrados[] = {1, 5, 4, 6, 3, 8, 2};
	for(int i = 0; i < 7; i++){
		try{
			intento1.deleteExample(borrados[i]);
			cout << "borrado example: " << i << endl;
		}
		catch(Error &e){
			Util::error(e);
			cout << "Al borrar " << borrados[i] << endl;
		}
	}
	cout << intento1 << endl;



	



	


		
	return 0;
}
