#include <vector>
#include <iostream>
#include <cstdlib>
using namespace std;

#include "Util.h"

int main(){
	vector<string> tokens;

	tokens = Util::extractTokens("las cosas de los nazis no son buenas");

	for(int i = 0; i < tokens.size(); i++){
		cout << tokens[i] << endl;
	}
	
	srand(2);

	cout << Util::welcome() << endl;


	return 0;
}
