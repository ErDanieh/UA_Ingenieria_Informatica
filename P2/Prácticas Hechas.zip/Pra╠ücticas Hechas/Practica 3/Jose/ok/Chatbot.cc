#include "Chatbot.h"
#include "Util.h"
#include <iostream>
#include <sstream>
using namespace std;

Chatbot::Chatbot(){
	threshold = 0.25;
	strcpy(similarity, "jc");
}

Chatbot::Chatbot(float threshold, const char similarity[]){
	if(threshold < 0 || threshold > 1){
		throw ERR_THRESHOLD;
	}
	if(strcmp(similarity, "jc") != 0 && strcmp(similarity, "ng") != 0){
		throw ERR_SIMILARITY;
	}
	this->threshold = threshold;
	strcpy(this->similarity, similarity);
}
/*
Chatbot::Chatbot(float threshold, const char similarity[]){
	if(threshold < 0 || threshold > 1){
		throw ERR_THRESHOLD;
	}
	//else{
		this->threshold = threshold;
	//}
	if(strcmp(similiarity, "jc") != 0 && strcmp(similarity, "ng") != 0){
		throw ERR_SIMILARITY;
	}
	//else{
		strcmp(this->similarity, similarity);
	//}
}
Chatbot::Chatbot(float threshold, const char similarity[]){
	if(threshold >= 0 && threshold <= 1){
		this->threshold = threshold;
	}
	else{
		throw ERR_THRESHOLD;
	}
	if(strcmp(similiarity, "jc") != 0 || strcmp(similarity, "ng") == 0){
		strcmp(this->similarity, similarity);
	}
	else{
		throw ERR_SIMILARITY;
	}
}
*/

float Chatbot::getThreshold() const{
	return threshold;
}

string Chatbot::getSimilarity() const{
	return similarity;
}

int Chatbot::searchIntent(string name) const{
	int i, pos;
	pos = -1;
	for(i = 0; i < intents.size() && pos == -1; i++){
		// if(intents[i].name == name){
		// if(intents[i]->name == name){		
		if(intents[i]->getName() == name){		
			pos = i;
		}
	}
	return pos;
}

bool Chatbot::addIntent(Intent *pIntent){
	bool added = false;
	int pos;	

	if(pIntent != NULL){
		pos = searchIntent(pIntent->getName()); // llamo a la de arriba.
		if(pos != -1){
			Util::error(ERR_INTENT);
		}
		else{
			added = true;
			intents.push_back(pIntent); // guardo la dir. en dirs
		}
	}

	return added;
}

bool Chatbot::deleteIntent(string name, bool askConfirm){
	bool deleted = false;
	int pos;
	char respuesta;

	if(name == ""){
		cout << "Intent name: ";
		getline(cin, name);
	}
	pos = searchIntent(name);
	// CUIDADIN!!!! CON LO QUE VIENE!! HASEDLO VOSOTROS.
	if(pos == -1){
		Util::error(ERR_INTENT);
	}
	else{
		respuesta = 'y';
		if(askConfirm == true){
			// esto cogerlo de la practica 1.
			// NO COPIAR!			
			do{
				cout << "Confirm (Y/N)?: ";
				cin >> respuesta;
				cin.get();			
			}while(tolower(respuesta) != 'y' && tolower(respuesta) != 'n');
		}
		//else{
		//	respuesta = 'y';
		//}
		if(respuesta == 'y' || respuesta == 'Y'){
			intents.erase(intents.begin() + pos);
			deleted = true;
		}
	}
	return deleted;
}

bool Chatbot::addExample(string name){
	bool added = false;
	int pos;
	string text;

	if(name == ""){
		cout << "Intent name: ";
		getline(cin, name);
	}
	pos = searchIntent(name);
	if(pos == -1){
		Util::error(ERR_INTENT);
	}
	else{
		// El bucle sacarlo de vuestra practica,
		// el control del bucle.
		cout << "New example: ";
		getline(cin, text);
		while(text != "q"){
			////////////////////////////////
			// cuerpo es este si o si...
			try{
				Example e(text);
				intents[pos]->addExample(e);
				added = true;
				// n++; (para saber si he metido alguno)
			}
			catch(Error &e){
				Util::error(e);
			}
			////////////////////////////
			cout << "New example: ";
			getline(cin, text);	
		}
	}

	return added;
}

bool Chatbot::deleteExample(int id){
	bool deleted = false;
	if(id == 0){
		cout << "Example id: ";
		cin >> id;
		cin.get();
	}
	for(int i = 0; i < intents.size() && deleted == false; i++){
		// no podeis acceder directamente a los examples del intent
		try{
			intents[i]->deleteExample(id);
			deleted = true; // trompo el bucle porque no se va
			// al catch, porque lo ha conseguido borrar
		}
		catch(Error &e){
			// no puedo sacar el error, porque si no
			// en cada intent que no lo encuentra
			// sacaria error
		}
	}
	if(!deleted){
		Util::error(ERR_EXAMPLE);
	}
	return deleted;
}

bool Chatbot::addResponse(string name, string response){
	bool added = false;
	int pos;
	
	if(name == ""){
		cout << "Intent name: ";
		getline(cin, name);
	}
	if(response == ""){
		cout << "New response: ";
		getline(cin, response);
	}
	pos = searchIntent(name);
	if(pos == -1){
		Util::error(ERR_INTENT);
	}
	else{
		added = true;
		intents[pos]->addResponse(response);
	}

	return added;
}

string Chatbot::bestResponse(string query, bool debug) const{
	string best = "";
	float bestValue = 0, currentlyValue;
	
	// recorremos los intents y nos quedamos con el mejor intent.
	for(int i = 0; i < intents.size(); i++){
		currentlyValue = intents[i]->calculateSimilarity(query, similarity);
		if(currentlyValue > bestValue){
			bestValue = currentlyValue;
			best = intents[i]->getResponse();
		}
	}
	if(bestValue < threshold){
		throw ERR_RESPONSE;
	}
	if(debug == true){
		stringstream ss;
		// lo meto todo al buffer.
		ss << "(" << bestValue << ")" << best;
		best = ss.str(); // devuelvo un string con el 
		// contenido del buffer
	}
	return best;	
}

void Chatbot::test(bool debug){
	string query, response;
	cout << ">> " << Util::welcome() << endl;
	cout << "<< ";
	getline(cin, query);
	while(query != "q"){
		try{
			response = bestResponse(query, debug);
			cout << ">> " << response << endl;
		}
		catch(Error &e){
			Util::error(e);
		}
		cout << "<< ";
		getline(cin, query);
	}
}

void Chatbot::configure(float threshold, const char similarity[]){
	// copiar vuestro configure de la practica 2.
	double halls;
	string algorithm;
	
	if(threshold == -1){
		cout << "Enter threshold: ";
		cin >> halls;
		cin.get();
	}
	else{
		halls = threshold;
	}
	if(halls >= 0 && halls <= 1){
		threshold = halls;
	}
	else{
		Util::error(ERR_THRESHOLD);
	}
	if(similarity == ""){
		cout << "Enter algorithm: ";
		getline(cin, algorithm);
	}
	else{
		algorithm = similarity;
	}
	if(algorithm != "jc" && algorithm != "ng"){
		Util::error(ERR_SIMILARITY);
	}
	else{
		strcpy(this->similarity, algorithm.c_str());
	}

}

ostream &operator<<(ostream &os, const Chatbot &c){
	int numExamples = 0;
	os << "Similarity: ";
	if(strcmp(c.similarity, "jc") == 0){
		os << "Jaccard" << endl;
	}
	else{
		os << "N-grams" << endl;
	}
	os << "Threshold: " << c.threshold << endl;
	for(int i = 0; i < c.intents.size(); i++){
		os << *(c.intents[i]);
		// numExamples += c.intents[i]->examples.size();
		numExamples += c.intents[i]->getNumExamples(); 
	}
	os << "Total intents: " << c.intents.size() << endl;
	os << "Total examples: " << numExamples << endl;
	os << "Examples per intent: ";
	if(c.intents.size() != 0){
		os << (double) numExamples / c.intents.size();
	}
	else{
		os << 0;
	}
	return os;
}




