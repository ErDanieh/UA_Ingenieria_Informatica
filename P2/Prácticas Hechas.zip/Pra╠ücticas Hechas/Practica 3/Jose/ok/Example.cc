#include "Example.h"
#include "Util.h"
#include <algorithm>

int Example::nextId = 1;
/*
Example::Example(string text){
	if(text == ""){
		throw ERR_EMPTY;
	}
	else{
		tokens = Util::extractTokens(text);	
		if(tokens.size() == 0){ // tokens.empty()
			throw ERR_EMPTY;
		}
		else{
			this->id = nextId;
			nextId++; // tiene que estar debajo de la excepcion
			this->text = text;
		}
	}
}
*/

Example::Example(string text){
	this->text = text;
	tokens = Util::extractTokens(text);
	if(tokens.size() == 0){
		throw ERR_EMPTY;
	}
	id = nextId++;
}

void Example::resetNextId(){
	nextId = 1;
}

string Example::getText() const{
	return text;
}

int Example::getId() const{
	return id;
}

vector<string> Example::getTokens() const{
	return tokens;
}


vector<string> Example::intersectar(vector<string> t1, vector<string> t2) const{
	vector<string> comunes;
	for(int i = 0; i < t1.size(); i++){
		if(find(t2.begin(), t2.end(), t1[i]) != t2.end()){
			comunes.push_back(t1[i]);
		}
	}
	return comunes;
}

vector<string> Example::quitarDuplicados(vector<string> tokens) const{
	vector<string> sd;
	for(int i = 0; i < tokens.size(); i++){
		if(find(sd.begin(), sd.end(), tokens[i]) == sd.end()){
			sd.push_back(tokens[i]);
		}
	}
	return sd;
}

float Example::jaccardSimilarity(string text) const{
	// this->tokens
	vector<string> tokensParametro;
	vector<string> interseccion;
	vector<string> t1, t2;
	float s;

	tokensParametro = Util::extractTokens(text);

	// quitar los duplicados de this->tokens
	// quitar los duplicados de tokenText

	t1 = quitarDuplicados(tokens);
	t2 = quitarDuplicados(tokensParametro);	

	interseccion = intersectar(t1, t2);
	s = (float) interseccion.size() / (t1.size() + t2.size() - interseccion.size());
	return s;
}
vector<string> Example::tokens2ngramas(vector<string> tokens) const{
	vector<string> ngramas;
	string ngrama;
	for(int i = 0; i < tokens.size(); i++){
		if(tokens[i].length() >= 3){
			for(int j = 0; j <= tokens[i].length() - 3; j++){
				ngrama = tokens[i].substr(j, 3);
				if(find(ngramas.begin(), ngramas.end(), ngrama) == ngramas.end()){
					ngramas.push_back(ngrama);			
				} 
			}
		}
	}
	return ngramas;
}


float Example::ngramSimilarity(string text) const{
	// this->tokens
	vector<string> tokensParametro;
	vector<string> interseccion;
	vector<string> t1, t2;
	float s;

	tokensParametro = Util::extractTokens(text);

	// quitar los duplicados de this->tokens
	// quitar los duplicados de tokenText
	t1 = quitarDuplicados(tokens);
	t2 = quitarDuplicados(tokensParametro);	

	t1 = tokens2ngramas(t1);
	t2 = tokens2ngramas(t2);

	interseccion = intersectar(t1, t2);
	s = (float) interseccion.size() / (t1.size() + t2.size() - interseccion.size());
	return s;
}

// os es como si fuera cout
ostream &operator<<(ostream &os, const Example &e){
	os << "Example " << e.id << ": " << e.text << endl;
	os << "Tokens " << e.id << ": ";	
	for(int i = 0; i < e.tokens.size(); i++){
		os << "<" << e.tokens[i] << "> ";
	}
	return os;
}
















