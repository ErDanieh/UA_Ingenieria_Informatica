#include <iostream>
#include "Example.h"
using namespace std;

int main(){
	Example e("casa casera");	// cas asa ase ser era
	float s;

	s = e.ngramSimilarity("pasajeran"); // pas asa saj aje jer era ran

	cout << s << endl; // 2 / (5 + 7 - 2) => 2 / 10 = 0.2
	
	// esteo utiliza el operado salida del Example
	cout << e << endl;

	return 0;
}
