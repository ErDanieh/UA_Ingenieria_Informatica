#ifndef _EXAMPLE_
#define _EXAMPLE_
#include <iostream>
#include <vector>
using namespace std;

class Example{
	friend ostream &operator<<(ostream &os, const Example &e);
	private:
		int id;
		string text;
		vector<string> tokens;
		static int nextId;
		vector<string> quitarDuplicados(vector<string> tokens)const;
		vector<string> intersectar(vector<string> t1, vector<string> t2)const;
		vector<string> tokens2ngramas(vector<string> tokens) const;
	public:
		Example(string text);
		static void resetNextId();
		string getText() const;
		int getId() const;
		vector<string> getTokens() const;
		float jaccardSimilarity(string text) const;
		float ngramSimilarity(string text) const;

		
};
#endif
