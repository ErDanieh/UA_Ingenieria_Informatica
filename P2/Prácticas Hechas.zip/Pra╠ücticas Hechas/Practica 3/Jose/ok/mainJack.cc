#include <iostream>
#include "Example.h"
#include "Util.h"
using namespace std;

int main(){
	Example e("las casas de las abuelas"); // la casa de abuela

	float s = e.jaccardSimilarity("la la la casa"); // la casa

	cout << s << endl; // 2/(4 + 2 - 2) = 0.5

	return 0;
}
