#include "Intent.h"
#include "Util.h"
#include <cstring>

// la misma constante para todos los objetos.
const unsigned Intent::KMAXEXAMPLES = 10;

Intent::Intent(string name){
	// da igual el orden porque si se lanza la excepcion el constructor
	// se cancela y el objeto no se crea, asi que da igual lo que
	// le haya asignado.
	this->name = name;
	response = "";	
	if(name.empty()){
		throw ERR_EMPTY;
	}
	// el vector de examples se inicializa solo, el constructor
	// invoca a los constructores de los objetos que contiene.
	this->examples.clear(); // no hace falta.
}

//Intent::Intent(string name):name(name), reponse(""){
//	if(name.empty()){
//		throw ERR_EMPTY;
//	}
//}


string Intent::getName() const{
	return name;
}

string Intent::getResponse() const{
	return response;
}

vector<Example> Intent::getExamples() const{
	return examples;
}

unsigned Intent::getNumExamples() const{
	return examples.size();
}

// el example ya viene creado e inicializado con su id.
//void Intent::addExample(const Example &example){
//	if(examples.size() < KMAXEXAMPLES){
//		examples.push_back(example);
//	}
//	else{
		// paramos la ejecucion del metodo lanzando la excepcion.
//		throw ERR_EXAMPLE;
//	}
//}

void Intent::addExample(const Example &example){
	if(examples.size() == KMAXEXAMPLES){
		throw ERR_MAXEXAMPLES;
	}
	examples.push_back(example); // this->examples.push_back(example)
}
/*
void Intent::deleteExample(int id){
	// buscar en  el vector de examples y si lo encuentro lo elimino.
	int i, pos;
	pos = -1;
	for(i = 0; i < examples.size() && pos == -1; i++){
		// if(examples[i].id == id){ // protected y no accesible
		if(examples[i].getId() == id){
			pos = i;
		}
	}	
	if(pos == -1){
		throw ERR_EXAMPLE;
	}
	examples.erase(examples.begin() + pos);
}
*/

// buscamos en el Intent implicito
int Intent::searchId(int id) const{
	int pos, i;
	pos = -1;
	for(i = 0; i < examples.size() && pos == -1; i++){
		if(examples[i].getId() == id){
			pos = i;
		}
	}
	return pos;
}

void Intent::deleteExample(int id){
	int pos;
	pos = searchId(id); // pos = this->searchId(id);
	if(pos == -1){
		throw ERR_EXAMPLE;
	}
	examples.erase(examples.begin() + pos);
}

void Intent::addResponse(string response){
	this->response = response;
}

float Intent::calculateSimilarity(string text,const char similarity[]) const{
	float s, sact;
	
	s = 0;
	for(int i = 0; i < examples.size(); i++){
		if(strcmp(similarity, "jc") == 0){
			sact = examples[i].jaccardSimilarity(text);
		}
		else{
			sact = examples[i].ngramSimilarity(text);
		}
		if(sact > s){
			s = sact;
		}
	}
	return s;
}

ostream &operator<<(ostream &os, const Intent &intent){
	// podemos acceder a la parte privada del intent porque es amiga.
	os << "Intent: " << intent.name << endl;
	os << "Response: " << intent.response << endl;
	for(int i = 0; i < intent.examples.size(); i++){
		// llama al operador salida del example
		os << intent.examples[i] << endl;
	}
	return os;
}






