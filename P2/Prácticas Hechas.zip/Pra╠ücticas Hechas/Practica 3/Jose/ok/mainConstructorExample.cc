#include <iostream>
#include <vector>
#include "Util.h"
#include "Example.h"
using namespace std;

void imprimir(const vector<string> &tokens){
	for(int i = 0; i < tokens.size(); i++){
		cout << tokens[i] << " ";
	}
	cout << endl;
}

int main(){
	Example e("las cadenas buenas");
	vector<string> tokens;

	tokens = e.getTokens(); // llama el getTokens de Example por e es de tipo Example.
	imprimir(tokens);


	try{
		Example e("");
		cout << "esta mal 1" << endl;	
	}
	catch(Error &e){
		cout << "tokens vacios 1" << endl;
	}

	try{
		Example e(" s    s     s   s");
		cout << "esta mal 2" << endl;	
	}
	catch(Error &e){
		cout << "tokens vacios 2" << endl;
	}
	
	try{
		Example e("               ");
		cout << "esta mal 3" << endl;	
	}
	catch(Error &e){
		cout << "tokens vacios 3" << endl;
	}

}
