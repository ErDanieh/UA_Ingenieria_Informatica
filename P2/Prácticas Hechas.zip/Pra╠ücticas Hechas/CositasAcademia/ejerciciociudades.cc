#include <iostream>
#include <cctype>
#include <cstring>
#include <cstdlib>
#include <vector>
#include <sstream>

using namespace std;

struct Ciudad
{
    string nombre;
    int poblacion;
};

enum Error{ERR_CIUDAD, ERR_VACIA};

void showmenu(){
    cout<<"Nueva ciudad"<<endl;
    cout<<"Introducir lista de ciudades"<<endl;
    cout<<"Mostrar ciudades"<<endl;
    cout<<"Salir"<<endl;
    cout<<"opcion: ";
}

int searchPos(vector<Ciudad> &ciudades, string nombre){
    int i;
    int pos;

    for(i= 0; i < ciudades.size() && pos==-1; i++){
        if(ciudades[i].nombre==nombre){
            pos=i;
        }
    }
    return pos;
}

void error(Error e){
    switch (e)
    {
    case ERR_CIUDAD:
     cout<<"CIUDAD DUPLICADA"<<endl;
        break;
    case ERR_VACIA:
     cout<<"NO HAY CIUDADES"<<endl;
    default:
        break;
    }
}

void nuevaCiudad(vector<Ciudad> &ciudades){
    Ciudad nueva;
    int pos;

    cout<<"Nueva ciudad: ";
    getline(cin, nueva.nombre, ','); //El tercer parametro es donde se va a acabar 
    cin>>nueva.poblacion;
    if(pos != -1){
        error(ERR_CIUDAD);
    }else{
        ciudades.push_back(nueva);
        cout<<"Ciudad"<<nueva.nombre<<"dada de alta"<<endl;
    }

}

void nuevasCiudades(vector<Ciudad> &ciudades){
    Ciudad nueva;
    string entrada;
    int pos;
    cout<<"Nueva ciudades: ";
    getline(cin,entrada);
    stringstream ss(entrada);
    do{
        getline(ss, nueva.nombre,',');
        ss>>nueva.poblacion;
        ss.get(); //Esto es para quitar el ;
        pos=searchPos(ciudades, nueva.nombre);
        if(pos==-1){
            ciudades.push_back(nueva);
        }
    }while(!ss.eof());
}

void mostrarCiudades(vector<Ciudad> &ciudades){
    int i;
    if (ciudades.size()==0){
        error(ERR_VACIA);
    }else{
        for(int i= 0; i < ciudades.size(); i++){
            cout<<"["<<i+1<<"] ";
            cout<<ciudades[i].nombre<<":";
            cout<<ciudades[i].poblacion<<endl;
        }
    }
}

int main(){
    int opc;
    vector<Ciudad> ciudades;
    do{
        showmenu();
        cin>>opc;
        switch (opc)
        {
        case 1:
            nuevaCiudad(ciudades);
            break;
        case 2:
            mostrarCiudades(ciudades);
            break;
        
        default:
            break;
        }
    }while(opc!=4);
    
}