#include <iostream>
#include <vector>
#include <cstring>


using namespace std;

int main(){
    string s ="jose";
    
    s = "pepe manolo"

    cout<<s<<endl;
    cout<<s.length()<<endl;

    string s2 = "se nos va";

    cout<<s2.length()<<endl;

    s= "si";

    if(s=="si"){
        cout<<"Ha dicho que si al corona"<<endl;

    }

    cout<<"Dime tu nombre" <<endl;
    getline(cin, s);
    cout<<s<<endl;

    s="matarlos que ";
    s= s + "no se callan";

    cout<<s<<endl;

    int  i;

    for(i=0; s.length(); i++){
        cout<<s[i];
    }
    cout<<endl;
}