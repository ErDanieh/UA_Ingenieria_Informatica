#include <iostream>
#include <vector>
#include <string.h>

using namespace std;

string buscarCampo(string cadena, string campos){
    int pos, desde, hasta;
    string r;

    pos=cadena.find(campos);
    desde=pos+ campos.length();

    hasta = cadena.find(";", desde);

    r=cadena.substr(desde, hasta - desde);

    return r;
}

int main(){
    string cadena="nombre:jose;edad:23;telefono:6666666";
    int ps;

    ps=buscarCampo(cadena, "edad");
    cout<<ps<<endl;

    return 0;

}