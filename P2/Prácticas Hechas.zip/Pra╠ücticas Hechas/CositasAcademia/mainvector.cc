#include <iostream>
#include <vector>

using namespace std;

void menu(){
	cout<<"1.nuevo elemento"<<endl;
	cout <<"2. Imprimir vector"<<endl;
	cout <<"3. Salir"<<endl;
	cout <<"Opcion: ";

}

int main(){
	int op;
	vector<int> elementos;
	int nuevo;

	menu();
	cin>>op;
	switch(op){
		case 1: 
			cout<<"Nuevo Valor: "
			cin>>nuevo;
			elementos.push_back(nuevo);
			break;
		case 2:
			if(elementos.size()==0){
				cout<<" no hay elementos"<<endl;

			}else{
				for(int i =0; i< elementos.size(); i++){
					cout<<elementos[i]<<" ";
				}
				cout<<endl;
			}
		case 3:
			break;
	}


}