#include <iostrea>
#include <vector>
#include <cstring>

using namespace std;

void imprimir(vector<string>nombres){
    cout<<"[";
    for (int i = 0; i < nombres.size(); i++){
        cout<<'"'<<nombres[i]<<'"';
            if(nombres.size()-1){
                cout<<", ";
            }
    }
    cout<<"]"<<endl;
}



int main(){
    vector<string> nombres;

    nombres.push_back("Jose manuel");
    nombres.push_back("Luisico");
    nombres.push_back("lucia");
    nombres.push_back("sara");
    nombres.push_back("fernando");

    for (int i = 0; i < nombres.size(); i++){
        cout<<nombres[i]<<"("<<nombres[i].length()<<") ";
    }
    cout<<endl;


    imprimir(nombres);

    nombres.insert(nombres.begin()," posicion 0");
    nombres.inset(nombres.begin() +2 ,"posicion 2" );

    cout<<"eliminar la ultima posicion"<<endl;
    nombres.pop_back();
    imprimir(nombres);

    cout<<"Como eliminar la primera posición";
    nombres.erase(nombres.begin());
    nombres.erase(nombres.begin() +2);
    return 0;
}