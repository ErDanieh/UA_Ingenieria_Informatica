#include <iostream>
#include <cstring>
#include <string.h>
using namespace std;

int main(int argc, char * argv[]){
    bool opcionx, correctos;
    string nombrefichero;


    cout<<"Numero de argumentos"<<argc << endl;

    correctos=true;
    opcionx=false;

   for (int i =0; i < argc; i++){
       if(strcmp(argv[i],"-x")==0){
           nombrefichero=argv[i+1];
           i= i+1; //Para pasar a la siguiente operación
       }
       else{
        correctos=false;
        cout<<"error en el nombre del fichero"<<endl;
       }
    }
}