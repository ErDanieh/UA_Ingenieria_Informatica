#include <iostream>
#include <vector>

using namespace std;

typedef struct Deposito
{
	int capacidad;
	int litros;
	
};

void menu(){
	cout<<"1.Nuevo Deposito"<<endl;
	cout <<"2. Imprimir Deposito"<<endl;
	cout <<"3. Mostrar Capacidad Total"<<endl;
	cout <<"4. Mostrar Total Disponible"<<endl;
	cout <<"3. Mosstrar el Deposito más lleno"<<endl;
	cout <<"Opcion: ";

}

void altaDeposito(vector<Deposito> &depositos){
	Deposito nuevo;
	cout<<"Capacidad: ";
	cin>>nuevo.capacidad;

	if(nuevo.capacidad<10){
		cout<<"ERROR"<<endl;
	}else{
		cout<<"Litros: ";
		cin>>nuevo.litros;
		if (nuevo.litros> nuevo.capacidad|| nuevo.litros< 0){
			cout<<"Error en los litros"<<endl;
		}else{
			depositos.push_back(nuevo);
			cout<<"Deposito creado";
		}
	}
}


void imprimirDeposito(vector<Deposito> Deposito){
	int i;
	
}

int main(){
	int op;
	vector<Deposito> depositos;
	int nuevo;

	menu();
	cin>>op;
	switch(op){
		case 1: 
			break;
		case 2:

			break;
		case 3:
			break;
	}


}