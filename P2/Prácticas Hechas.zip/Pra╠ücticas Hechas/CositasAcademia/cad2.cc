#include <iostream>
#include <vector>
#include <string.h>

using namespace std;

//sustituye en cad1 todas las ocurrencias de cad2 por la cadena cad3

string replace(string cad1, string cad2, string cad3){

    int desde, hasta;
    int pos, i;
    string resultado;
    resultado="";

    desde=0;
    hasta=cad1.find(cad2, desde);

    while(hasta != string::npos){ //string::npos   Es un número muy grande que devuelve la función find cuando no encuentra un valor
    resultado=  resultado+cad1.substr(desde, hasta-desde); //hasta-la cantidad de letras
    resultado=resultado+ cad3;
    desde =hasta +cad2.length();
    hasta=cad1.find(cad2, desde);

    }

    return resultado;
}


int main(){
    string cad1, cad2, cad3;
    string resultado;


    cad1="Julia esta gorda muy muy gorda esta realmente gorda";
    cad2="gorda";
    cad3="guapa";

    resultado=replace(cad1,cad2,cad3);
    cout<<resultado;
    
}