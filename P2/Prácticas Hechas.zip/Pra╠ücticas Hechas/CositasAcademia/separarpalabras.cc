#include <cstring>
#include <cstring>
#include <iostream>
#include <vector>

using namespace std;

vector<string> extraerTokens(string cadena){
	string aux;
	int i, tam;
	vector<string>tokens;
	tam=cadena.length();
	 i = 0;

	 while(i  < tam){
	 	//1.Bucar una palabra. i < tam no quedan palabras
	 	while(i < tam && cadena[i]==' '){
	 		i++;
	 	}
	 	//2. coger palabras
	 	while(i < tam && cadena[i] != ' '){
	 		aux = aux + cadena[i];
	 		i++;
	 	}
	 	//Y si he encontrado palabra la guardas en el vector
	 	if(aux != ""){
	 		tokens.push_back(aux);
	 	}
	 }
	 return tokens;

}

void imprimir(vector<string>cadenas){
	string aux;
	for(int i = 0; i < cadenas.size(); i++){
		cout<<"<"<<cadenas[i]<<"> ";
		//para que no salga un espacio despues de la ultima cadena pongo este if
		if (i != cadenas.size()-1){
			cout<<" ";
		}
	}
}

int main(){
	string cadena;
	int i;
	vector<string> cadenas;

	cout<<"Cadena de palabras: ";
	getline(cin,cadena);
	cadenas = extraerTokens(cadena);
	imprimir(cadenas);

	return 0;
	
}