#include <iostream>
#include <cstring>
#include <sstream>
#include <vector>

struct Elemento{
    string dia;
    vector<string> productos;
};
struct Compra{
    vector<Elemento>elementos;
    string name;
};

int searchday(Compra compra, string day){
    int pos, i;
    pos=-1;
    for(i= 0;i < compra.elementos.size() && pos==-1; i++){
        if(compra.elementos[i].dia==day){
            pos=i;
        }
    }
    return pos;
}
void añadirDia(Compra &Compra){
    string day;
    int pos;

    cout<<"New Day: ";
    getline(day);
    
    pos=searchday(Compra, day);
    if(pos != -1){
        cout<<"ERROR- DUPLICATED DAY"<<endl;
    }else{
        nuevo.dia=day;
        compra.elementos.push_back(nuevo);
    }
}

//pedimos el dia, al cual añadir los productos
//buscamos ese dia en el vector de productos 
//si no esta error
//si esta pedimos los productos (todos en la misma cadena separados por espacios)
//recorreos la cadena y metemos los productos en vector de productos de ese día
//Day: lunes 18;
//products: patatas nonganizas cebolla

void addProducts(Compra &Compra){
    string day;
    string products;
    int pos;
    cout<<"Day: ";
    getline(cin, day);
    pos=searchday(compra, day);
    if(pos==-1){
        cout<<"ERROR-DAY NOT FOUND"<<endl;
    }else{
        cout<<"Products: ";
        getline(cin, products);
        while (ss>>aux)
        {
            compra.elements[pos].products.push_back(aux);
        }
        
    }
}
//pedimos el nombre del día, si no esta "ERROR- Day not found"
//Si esta mostraremos los productos de la compra por separado por comas 
void showDay(compra){
    string day;
    int pos;
    cout<<"Day";
    getline(cin,day);
    pos=searchday(compra, day);
    if (pos==-1){
        cout<<"ERROR- DAY not found"<<endl;
    }else{
        cout<<"Products;";
        for (int i = 0; i  < compra.elements[pos].productos.size(); i++){
            cout<<compra.elements[pos].productos[i];
            if(i!= compra.elements[pos].productos.size() - 1){
                cout<< ", "
            }
        }
        cout<<endl;
    }
}

void showall(compra compra){
    int i , j;
    for(i  = 0;i < compra.elements.size(); i++){
        cout<<"Day : "<< compra.elements[i].dia<<endl;
        for (j = 0; j < compra.elements[i].productos.size();j++){
            cout<< j << " : "<<compra.elements[i].prodictos[j]<<endl;
        }
    }
    cout<<endl;
}

int main(){
    int opc;
    Compra compra;
    compra.name="compras 12 s.l.";
    
    do{
        cout<<"1."<<endl;
        cout<<"2."<<endl;
        cout<<"3."<<endl;
        cout<<"4."<<endl;
        cout<<"5."<<endl;
        cout<<"6."<<endl;
        cin>>opc;
        cin.get();
        switch (opc)
        {
        case 1:
            break;
        case 2:
            break;
        case 3:
            break;
        case 4:
            break;
        
        default:
            break;
        }
    }while(opc>5 && opc<1);
}