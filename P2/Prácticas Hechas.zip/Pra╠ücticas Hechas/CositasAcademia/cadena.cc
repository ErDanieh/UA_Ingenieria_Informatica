#include <iostream>
#include <vector>
#include <string.h>

using namespace std;


//string ::npos si no la ha encontrado
vector<unsigned> buscar(string cad1, string cad2){
    vector<unsigned> posiciones;
    int aux;
    int i, pos;
    i=0;
    pos=cad1.find(cad2, i);

    cout<<"Buscando "<< cad2<<"desde "<<i<<endl;
    while(pos != -1){
        cout<<"encontrado en "<<pos<<endl;
        posiciones.push_back(pos);
        i=i+cad2.length();
        cout<<"Buscando desde : "<<i<<endl;
        pos=cad1.find(cad2,i);
    }
    return posiciones;
}

int main(){
    vector<unsigned> posiciones;

    posiciones=buscar("Julia gorda esta gorda, muy gorda", "gorda");
    
    for(int i = 0; i < posiciones.size();i++){
        cout<<posiciones[i]<<" ";
    }
    cout<<endl;

    return 0;

}