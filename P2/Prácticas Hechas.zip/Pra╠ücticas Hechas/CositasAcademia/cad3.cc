#include <iostream>
#include <vector>
#include <string.h>

using namespace std;

void insertarOrdernado(vector<string> &cadenas, string nueva){
    int i;
    string aux;

    cadenas.push_back(nueva);

    for(i= 0; cadenas.size() - 1 ; i > 0 && cadenas[i] < cadenas [i-1]; i --){
        aux=cadenas[i - 1];
        cadenas[i - 1]= aux;
    }

    
}


void insertarPalabras(vector<string> &cadenas, string linea){
    stringstream ss (linea);
    string aux;

    while (ss>>aux)
    {
        insertarOrdernado(cadenas, aux);
    }
    
}

int main (){
    
    vector<string> cadenas;

    insertarPalabras(cadenas,"es el cambio climatico microbiología");
    for(int i = 0; i < cadenas.size(); i++){
        cout<<cadenas[i]<<endl;
    }


    return 0;
}