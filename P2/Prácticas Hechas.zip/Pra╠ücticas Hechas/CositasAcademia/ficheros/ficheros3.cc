#include <iostream>
#include <fstream>

using namespace std;

int main(){
    ofstream fich;
    string linea;
    int numlinea;

    fich.open("Agenda.txt");

    if(fich.is_open()){
        numlinea=0;
        getline(fich, linea);

        while(!fich.eof()){
            cout<<numlinea<<" "<<linea<<endl;
            numlinea++;
            getline(fich,linea);
        }
        fich.close()
    }
    return 0;
}