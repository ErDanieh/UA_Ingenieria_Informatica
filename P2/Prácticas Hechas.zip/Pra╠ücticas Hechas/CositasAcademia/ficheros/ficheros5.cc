#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

 struct Hora{
     int min, seg;
 };

 Hora procesarLinea(string linea){
     Hora procesada;
     stringstream ss(linea);
     ss >> procesada.min;
     ss.get();
     ss>>procesada.seg;
     return procesada;
 }

int main(){
    string linea, nombre;
    ifstream fich;
    vector<Hora> horas;
    Hora nueva;

    cout<<"Nombre: ";
    getline(cin, nombre);
    fich.open(nombre.c_str());
    if(fich.is_open()){
        getline(fich, linea);
        while (!fich.eof())
        {
            nueva = procesarLinea(linea);
            horas.push_back(nueva);
            getline(fich, linea);
        }
        fich.close():

        for(int i = 0); i < horas.size(); i++){
            cout << horas[i].m<<":"<<horas[i].s<<endl;
        }        
    }
    return 0;
}