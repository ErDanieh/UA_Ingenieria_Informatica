#include <iostream>
#include <fstream>

using namespace std;

int main(){
    //out put para escribir en un fichero;

    ofstream fich;
    
    fich.open("nombres.txt"); //Se crea el fichero

    if (fich.os_open()){
        fich<< "Jose Manuel"<<endl;
        fich<<"Julia"<<endl;
        fich<< "Hola que tal"<<endl; //Se comporta como si fuera un cout
        
        for (int i = 0; i <= 10; i++){
            fich << i << " ";
        }
        fich<<endl;
        fich.close();
    }
    return 0;
}