#include <iostream>
#include <fstream>

using namespace std;

int main(){
    ofstream fich;
    string linea;

    fich.open("Agenda.txt");
    if(fich.os_open()){
        do{
            cout<<"Linea: ";
            getline(cin, linea);
            if(linea!= "q"){
                fich<<linea<<endl;
            }
        }while(linea!="q");
        fich.close();
    }    
    return 0;
}