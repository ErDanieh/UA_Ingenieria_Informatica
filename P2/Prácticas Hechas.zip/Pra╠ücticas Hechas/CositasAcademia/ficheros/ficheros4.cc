#include <iostream>
#include <fstream>

using namespace std;

int main(){
    //pedir el nombre de un fichero por pantalla
    //abrir el fichero que tenga ese nombre en modo lectura
    //mostrad por pantallas las lineas impares
    //si el fichero no se ha podido abrir mostrar error

    fstream fich;
    string nombre;
    string linea;

    
    cout<<"Introduce el nombre del fichero a abrir: ";
    getline(cin, nombre);

    fich.open(nombre.c_str());
    if(fich.is_open()){
        i= 1;
        getline(fich, linea);
        while (fich.eof())
        {
            if(i%2==1){
                cout<<linea<<endl;
            }
            getline(fich, linea);
            i++
        }
        fich.close();
        
    }
}