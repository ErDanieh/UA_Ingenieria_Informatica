#include <iostream>
#include <cstdlib>
#include <vector>

using namespace std;

struct Medicion{
	string ciudad;
	double temperatura;
};

int main(){
	vector<Medicion> mediciones;
	string cadena = "oriola:12.32;san vicente;1.12;almoradi:9.23;cartagena:-12.3";
	int i;
	Medicion m;
	int tam;
	string aux;
	aux  = "";

	tam=cadena.length();

	while( i < tam){
		while (i < tam && cadena[i]==' '){
			i++;
		}
		while(i < tam && cadena[i]!= ':'){
			aux=aux + cadena[i];
			i++;
		}
		m.ciudad=aux;
		i++; //Para saltarse los dos puntos
		aux=""
		if(i< tam && cadena[i]!= ';'){
			aux=aux + cadena[i];
			i++;
		}
		m.temperatura  = atof(aux.c_str()); // Para transformar el string a vector de caracteres
		mediciones.push_back(m);
		i++; 
	}
	for (int i = 0; i < mediciones.size(); i++){
		cout<<mediciones[i].ciudad<<"=> ";
		cout<<mediciones[i].temperatura << endl;
	}
	return 0;
}