#include <iostream>
#include <vector>

using namespace std;


int main(){
	vector<int> v; //Vector dinamico adapta el tamañoa al contenido;
	v.push_back(3); //añade un elemento al final de un vector 

	for(int i= 0; i < v.size(); i++){ //v.size = la cantidad de elementos almacenados
		cout<<v[i]<< " ";
	}
	cout<<endl;

}