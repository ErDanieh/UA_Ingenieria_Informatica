#include <iostream>

using namespace std;

unsigned buildnumber(const unsigned numbers[], unsigned size){
    int num;
	int cantd;
	cantd=(int)size;
	num=0;
	if(cantd==0){
		num=0;
	}else{
		for(int i= 0; i < cantd; i++){
			num=numbers[i]+num*10;
		}
	}
	return num;
}

int main(){
    int size;
	int numbers[];
	
	buildnumber(numbers, size)
}