#include <iostream>
#include <cstring>
#include <cctype>

using namespace std;

const unsigned kMATSIZE=5;


void deleteChar(char str[], char c){
	int i, j;
	i = 0;
	j = 0;
	while(str[i] != '\0'){
		if(str[i] != c){
			str[j] = str[i];
			j++;
			i++;		
		}
		else{
			i++;
		}
	}
	str[j] = '\0';
}


unsigned factorial(unsigned n){
    int fact;
    
    for (int i =1; i <= n; i++){
        fact=fact*i;
    }
return fact;
}



bool checkPassword(const char passwd[]){
	bool correcto;
	int i, longitud;
	int mayus,minus,digi,otros;
	int nums;
	mayus=0;
	minus=0;
	digi=0;
	otros=0;
	nums=0;
	longitud=strlen(passwd);

		if (longitud>=8 &&longitud <=12){
			for(i= 0; i< longitud && correcto==true; i++){
				if(isupper(passwd[i]!=0)){
					mayus++;
				}else{
					if(isupper(passwd[i]!=0)){
						minus++;
					}else{
						if(isdigit(passwd[i]!=0)){
							digi++;
						}else{
							correcto=false;
							otros++;
						}
					}
				}
			}
			if(mayus==0&&minus==0&&digi==0&&otros!=0){
				correcto=false;

			}else{
				correcto=true;
			}
		}else{
			for(i=0; i <= longitud; i++){
				if(isdigit(passwd[i]!=0)){
					nums++;
				}else{
					otros++;
				}
			}
			if(nums!=0&&otros==0){
				correcto=true;
			}else{
				correcto=false;
			}
			return correcto;

		}
	}




unsigned buildnumber(const unsigned numbers[], unsigned size){
    int form=0;
    if(size == 0){
        return 0;
    }else{
        for (int i=0;i < size; i++){
        form=(form*10) + numbers[i];
        }
    }
	return form;
}

bool friends(unsigned x, unsigned y){
	int sumax=0;
	int sumay=0;
	bool friend;

	friend=false;

	for (int i=1; i < x; i++){
		if(x%i == 0){
			sumax=sumax+i;
		}
	}
	for(int j=1; j < y; j++){
		if(y%j == 0){
			sumay=sumay+j;
		}
	}
	if((sumax==y) && (sumay==x)){
		friend=true;
	}else{
		friend=false;
	}
	return friend;
}


int sumNeighbors(int m[][kMATSIZE],int row,int column){
	int sum=0;


	int i, j;

	for (i = row-1; i <= row + 1; i++){

		for(j = column - 1; j <=row; j++){

			if(i >= 0 && i < kMATSIZE && j >= 0 && j < kMATSIZE && i!=0 && j!=0){
				sum=m[i][j]+sum;
			}
		}
	}
	return sum;
}


void printX(int n){
	
	int h=(n-1);

	if(n <= 0 || n%2!=0){
		cout<<"ERROR";
	}else{
		
			for(int i=0;i<n;i++){
			for(int j=0;j<n;j++){
				if((i==j)||(i+j==h)){
					cout<<"X";
				}else{
					cout<<" ";
				}					
			}
				cout<<endl;
		}
	}
}