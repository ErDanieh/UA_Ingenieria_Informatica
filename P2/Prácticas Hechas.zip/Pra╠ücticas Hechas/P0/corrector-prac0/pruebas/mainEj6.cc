#include <iostream>

using namespace std;

bool friends(unsigned x,unsigned y);


void printMainFriends(unsigned x, unsigned y)
{
	cout << "friends(" << x << "," << y << ")=" << friends(x,y) << endl;
}

void mainFriends()
{
	printMainFriends(2,2);
	printMainFriends(220,284);
	printMainFriends(20,54);
	printMainFriends(6,6);
	
	// ---------------------- 

	// Ejemplos dados pero a la inversa
	printMainFriends(284,220);
	printMainFriends(54,20);

	// Probar con el 0 (enunciado)
	printMainFriends(0,8);
	printMainFriends(8,0);
	printMainFriends(0,0);

	// Valores más grandes para evitar if/else
	printMainFriends(342,298);
	printMainFriends(656,322);
	printMainFriends(284,504);
	printMainFriends(17296,18416);
	printMainFriends(18416, 17296);
}


int main()
{
	mainFriends();
}
