#include <iostream>

using namespace std;

unsigned factorial(unsigned n);


void printFactorialTest(int n)
{
	cout << "factorial(" << n << ")=" << factorial(n) << endl;	
}
void mainFactorial()
{
	printFactorialTest(1);
	printFactorialTest(2);
	printFactorialTest(3);
	printFactorialTest(5);

	// ---------------------- 

	// Numeros más altos para (intentar) evitar programación con if/else (hay overflow!!)
	printFactorialTest(15);
	printFactorialTest(20);
}

int main() {
    mainFactorial();
}