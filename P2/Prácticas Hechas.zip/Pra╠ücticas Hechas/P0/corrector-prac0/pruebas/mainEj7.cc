#include <iostream>

using namespace std;

const unsigned kMATSIZE=5;

int sumNeighbors(int m[][kMATSIZE],int row,int col);

void printSumNeigbors(int matrix[][kMATSIZE], int row, int col)
{
	cout << "sumNeighbors(matrix," << row << "," << col << ")=" << sumNeighbors(matrix,row,col) << endl;
}

void mainSumNeighbors()
{
	int matrix[kMATSIZE][kMATSIZE] = { {1, 2, 3, 4, 5}, 
										{6, 7, 8, 9,10},
										{11,12,13,14,15},
										{16,17,18,19,20},
										{21,22,23,24,25}
									};

	printSumNeigbors(matrix, 2, 2);
	printSumNeigbors(matrix, 0, 0);
	printSumNeigbors(matrix, 4, 4);
	
	// ---------------------- 

	// row fuera de rango superior
	printSumNeigbors(matrix, -3, 2);

	// row fuera de rango inferior
	printSumNeigbors(matrix, 5, 2);

	// col fuera de rango superior
	printSumNeigbors(matrix, 2, 5);

	// col fuera de rango inferior
	printSumNeigbors(matrix, 2, -3);

	// col y row fuera de rango superior
	printSumNeigbors(matrix, 5, 5);

	// col y row fuera de rango inferior
	printSumNeigbors(matrix, -1, -1);
}

int main()
{
	mainSumNeighbors();
}
