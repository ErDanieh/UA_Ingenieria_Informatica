#include <iostream>
using namespace std;


void deleteChar(char str[],char c);

void printDeleteCharTest(char test[], char charToDelete)
{
  	cout << "deleteChar(\"" << test << "\"," << charToDelete << "), test=\"";
  	deleteChar(test, charToDelete);
  	cout << test << "\"" << endl;
}

void mainDeleteChar()
{
	char test1[] = "cadena de pruebaas";
	printDeleteCharTest(test1, 'a');

	char test2[] = "cadena de pruebaas";
	printDeleteCharTest(test2, 'e');

	char test3[] = "hola, mundo";
	printDeleteCharTest(test3, 'a');

	char test4[] = "hola, mundo";
	printDeleteCharTest(test4, 'o');

  	// ---------------------- 

	// Cadena vacía 
	char test5[] = "";
	printDeleteCharTest(test5, 'o');

  	// Todos los caracteres por borrar 
	char test6[] = "aaaaa";
	printDeleteCharTest(test6, 'a');

	// El caracter a borrar es el '\t'
	char test8[] = "hola,\tmundo";
	printDeleteCharTest(test8, '\t');

	// Ninguno se borra 
	char test9[] = "hola, mundo";
	printDeleteCharTest(test9, 'z');
}


int main() {
    mainDeleteChar();
}