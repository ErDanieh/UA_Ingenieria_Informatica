#include <iostream>

using namespace std;

bool checkPassword(const char passwd[]);

void printCheckPasswordTest(const char password[])
{
	cout << "checkPassword("<< password << ")=" << checkPassword(password) << endl;
}

void mainCheckPassword()
{
	printCheckPasswordTest("holaMundo");
	printCheckPasswordTest("hlM7no");
	printCheckPasswordTest("hlM7no8kj43");
	printCheckPasswordTest("hlM7no8kj43aa");
	printCheckPasswordTest("hola, mundo");
	printCheckPasswordTest("0123456789012345");
	printCheckPasswordTest("01234567890123a5");

	// ---------------------- 

	// Contraseña alfanumerica de mas de 12 caracteres
	printCheckPasswordTest("hlM7no8kj43aaajsh23");
	printCheckPasswordTest("hlM7no8kj43aa113");

	// Contreseña alfanumerica de justo 12 caracteres
	printCheckPasswordTest("hlM7no8kj43a");

	// Contreseña alfanumerica de entre 8 y 12 caracteres
	printCheckPasswordTest("hlM7no8k");
	printCheckPasswordTest("hlM7no8kj");
	printCheckPasswordTest("hlM7no8kj43");

	// Contraseña alfanumerica de justo 8 caracteres
	printCheckPasswordTest("hlM7no8k");

	// Contraseña alfanumerica de menos de 8 caracteres
	printCheckPasswordTest("hlM7no8");

	// Contraseña en rango con todo menos digitos
	printCheckPasswordTest("hlMNPwkt");

	// Contraseña en rango con todo menos mayusculas
	printCheckPasswordTest("hlmnpw92");

	// Contraseña en rango con todo menos minusculas
	printCheckPasswordTest("HLMNPW92");

	// Contraseña de digitos de más de 16 caracteres
	printCheckPasswordTest("01234567890123456");

	// Contraseña de 8 dígitos
	printCheckPasswordTest("01234567");

}

int main() {
    mainCheckPassword();
}