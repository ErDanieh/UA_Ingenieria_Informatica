#include <iostream>

using namespace std;

void printX(int n);

void printPrintX(int n)
{
	cout << "printX(" << n << ")" << endl;
	printX(n);
}

void mainPrintX()
{
	printPrintX(1);
	printPrintX(2);
	printPrintX(5);

	// ---------------------- 

	// Numero par distinto de 2
	printPrintX(12);
	
	// Ejemplo grande para evitar codigo con if/else
	printPrintX(99);
}

int main()
{
	mainPrintX();
}
