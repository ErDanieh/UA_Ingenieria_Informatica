#include <iostream>
#include <cstring>
#include <cctype>

using namespace std;

const unsigned kMATSIZE=5;


void deleteChar(char str[], char c){
	int i, j;
	i = 0;
	j = 0;
	while(str[i] != '\0'){
		if(str[i] != c){
			str[j] = str[i];
			j++;
			i++;		
		}
		else{
			i++;
		}
	}
	str[j] = '\0';
}


unsigned factorial(unsigned n){
	
	if (n<=0){
		return 1;
	}else{
		return n*factorial(n-1);
	}
}




bool checkPassword(const char passwd[]){
	bool correcto;
	int i;
	int longitud;
	int nummayus, nummins, numdigs, numdife;

	longitud = strlen(passwd);
	nummayus = nummins = numdigs = numdife = 0;
	if(longitud >= 8 && longitud <= 12){
		for(i = 0; i < longitud; i++){
			if(isupper(passwd[i]) != 0){
				nummayus++;
			}
			else{
				if(islower(passwd[i]) != 0){
					nummins++;
				}
				else{
					if(isdigit(passwd[i]) != 0){
						numdigs++;
					}
					else{
						numdife++;
					}
				}
			}
		}
		if(nummayus > 0 && nummins > 0 && numdigs > 0 && numdife == 0){
			correcto = true;
		}
		else{
			correcto = false;
		}
	}
	else{
		if(longitud == 16){
			correcto = true;
			for(i = 0; i < longitud && correcto == true; i++){
				if(isdigit(passwd[i]) == 0){
					correcto = false;
				}
			}
		}
		else{
			correcto = false;
		}
	}
		return correcto;
}




unsigned buildNumber(const unsigned numbers[],unsigned size){
    unsigned num=0;
	if(size==0){
		return 0;
	}else{
		for(int i= 0; i < size; i++){
			num=(num*10)+numbers[i];
		}
	}
	return num;
}
int calculator(const int numbers[],unsigned size,const char operators[]){
	
	int i=0;
	int j=0;
	int solve;
	solve=numbers[i];


	
	
		for (i=1; i < (int)size; i++){
			if(operators[j]=='+'){
				solve = solve + numbers[i];
				j++;
			}
			else if(operators[j]=='-'){
				solve = solve - numbers[i];
				j++;
			}
			else if(operators[j]=='*'){
				solve = solve * numbers[i];
				j++;
			}
			else if(operators[j]=='/'){
				if(numbers[i]!=0 && solve!=0){
				solve = solve / numbers[i];
				j++;
				}else{
					cout<<"ERROR";
				}
			}						
		}
		return solve;
}

bool friends(unsigned x, unsigned y){
	int sumax=0;
	int sumay=0;
	bool amis;

	for (int i=1; i < x; i++){
		if(x%i == 0){
			sumax=sumax+i;
		}
	}
	for(int j=1; j < y; j++){
		if(y%j == 0){
			sumay=sumay+j;
		}
	}
	if((sumax==y) && (sumay==x)){
		amis=true;
	}else{
		amis=false;
	}
	return amis;
}

int sumNeighbors(int m[][kMATSIZE], int row, int col){
	int suma;
	int i, j;
	
	suma = 0;
	for(i = row - 1; i <= row + 1; i++){
		for(j = col - 1; j <= col + 1; j++){
			if(i >= 0 && i < kMATSIZE && j >= 0 && j < kMATSIZE){
			suma = suma + m[i][j];

			}
		}
	}
	suma=suma-m[row][col];

	return suma;
}




void printX(int n){
	
	int h=(n-1);

	if(n <= 0 || n%2==0){
		cout<<"ERROR";
	}else{
		
			for(int i=0;i<n;i++){
				for(int j=0;j<n;j++){
					if((i==j)||(i+j==h)){
					cout<<"X";
					}else{
					cout<<" ";
				}					
				}
				cout<<endl;
			}
	}
}