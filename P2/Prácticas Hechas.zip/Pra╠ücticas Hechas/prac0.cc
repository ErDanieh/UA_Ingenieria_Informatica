// DNI 48776120C ASENSI ROCH, DANIEL
#include <iostream>
using namespace std;

const unsigned kMATSIZE=5;

void deleteChar(char str[],char c){

}

bool checkPassword(const char passwd[]){

}

int calculator(const int numbers[],unsigned size,const char operators[]){

}

bool friends(unsigned x,unsigned y){

}

int sumNeighbors(int m[][kMATSIZE],int row,int col){

}

void printX(int n){

    
}


unsigned factorial(unsigned n){
    int fact;
    
    for (int i =1; i <= n; i++){
        fact=fact*i;
    }
return fact;
}

unsigned buildnumber(const unsigned numbers[], unsigned size){
    int form=0;
    if(size == 0){
        return 0;
    }else{
        for (int i=0;i < size; i++){
        form=(form*10) + numbers[i];
        }
    }
return form;
}
