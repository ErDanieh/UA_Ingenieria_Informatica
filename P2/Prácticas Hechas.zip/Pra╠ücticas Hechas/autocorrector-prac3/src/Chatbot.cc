#include "Chatbot.h"
#include "Util.h"
#include <iostream>
#include <sstream>
using namespace std;


//Para inicializar el Chatbot
//con la similitud del jaccard
Chatbot::Chatbot()
{
    threshold=0.25;
    strcpy(similarity,"jc");
}

Chatbot:: Chatbot(float threshold, const char similarity[])
{
    if(strcmp(similarity,"jc")!=0 && strcmp(similarity,"ng")!=0)
    {
        throw ERR_SIMILARITY;
    }
    if(threshold<0||threshold>1)
    {
        throw ERR_THRESHOLD;
    }

    this->threshold=threshold;
    strcpy(this->similarity,similarity);

    //Reuerda que el this es para indicar que lo que pasas como parametro
    //Lo asignas al del mismo nombre
}

float Chatbot::getThreshold()const
{
    return threshold;
}

string Chatbot::getSimilarity() const
{
    return similarity;
}


//Función auxiliar para buscar los intent
int Chatbot::searchIntent(string name)const
{
    int pos;
    pos=-1;

    for (int i =0; i <(int) intents.size()&& pos==-1;i++)
    {
        if(intents[i]->getName()==name)
        {
            pos=i;
        }
    }
    return pos;
}

bool Chatbot::addIntent(Intent *pIntent){
    bool anadido;
    int pos;

    anadido=false;

    if(pIntent!=NULL){
        pos=searchIntent(pIntent->getName());
        //Buscamos el intent y sacamos su posicion mediante su nombre

        if (pos==-1)
        {
            anadido=true;
            intents.push_back(pIntent);
        }
        else{
            Util::error(ERR_INTENT);
        }
        
    }
    return anadido;
}

bool Chatbot::deleteIntent(string name, bool askConfirm)
{
    bool deleted;
    int pos;
    char respuesta;
    deleted=false;

    if(name==""){
       cout<<"Intent name: ";
       getline(cin,name);
    }

    pos=searchIntent(name);

    if(pos!=-1)
    {
        respuesta='y';
        if(askConfirm==true){
            do
            {
                cout<<"Confirm [Y/N]?: ";
                cin>>respuesta;
                cin.get();
            } while (respuesta!='y'&&respuesta!='Y'&&respuesta!='n'&&respuesta!='N');
            
            if(respuesta=='y'||respuesta=='Y')
            {
                intents.erase(intents.begin()+pos);
                deleted=true;
            }
        }
    }
    else{
        Util::error(ERR_INTENT);
    }
    return deleted;
}

bool Chatbot::addExample(string name){
    bool anadido;
    int pos;
    string text;

    if(name=="")
    {
        cout<<"Intent name: ";
        getline(cin,name);
    }
    pos=searchIntent(name);

    if(pos==-1)
    {
        Util::error(ERR_INTENT);
    }
    else{
        cout<<"New example: ";
        getline(cin,text);
        while (text!="q")
        {
            try{
            Example e(text);
            intents[pos]->addExample(e);
            anadido =true;
            }
            catch(Error &e){
                Util::error(e);
            }
            cout<<"New example: ";
            getline(cin, text);
        }
        
    }
    return anadido;
}

bool Chatbot::deleteExample(int id)
{
    bool eliminado;
    eliminado=false;

    if(id==0){
        cout<<"Example id: ";
        //Pedimos el id del que queremos eleminar
        cin>>id;
        cin.get();
    }
    for(int i = 0;i < (int) intents.size() && eliminado==false;i++){
        try{
            intents[i]->deleteExample(id);
            eliminado=true;
        }
        catch(Error &e){

        }
    }
    if(!eliminado){
        Util::error(ERR_EXAMPLE);
    }
    return eliminado;
}

bool Chatbot::addResponse(string name, string response){
    bool ananido;
    int pos;
    ananido = false;

    if(name==""){
        cout<<"Intent name: ";
        getline(cin, name);
    }
    if(response==""){
        cout<<"New response: ";
        getline(cin, response);
    }

    pos=searchIntent(name);

    if(pos!=-1){
        ananido=true;
        intents[pos]->addResponse(response);
    }
    else{
        Util::error(ERR_INTENT);
    }
    return ananido;
}


string Chatbot::bestResponse(string query, bool debug)const
{
    string mejorRespu;
    float mejor;
    float actual;
    //Lo inicializo a cero para reseatearlo cada vez que me meto a la función

    for(int i = 0; i <(int) intents.size();i++){
        //adquiere el valor de la similitud
        actual=intents[i]->calculateSimilarity(query, similarity);

        if(actual>mejor){
            mejor=actual;
            mejorRespu=intents[i]->getResponse();
        }
    }
    //Si es menor que el umbral lanzamos el error porque no encontramos respuesta compatible
    if(mejor<threshold){
        throw ERR_RESPONSE;
    }
    //Para meter en response el valor del buffer si de debug esta activado

    if (debug==true)
    {
        stringstream KK;
        KK<<"("<<mejor<<")"<<mejorRespu;
        mejorRespu=KK.str();
    }

    return mejorRespu;
    
}

void Chatbot::test(bool debug)const{
    string query;
    string respuesta;

    cout<<">>"<<Util::welcome()<<endl;
    cout<<"<< ";

    getline(cin, query);

    while (query!="q")
    {   
        //va a intentar encontrar una respuesta
        try{
            respuesta=bestResponse(query,debug);
            cout<<">>"<<respuesta<<endl;
        }
        catch(Error &e){
            //Si no la encuentra para no parar la ejecución la capturamos
            Util::error(e);
        }
        cout<<"<< ";
        getline(cin, query);
    }
    

}

void Chatbot::configure(float threshold, const char similarity[]){
    string algoritmo;
    double umbral;
    

    if(threshold!=-1){
        umbral=threshold;
    }
    else
    {
        cout<<"Enter threshold: ";
        cin >> umbral;
        cin.get();
    }
    if(umbral>=0 && umbral<=1){
        threshold=umbral;
    }
    else{
        Util::error(ERR_THRESHOLD);
    }

    //Para la Similaridad

    if(similarity == ""){
        cout <<"Enter algorithm: ";
        getline(cin,algoritmo);
    }
    else{
        algoritmo=similarity;
    }

    if(algoritmo!="jc" && algoritmo!="ng"){
        Util::error(ERR_SIMILARITY);
    }
    else
    {
        strcpy(this->similarity, algoritmo.c_str());
    }
    
}


ostream &operator<<(ostream &os, const Chatbot &c){
    int NumeroExamples;
    NumeroExamples=0;

    os<<"Similarity: ";
    if(strcmp(c.similarity,"jc")==0){
        os<<"Jaccard"<<endl;
    }
    else{
        os<<"N-grams"<<endl;
    }

    os<<"Threshold: "<<c.threshold<<endl;

    for(int i = 0; i <(int) c.intents.size();i++){
        os<<*(c.intents[i]);

        NumeroExamples += c.intents[i]->getNumExamples();
    }

    os<<"Total intents: "<<c.intents.size()<<endl;

    os<<"Total examples: "<<NumeroExamples<<endl;

    os<<"Examples per intent: ";

    if(c.intents.size()==0){
        os<<0;
        cout<<endl;
    }
    else{
        os<<(double)NumeroExamples/c.intents.size();
        cout<<endl;

    }
    return os;
}