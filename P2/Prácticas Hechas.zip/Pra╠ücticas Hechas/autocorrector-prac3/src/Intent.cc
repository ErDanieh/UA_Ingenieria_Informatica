#include "Intent.h"
#include "Util.h"
#include <cstring>

const unsigned Intent::KMAXEXAMPLES=10;

Intent::Intent(string name)
{
    this->name = name;
    response ="";
    if(name.empty()){
        throw ERR_EMPTY;
    }

    this->examples.clear();

}

//Funciones hechas desde el pdf solo para devolver

string Intent::getName()const 
{
    return name;
}

string Intent::getResponse() const
{
    return response;
}

vector<Example> Intent::getExamples()const
{
    return examples;
}

unsigned Intent::getNumExamples() const
{
    return examples.size();
}

void Intent::addResponse(string response)
{//Asignamos la respuesta
    this->response=response;
}

void Intent::addExample(const Example &example)
{
    if(examples.size()==KMAXEXAMPLES)
    {
        throw ERR_MAXEXAMPLES;
    }
    examples.push_back(example);
}

//Buscamos el id del intent
//Esta funcion es completamente auxiliar

int Intent::BuscadordeIds(int id)const
{
    int pos;
    pos=-1;
    for(int i=0; i <(int) examples.size() && pos==-1;i++)
    {
        if(examples[i].getId()==id)
        {
            pos=i;
        }
    }
    return pos;
}

//Para hacer la funcion de delete
//tengo que utilizar mi función auxiliar

void Intent::deleteExample(int id)
{
    int pos;
    pos=BuscadordeIds(id);//Le pasamos el id a buscar
    if(pos==-1)
    {
        throw ERR_EXAMPLE;
        //El principio + la cantidad de la posición encontrada
    }
    else{//Lanzamos el error si no se encuentra
        examples.erase(examples.begin() + pos);
    }
}

float Intent::calculateSimilarity(string text, const char similarity[])const
{
    float actual;
    float mejor;

    if(strcmp(similarity,"ng")==0 && strcmp(similarity,"jc")==0)
    {
        mejor=0;
        
        for(int i= 0; i<(int) examples.size();i++){
            if(strcmp(similarity,"ng")==0)
            {
                actual=examples[i].ngramSimilarity(text);
            }
            else{
                actual=examples[i].jaccardSimilarity(text);
            }
            if(actual>mejor){
                mejor=actual;
            }
        }
    }
    else{ //Si no se inicializa ningun algoritmo de comparación
        throw ERR_SIMILARITY;
    }
    return mejor;
}

ostream &operator<<(ostream &os, const Intent &intent){
    os<<"Intent: "<<intent.name<<endl;
    os<<"Response: "<<intent.response<<endl;

    for(int j=0; j < (int) intent.examples.size();j++)
    {
        os<<intent.examples[j]<<endl;
    }
    return os;
}

