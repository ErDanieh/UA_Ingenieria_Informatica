#include "Example.h"
#include <algorithm>

int Example::nextId=1;

Example::Example(string text)
{
    id=nextId;

    this->text=text;

    tokens=Util::extractTokens(text);

    //Comprobamos que el vector de tokens no esta vacio
    //Si lo esta lanzamos el error
    if(tokens.size()==0)
    {
        throw ERR_EMPTY;
    }
    nextId++;

}

void Example::resetNextId()
{
    nextId=1;
}

int Example::getId() const{
    return id;
}

string Example::getText()const
{
    return text;
}

vector<string> Example::getTokens() const
{
    return tokens;
}

vector<string> limpiaDuplicados(const vector<string> &tokens)
{
    vector<string> noDupli;
    bool find;
    int tam, tam2;
    tam=tokens.size();
    tam2=noDupli.size();

	for(int i = 0; i < tam; i++){
		find = false;
		for(int j = 0; j < tam2 && !find; j++){
			if(noDupli[j] == tokens[i]){
				find = true;
			}
		}
		if(!find){	
			noDupli.push_back(tokens[i]);
		}
	}
	return noDupli;
}

vector<string>Example::PalabrasCompartidas(vector<string> cad1, vector<string> cad2)
{
  vector<string>intersec;
  int tam1;
  tam1=cad1.size();

  for(int i = 0; i < tam1; i++ ){
    if(find(cad2.begin(),cad2.end(), cad1[i]) != cad2.end()){
      intersec.push_back(cad1[i]);
    }
  }
  return intersec;
}

vector<string> Example::tokensaNG(vector<string>tokens)
{
    vector <string> tresgramitas;
    string grama;
  
  for (int i = 0 ; i < (int)tokens.size(); i++){
    if(tokens[i].length()>= 3){
      for(int j= 0; j <=(int) tokens[i].length()-3;j++){
        tresgramitas.push_back(tokens[i].substr(j,3));
      }
    }
  }
  return tresgramitas;

}

float Example::jaccardSimilarity(string text)const
{
    float solve=0;
    vector<string>tokenspp;
    vector<string>tokens1;
    vector<string>tokens2;
    vector<string>interseccion;

    tokenspp=Util::extractTokens(text);

    tokens1=limpiaDuplicados(tokens);
    tokens2=limpiaDuplicados(tokenspp);

    interseccion=PalabrasCompartidas(tokens1,tokens2);
    //Formulita
    solve=(float) interseccion.size()/(tokens1.size()+tokens2.size()-interseccion.size());
    return solve;
}

float Example::ngramSimilarity(string text)const
{
    float solve=0;
    vector<string>tokenspp;
    vector<string>tokens1;
    vector<string>tokens2;
    vector<string>interseccion;
    
    tokenspp=Util::extractTokens(text);

    tokens1=limpiaDuplicados(tokens);
    tokens2=limpiaDuplicados(tokenspp);

    //Para los enegramas
    tokens1=tokensaNG(tokens1);
    tokens2=tokensaNG(tokens2);

    interseccion=PalabrasCompartidas(tokens1,tokens2);
    solve=(double) interseccion.size() /(tokens1.size()+tokens2.size()-interseccion.size());
    return solve;

}

//Lanzamos el display de los tokens y los examples para ver
//Lo que tenemos almacenado el vector de examples y  a su
//En el vector de tokens
//En definitiva es como un cout
ostream &operator<<(ostream &os, const Example &e){
    os<<"Example "<<e.id<<": "<<e.text<<endl;
    os<<"Tokens "<<e.id<<": ";
    for (int i =0; i < (int) e.tokens.size();i++){
        os<<"<"<<e.tokens[i]<<">";
    }
    return os;
}