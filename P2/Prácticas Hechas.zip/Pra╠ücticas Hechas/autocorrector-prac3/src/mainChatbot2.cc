#include <iostream>
#include "Util.h"
#include "Example.h"
#include "Intent.h"
#include "Chatbot.h"
using namespace std;

int main(){
	Chatbot c;

	cout << c << endl;
	
	c.addIntent(new Intent("los putos lunes"));

	c.addExample("los putos lunes");

	cout << c << endl;	

	cout << "borrado examples" << endl;
	
	cout << "borrando el 12" << endl;
	c.deleteExample(12);

	c.deleteExample();
	
	cout << "hemos borrado el 3" << endl;
	cout << c << endl;

	return 0;
}
