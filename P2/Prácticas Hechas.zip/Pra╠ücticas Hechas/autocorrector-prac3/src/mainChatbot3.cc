#include <iostream>
#include "Chatbot.h"
using namespace std;


int main(){
	Chatbot bot(0.1, "jc");
	vector<Intent *> ins;

	ins.push_back(new Intent("cuantos virus hay?"));
	ins.push_back(new Intent("cuantos vamos a aprobar?"));
	ins.push_back(new Intent("cuando vienen los extrarrestre?"));
	for(int i = 0; i < ins.size(); i++){
		bot.addIntent(ins[i]);
	}
	cout << bot << endl;
	bot.addResponse("cuantos virus hay?", "hay mas de 1500 virus");
	bot.addResponse("cuantos vamos a aprobar?", "mas del 80%");
	bot.addResponse("cuando vienen los extrarrestre?", "ya estan aqui, no has visto a paco?");
	cout << bot << endl;
	cout << "===================" << endl;

	
	bot.addExample();
	cout << bot << endl;	
	
	cout << "===================" << endl;

	bot.addExample();
	cout << bot << endl;	
	
	cout << "===================" << endl;

	bot.addExample();
	cout << bot << endl;

	cout << "===================" << endl;

	
	bot.test();

	//bot.test();

	
	// liberarmos la memoria dinamica
	for(int i = 0; i < ins.size(); i++){
		delete ins[i];
	}

	return 0;
}
