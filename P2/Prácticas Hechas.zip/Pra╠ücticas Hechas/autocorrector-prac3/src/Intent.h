#ifndef _INTENT_
#define _INTENT_
#include "Example.h"
#include <iostream>

using namespace std;

class Intent
{
    friend ostream &operator<<(ostream &os, const Intent &intent);

    protected: 
        string name;
        string response;
        vector<Example> examples;
        //Funcion auxiliar para buscar IDS
        int BuscadordeIds(int id) const;

    public:
        static const unsigned KMAXEXAMPLES;
        Intent(string name);
        string getName() const;
        string getResponse() const;
        vector<Example> getExamples() const;
        unsigned getNumExamples() const;
        void addExample(const Example &example);
        void deleteExample(int id);
        void addResponse(string response);
        float calculateSimilarity(string text, const char similarity[]) const;

};

#endif