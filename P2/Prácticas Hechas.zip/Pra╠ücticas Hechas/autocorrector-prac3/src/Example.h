#ifndef __EXAMPLE__
#define __EXAMPLE__
#include <iostream>
#include <vector>
#include "Util.h"


using namespace std;

class Example{
    friend ostream &operator<<(ostream &os, const Example &e);

    protected:
        vector <string> tokens;
        int id;
        string text;
        static int nextId;
        static vector<string> PalabrasCompartidas(vector<string> cad1, vector<string> cad2);
        static vector<string> tokensaNG(vector<string>tokens);


    public:
        Example(string text);
        static void resetNextId();
        int getId()const;
        string getText() const;
        vector <string> getTokens()const;
        float jaccardSimilarity(string text) const;
        float ngramSimilarity(string text)const;
        

};

#endif