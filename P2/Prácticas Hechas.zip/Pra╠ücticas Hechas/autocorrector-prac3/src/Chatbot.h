#ifndef _CHATBOT_
#define _CHATBOT_
#include <iostream>
#include <cstring>
#include <vector>
#include "Intent.h"
#include "Example.h"

using namespace std;

class Chatbot
{
    friend ostream &operator<<(ostream &os, const Chatbot &c);

    protected:
        float threshold;
        char similarity[3];
        vector<Intent *> intents;
        int searchIntent(string name) const;
        string bestResponse(string query, bool debug)const;
        

    public:
        Chatbot();
        Chatbot(float threshold, const char similarity[]);
        bool addIntent(Intent *pIntent);
        bool addExample(string name="");
        bool deleteIntent(string name="",bool askConfirm = true);
        bool deleteExample(int id =0);
        void configure(float threshold = -1, const char similarity[]="");
        bool addResponse(string name="",string response ="");
        void test(bool debug = false) const;
        float getThreshold()const;
        string getSimilarity() const;

        
};
#endif