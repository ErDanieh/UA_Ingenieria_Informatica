#include "Chatbot.h"
#include <iostream>
#include "Util.h"
using namespace std;


int main(){
	Chatbot defs;
	cout << defs << endl;

	Chatbot bot(0.9, "jc");
	cout << bot << endl;

	Chatbot bot2(0.1, "ng");
	cout << bot2 << endl;

	try{
		Chatbot bot3(-0.1, "ng");
	}
	catch(Error &e){
		Util::error(e);
	}

	try{
		Chatbot bot4(0.1, "xx");
	}
	catch(Error &e){
		Util::error(e);
	}

	vector<Intent *> misIntents;
	misIntents.push_back(new Intent("vacaciones"));
	misIntents.push_back(new Intent("examenes"));
	misIntents.push_back(new Intent("niños en la calle"));
	bool r;
	for(int i = 0; i < misIntents.size(); i++){
		r = bot.addIntent(misIntents[i]);
		cout << "added " << r << " => " << misIntents[i]->getName() <<endl;	
	}

	r = bot.addResponse("vacaciones", "nunca mas");
	cout << "modficiado: " << r << endl;

	
	r = bot.addResponse("vocaciones", "no mas");
	cout << "modfiicado: " << r << endl;
	
	cout << bot << endl;

/*
	bot.addExample("vacaciones");
	cout << bot << endl;

	
*/	

	return 0;
}

