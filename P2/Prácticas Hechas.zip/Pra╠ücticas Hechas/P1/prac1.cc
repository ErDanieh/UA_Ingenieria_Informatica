//DNI 48776120C  Asensi Roch, Daniel

#include <iostream>
#include <cctype>
#include <cstring>
#include <cstdlib>
#include <vector>
#include <algorithm> //Para iteradores
#include <sstream>

using namespace std;

const string INTENTNAME="Intent name: ";
const string ESPERAR="<< ";
const string SALIDA="q";
const char SALIDAMENU='b';

struct Example{
  int id; 
  string text; 
  vector<string> tokens; 
};


struct Intent{
  string name; 
  vector<Example> examples;
  string response;  
};

struct Chatbot{
  int nextId; 
  float threshold; 
  char similarity[3];
  vector<Intent> intents; 
};


void showMainMenu();
void showTrainMenu();
int Buscador(Chatbot megabot, string name);
void addIntent(Chatbot &megabot);
void deleteIntent(Chatbot &megabot);
string limpiacadenas(string cadena);
string limpiadorEses(string cadena);
string limpiadortotal(string cadena);
vector<string> tokenizador(string cadena);
void addExample(Chatbot &megabot);
void deleteExample(Chatbot &megabot);
void addResponse(Chatbot &megabot);
void train(Chatbot &megabot);
vector<string> PalabrasCompartidas(vector<string> cad1, vector<string> cad2);
double algoritmoJaccard(string cad1, string cad2);
void busquedaConsulta(const Chatbot &megabot, string consulta);
void test(const Chatbot &megabot);
void impresorTokens(vector<string> tokens);
void report(const Chatbot &megabot);


string cleanString(string);

enum Error{ 
  ERR_OPTION,
  ERR_INTENT,
  ERR_EXAMPLE,
  ERR_RESPONSE
}; 

const int KSIZE=10;

const string greetings[KSIZE]=
{
  "Hola, ¿en qué puedo ayudarte?",
  "¿Qué puedo hacer hoy por ti?",
  "Oh, gran prócer de los bits, ¿cuál es tu deseo?",
  "Buenas",
  "¿Qué quieres?",
  "¿Otra vez necesitas ayuda?",
  "¡Hola! Soy Megabot 3000. ¿En qué puedo ayudarte?",
  "Bonito día para ser Megabot 3000",
  "Pregunta sin miedo",
  "Soy todo oídos"
};

void error(Error n)
{
  switch(n){
    case ERR_OPTION:
      cout << "ERROR: wrong menu option" << endl;
      break;
    case ERR_INTENT:
      cout << "ERROR: wrong intent name" << endl;
      break;
    case ERR_EXAMPLE:
      cout << "ERROR: wrong example id" << endl;
      break;
    case ERR_RESPONSE:
      cout << "Lo siento, pero no tengo respuesta para eso" << endl;
  }
}

void showMainMenu()
{
  cout << "1- Train" << endl
       << "2- Test" << endl
       << "3- Report" << endl
       << "q- Quit" << endl
       << "Option: ";
}

void showTrainMenu()
{
  cout << "1- Add intent" << endl
       << "2- Delete intent" << endl
       << "3- Add example" << endl
       << "4- Delete example" << endl
       << "5- Add response" << endl
       << "b- Back to main menu" << endl
       << "Option: ";
}




int Buscador(Chatbot megabot, string name)
{ 
int pos;
int tamanyo;
tamanyo=megabot.intents.size();
pos=-1;

for (int i =0; i < tamanyo && pos == -1; i++){
  if(megabot.intents[i].name==name){
    pos=i;
  }
}
return pos;

}


void addIntent(Chatbot &megabot)
{
  Intent nuevo; //Donde se introducen los valores del usuario
  int pos;

  cout<<INTENTNAME;
  getline(cin, nuevo.name);

  pos=Buscador(megabot, nuevo.name);
  
  if(pos == -1){
    megabot.intents.push_back(nuevo);
  }else{
   error(ERR_INTENT); 
  }
}

void deleteIntent(Chatbot &megabot)
{
  string name;
  char siono;
  int pos;
  pos=0;

  cout<<INTENTNAME;
  getline(cin, name);

  pos=Buscador(megabot, name);

  if (pos==-1){
    error(ERR_INTENT);
  }else{
  do{
      cout<<"Confirm [Y/N]?: ";
      cin>>siono;
      if(siono=='y' || siono=='Y'){
        megabot.intents.erase(megabot.intents.begin()+pos); //elimina la intención que se encuentra en pos
      }
    } while (siono!='y' && siono !='Y' && siono != 'n' && siono!='N');

  }
}

string limpiacadenas(string cadena)
{
  string limpia;
  int tamanyo;
  limpia = "";
  tamanyo=cadena.length();

  for (int i = 0; i < tamanyo; i++){
    if(isalnum(cadena[i]) != 0 || cadena[i]== ' '){ 

        limpia=limpia + (char) tolower(cadena[i]);

    }
  }
  return limpia;
}

string limpiadorEses(string cadena)
{ 
  string eses="";
  int tamanyo;

  tamanyo=cadena.length();
  for(int i = 0; i < tamanyo; i++){
    if(cadena[i]=='s'){
      if(i+1 < tamanyo){
        if(cadena[i + 1]!=' '){
          eses=eses+cadena[i];
        }

      }
    }
    else{
      eses=eses+cadena[i];
    }
  }
  return eses;
}

string limpiadortotal(string cadena)
{
  cadena=cleanString(cadena);
  cadena=limpiacadenas(cadena); 
  cadena=limpiadorEses(cadena);

  return cadena;
}


vector<string> tokenizador(string cadena)
{
  string aux;
  vector<string> tokenizada;
  stringstream ss (cadena);
  while (ss >> aux)
  {
    tokenizada.push_back(aux);
  }
  return tokenizada;
  
}


void addExample(Chatbot &megabot)
{

  string Asignar, cleantext;
  Example nuevoExample;
  int pos;
  vector <string>toks;

  cout<<INTENTNAME;
  getline(cin, Asignar);

  pos=Buscador(megabot,Asignar); 

  if(pos == -1){

    error(ERR_INTENT); 
  }
	else{
		cout << "New example: ";
		getline(cin, cleantext);
		do{
			nuevoExample.id = megabot.nextId;
			nuevoExample.text = cleantext;

      cleantext=limpiadortotal(cleantext);
      toks.clear();
      toks=tokenizador(cleantext);
      
      if(toks.size()!=0){
        nuevoExample.tokens=toks;
        megabot.intents[pos].examples.push_back(nuevoExample);
        megabot.nextId++;
      }
			cout << "New example: ";
			getline(cin, cleantext);

		}while(cleantext != SALIDA);
	}
}



void deleteExample(Chatbot &megabot)
{
  int posi, posj;
  int aborrar;
  int tamanyo, tamanyo2;
  tamanyo=megabot.intents.size();
  posi=-1;
  posj=-1;

  cout<<"Example id: ";
  cin>>aborrar;
  cin.get();
  
  for (int i = 0; i < tamanyo; i++){
    tamanyo2=megabot.intents[i].examples.size();
    for(int j = 0; j < tamanyo2 ;j++){
      if(aborrar == megabot.intents[i].examples[j].id){
        posi=i;
        posj=j;
      }
    }
  }
  if(posi!=-1 && posj!=-1){
    megabot.intents[posi].examples.erase(megabot.intents[posi].examples.begin()+posj);
  }
  else{
    error(ERR_EXAMPLE);
  }

}

void addResponse(Chatbot &megabot)
{
  string wantAdd;
  int pos;

  cout<<INTENTNAME;
  getline(cin, wantAdd);
  
  pos=Buscador(megabot, wantAdd);

  if(pos==-1){
    error(ERR_INTENT); 
  }
  else{
    cout<<"New response: ";
    getline(cin,megabot.intents[pos].response); //Se sobreescribe el valor de response
  }
}


void train(Chatbot &megabot)
{ 
  char opcion;

  do{
    showTrainMenu();
    cin>>opcion;
    cin.get();
    switch (opcion)
    {
    case '1':
    addIntent(megabot);
      break;
    case '2':
    deleteIntent(megabot);
      break;
    case '3':
    addExample(megabot);
      break;
    case '4':
    deleteExample(megabot);
      break;
    case '5':
    addResponse(megabot);
      break;
    case 'b':
      break;
    default:
    error(ERR_OPTION);
      break;
    }
  }while(opcion!=SALIDAMENU);

}


vector<string> limpiaDuplicados(const vector<string> &tokens){
	vector<string> noDupli;
	bool find;
  int tam, tam2;
  tam=tokens.size();
  tam2=noDupli.size();

	for(int i = 0; i < tam; i++){
		find = false;
		for(int j = 0; j < tam2 && !find; j++){
			if(noDupli[j] == tokens[i]){
				find = true;
			}
		}
		if(!find){	
			noDupli.push_back(tokens[i]);
		}
	}
	return noDupli;
}


vector<string> PalabrasCompartidas(vector<string> cad1, vector<string> cad2)
{
  vector<string>intersec;
  int tam1;
  tam1=cad1.size();

  for(int i = 0; i < tam1; i++ ){
    if(find(cad2.begin(),cad2.end(), cad1[i]) != cad2.end()){
      intersec.push_back(cad1[i]);
    }
  }
  return intersec;
}



double algoritmoJaccard(string cad1, string cad2)
{
  double jaccard;
  vector<string> tok1;
  vector<string> tok2;
  vector<string> intersec;

  cad1=limpiadortotal(cad1);
  cad2=limpiadortotal(cad2);

  tok1=tokenizador(cad1);
  tok2=tokenizador(cad2);

  tok1=limpiaDuplicados(tok1);
  tok2=limpiaDuplicados(tok2);

  
  intersec=PalabrasCompartidas(tok1, tok2);


  jaccard=(double) intersec.size()/ (tok1.size()+tok2.size()-intersec.size());
  //Ecuación de Jaccard Segun la cantidad de palabras

  return jaccard;
}

void busquedaConsulta(const Chatbot &megabot, string consulta)
{
  double actual;
  double mejor;
  string respuesta;
  int tamanyo;
  int tam2;
  string aux;


  tamanyo=megabot.intents.size();
  mejor=0;

  for(int i = 0; i < tamanyo; i++){

    tam2=megabot.intents[i].examples.size();

    for(int j=0; j < tam2; j++){
      actual=algoritmoJaccard(consulta, megabot.intents[i].examples[j].text); //Asignamos el valor actual de similitud

      if(actual>mejor){
        mejor=actual;
        respuesta=megabot.intents[i].response; //Vamos asignando las respuestas según la similitud, recorriendo el vector
      }
    }
  }
  if(mejor< megabot.threshold){
    error(ERR_RESPONSE);
  }
  else{
    cout<<">>"<<respuesta<<endl;
  }
}


void test(const Chatbot &megabot)
{
  int position;
  string consulta, respuesta;
  
  string aux;

  position=rand()% KSIZE;
  cout<<">>"<<greetings[position]<<endl;
  cout<<ESPERAR;
  getline(cin, consulta);
  while(consulta != SALIDA){
      busquedaConsulta(megabot, consulta);
      cout<<ESPERAR;
      getline(cin, consulta);
  }

}

void impresorTokens(vector<string> tokens)
{
  int tam;
  tam=tokens.size();

  for (int i = 0; i < tam; i++){
    cout<<"<"<<tokens[i]<<"> ";
    if(i != tam-1){
      cout<<" ";
    }
  }
}

void report(const Chatbot &megabot)
{
  int tam2;
  int tamnyo=megabot.intents.size();
  int numExamples;
  numExamples=0;
  if(strcmp(megabot.similarity, "jc")==0){
    cout <<"Similarity: Jaccard"<< endl;
  }
  
  cout <<"Threshold: "<<megabot.threshold << endl;

  for(int i = 0; i < tamnyo; i++){
    cout<<"Intent: "<< megabot.intents[i].name<<endl;
    cout<<"Response: "<<megabot.intents[i].response<<endl;
    tam2=megabot.intents[i].examples.size();

    for(int j = 0; j < tam2; j++){
      numExamples++;
      cout<<"Example ";
      cout<<megabot.intents[i].examples[j].id<<": ";
      cout<<megabot.intents[i].examples[j].text<<endl;
      cout<<"Tokens "<<megabot.intents[i].examples[j].id<<": ";
      impresorTokens(megabot.intents[i].examples[j].tokens);
      cout<<endl;
    }
    cout<<endl;
  }
  cout<<"Total intents: "<<tamnyo<<endl;
  cout<<"Total examples: "<<numExamples<<endl;
  cout<<"Examples per intent: ";

  if(tamnyo != 0){
    cout<<(double) numExamples / tamnyo <<endl;
  }
  else {
    cout<< 0.0 <<endl;
  }

}

int main(){
  Chatbot megabot;
  megabot.nextId=1;
  megabot.threshold=0.25;
  strcpy(megabot.similarity,"jc");
    
  srand(666);

  char option;
  do{
    showMainMenu();
    cin >> option;
    cin.get();
        
    switch (option){ 
      case '1':
        train(megabot);
        break;
      case '2':
        test(megabot);
        break;
      case '3':
        report(megabot);
        break;
      case 'q':
        break;
      default:
        error(ERR_OPTION);
    }
  }while(option!='q');
    
  return 0;
}
