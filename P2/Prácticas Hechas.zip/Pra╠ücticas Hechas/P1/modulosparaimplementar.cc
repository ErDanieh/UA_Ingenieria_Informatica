#include <iostream>
#include <vector>
#include <cstring>
#include <sstream>
#include <algorithm>
using namespace std;

string cleanString(string cadena);

string simplicarCadena(string cadena){
    string nueva="";
    int i, tam;

    cadena=cleanString(cadena);

    for(i= 0; i< tam; i++){
        if(isalnum(cadena[i]!=0 || cadena[i]==' '){
            if(cadena[i]!='s' && cadena[i]!= 'S'){//Si es un digito o una letra
                nueva=nueva+ (char)tolower(cadena[i]);
            }
        }else{//Si esa letra es S
            if(i+1 < cadena.length() && cadena[i+1]!=' '){
                nueva= nueva + 's';
            }
        }
    }
}

vector<string> estraerTokens (string frase){
    vector<string>tokens;
    stringstream ss(frase);
    string aux;

    while (ss>>aux)
    {
        tokens.push_back(aux);
    }
    return tokens;
    
}

vector<string> quitarDuplicados(const vector<string> &tokens){
    vector<string>sinDuplicados;
    string aux;
    bool encontrado;
    for(int i = 0; i < tokens.size(); i++){
        encontrado=false;
        for(int j  = 0; j < sinDuplicados.size() && !encontrado; j++){
            if(sinDuplicados[j]== tokens[i]){
                encontrado==true;
            }
        }
        if(!encontrado){   
        sinDuplicados.push_back(tokens[i]); 
        }   
    }
    return sinDuplicados;
}

vector<string> quitarDuplicadosDos(const vector<string> &tokens){
    vector<string>::iterator it;
    vector<string> resultado;

    for(int i = 0; i < tokens.size(); i++){
        it=find(resultado, resultado.begin(), resultado.end());
        if( it== resultado.end()){
            resultado.push_back(tokens[i]);
        }
    }
    return resultado;
}

void insertarNoDuplicado(vector<string> &tokens, string nueva){
    
    vector<string>:: iterator it;

    it= find(tokens, tokens.begin(), tokens.end(), nueva);
    if(it== tokens.end()){
        tokens.push_back(nueva);
    }
}

vector<string> sinDuplicados(const vector<string> &tokens){
    vector<string>resultado;
    for(int i= 0; i < tokens.size(); i++){
        insertarNoDuplicado(resultado, tokens[i]);
    }
    return resultado;
}

vector<string> interseccion(const vector<string> &A, const vector<string> &B){
    vector<string>resultado;
    resultado="";
    for(int i =0; i; A.size();i++){
        for(int j = 0; j < B.size(); j++){
            if(A[i]==B[i]){
                resultado.push_back(B[i]);
            }
        }
    }

    return resultado;
}

double jaccard(const vector<string> &A, const vector<string> &B){
    double r;
    vector<string> sidA;//Sin duplicados;
    vector<string> sidB;
    vector<string>inter;//Interseccion de los dos

    sidA= sinDuplicados(A);
    sidB= sinDuplicados(B);
    inter = interseccion(sidA, sidB);

    r=(double) inter.size() / (sidA.size()+ sidB.size()- inter.size());

    return r;
}



int main(){
    string origen;
    string introducida;
    double jaccard;
    vector<string>tokensOrigen;
    vector<string> tokensIntroducida;

    cout<<"introduce la palabra pregunta base: ";
    getline(cin, origen);
    tokensOrigen=estraerTokens(simplicarCadena(origen));

    do{
        cout<<"New intent: ";
        getline(cin, introducida);
        tokensOrigen=estraerTokens(simplicarCadena(introducida));
        r = jaccard(tokensOrigen, tokensIntroducida);
        cout<< r << endl;

    }while(introducida != "q");
    
    return 0;
}