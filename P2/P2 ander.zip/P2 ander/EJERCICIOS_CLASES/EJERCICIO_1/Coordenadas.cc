#include <iostream>
#include "Coordenadas.h"

using namespace std;

Coordenada::Coordenada(float cx, float cy)
{
  x = cx;
  y = cy;
  cout << "El objeto ha sido creado de la primera forma." << endl;
}

Coordenada::Coordenada(const Coordenada &c)
{
  x = c.x;
  y = c.y;
  cout << "El objeto ha sido creado de la segunda forma." << endl;
}

Coordenada::~Coordenada(){
  cout << "El objeto ha sido destruido." <<  endl;
}

float Coordenada::getX() const
{
  return x;
}

float Coordenada::getY() const
{
  return y;
}

void Coordenada::setX(float cx)
{
  x = cx;
}

void Coordenada::setY(float cy)
{
  y = cy;
}


ostream& operator<<(ostream& os, const Coordenada& obj)
{
  os << obj.x << "," << obj.y;
  return os;
}
