#include "Linea.h"

Linea::Linea(){
  cantidad = 0;
  precio = 0;
  descripcion = "";
}

