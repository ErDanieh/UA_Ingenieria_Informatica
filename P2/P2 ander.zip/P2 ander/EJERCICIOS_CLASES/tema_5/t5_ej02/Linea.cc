#include "Linea.h"

Linea::Linea(){
  cantidad=0;
  precio=0;
  descripcion=""; // Realmente no hace falta, porque el constructor de "string" ya lo inicializa a cadena vacía
}
