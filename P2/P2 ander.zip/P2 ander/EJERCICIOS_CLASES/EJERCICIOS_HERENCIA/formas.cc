#include <iostream>
#include "Shape.h"
#include "Rectangle.h"

using namespace std;


int main(){
  Rectangle rect;

  rect.setWidth(5);
  rect.setHeight(7);

  cout << "Total area: " << rect.getArea() << endl;
}