
#include <iostream>
using namespace std;

class fecha
{
  private:
    int dia;
    int mes;
    int anyo;
  public:
    fecha(int d=1, int m=1, int a=1900); // -> Constructor con parametros por defecto
    ~fecha();                   // -> Destructor
    int getDia();
    int getMes();
    int getAnyo();
    void setDia(int d);
    void setMes(int m);
    void setAnyo(int a);
    bool isBisiesto();
};