#include <iostream>
#include <fstream>
#include <string>

using namespace std;


void finfichero(unsigned n, string fichero)
{
    string line;
    ifstream fl(fichero); 

    if (fl.is_open())
    {
        fl.seekg(EOF); // Va al final del archivo
        for (unsigned i=0; i<n; i++)
        {
            fl.unget();
        }
        while( getline(fl,line) )
        {
            cout << line ;
        }
    }
    else
    {
        cout << "No se ha podido leer el archivo." << endl;
    }
    
}


int main()
{   
    string fichero;
    unsigned n;

    cin >> n;
    cin >> fichero;

    finfichero(n, fichero);

    return 0;
}