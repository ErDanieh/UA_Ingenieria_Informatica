#ifndef _LIST_H_
#define _LIST_H_

#include <iostream>
#include <vector>
#include <string>
#include "Movie.h"

using namespace std;



class List
{
  friend ostream &operator<<(ostream &os, const List &l);
  private:
    vector <Movie> movies;
    string name;
    const bool searchMovie(string title);
  public:
    List(string name);
    void addMovie(string desc, Genre genre);
    float getMeanScore() const;
};

#endif