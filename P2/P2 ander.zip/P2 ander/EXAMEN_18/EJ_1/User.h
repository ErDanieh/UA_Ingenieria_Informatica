#ifndef _USER_H_
#define _USER_H_

#include <iostream>
#include <string>
#include <vector>
#include "Tweet.h"

class User
{
  friend ostream &operator<<(ostream &os, const User &u);
  private:
    vector <Tweet> tweets;
    string name;
    string email;
  public:
    User(string name, string email);
    unsigned int writeTweet(string text,const vector <string> &users);
    void addTweet(Tweet newTweet);
    string getName() const { return name; }
    Tweet getTweet(int pos) const { return tweets[pos]; }
    unsigned int getNumberOfTweets() const { return tweets.size(); };

};


#endif