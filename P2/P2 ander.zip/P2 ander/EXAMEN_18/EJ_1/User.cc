#include "User.h"


User::User(string name, string email){

  bool existeArroba = false;
  bool existePunto = false;
  bool existeTerminacion = false;
  

  // Comprobar el usuario
  for(unsigned i = 0; i < name.length(); i++){
    if(isalnum(name[i]) == false ){
      throw Exception(exception_name);
    }
  }

  this->name = name;

  // Comprobar el email
  for (unsigned i = 0; i < email.length() && existeArroba == false; i++){
    
    if(i!=0 && email[i] == '@'){
      existeArroba = true;
      
      for(unsigned j = i; j < email.length() && existePunto == false; j++){
        
        if(j!=i && email[j] == '.'){
          existePunto = true;

          if(j != email.length()){
            existeTerminacion = true;
          }
        }
      }
    }
  }

  if(existeArroba == false || existePunto == false || existeTerminacion == false){
    throw Exception(exception_email);
  }
  
  this->email = email;

}

void User::addTweet(Tweet newTweet){
  tweets.push_back(newTweet);
}


unsigned int User::writeTweet(string text,const vector <string> &users){
  int identificador = 0;
  try
  {
    Tweet tweet(text,users);
    tweets.push_back(tweet);
    identificador = tweet.getId();
  }
  catch(const Exception &e)
  {
    cout << "Error de excepcion. " << endl;
  }
  
  return identificador;
}


ostream &operator<<(ostream &os, const User &u){
  
  cout << u.name << " (" << u.email <<  ")" << endl;

  for (unsigned i = 0; i < u.tweets.size(); i++)
  {
    cout << u.tweets[i];
  }
  
  return os;
}