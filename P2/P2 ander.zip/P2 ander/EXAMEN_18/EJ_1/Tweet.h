#ifndef _TWEET_H_
#define _TWEET_H_

#include <iostream>
#include <string>
#include <vector>
#include <sstream>

using namespace std;

enum Exception { exception_mention, exception_name, exception_email, exception_pos};

class Tweet
{
  friend ostream &operator<<(ostream &os, const Tweet &t);

  private:
    string text;
    static unsigned int nextId;
    unsigned int id;
  public:
    Tweet(string text,const vector <string> &user);
    string getText() const { return text; };
    unsigned int getId() const { return id; };
    vector <string> getMentions() const;
};

#endif