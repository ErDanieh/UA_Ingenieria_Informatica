
#include <iostream>
#include <stdexcept>
#include <cstdlib>
#include "Fighter.h"

using namespace std;

Fighter::Fighter(string type,int attack,int shield)
{
  if (attack>0 && attack<100 && shield>0 && shield<100)
  {
    this->type=type;
    this->attack=attack;
    this->shield=shield;
  }
  else
    throw exception(); // si los valores de attack o shield están mal, se lanza una excepción
}

int Fighter::getRandomNumber(int n)
{
  return rand()%n;
}

bool Fighter::fight(Fighter &enemy)
{
  bool win=false;
  int nrand=getRandomNumber(100);     // devuelve un valor entre   0 y 99

  enemy.shield -= attack*nrand/100;

  if (enemy.shield <= 0)
     win=true;

  return win;
}

void Fighter::setAttack(int attack)
{
  if (attack>0 && attack<100)
    this->attack=attack;
  // else throw exception();  (otra posibilidad)
}

void Fighter::setShield(int shield)
{
  if (shield>0 && shield<100)
    this->shield=shield;
  // else throw exception();  (otra posibilidad)
}

ostream &operator<<(ostream &os,const Fighter &f)
{
  os << f.type << " (a=" << f.attack << ",s=" << f.shield << ")";
  return os;
}
