
#ifndef _SQUADRON_H_
#define _SQUADRON_H_

#include <vector>
#include "Fighter.h"

class Squadron {

 private:
   string name;
   int wins;
   int losses;
   vector<Fighter> fighters;

 public:

   Squadron(string filename,string name="");
   void fight(Squadron &enemy);

   friend ostream &operator<<(ostream &os,const Squadron &sq);
};


#endif
