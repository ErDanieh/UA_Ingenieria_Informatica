
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

typedef struct {
  string nombre;
  vector <string> familiares,amigos,enemigos;
} Personaje;

const int MAXNOM=40;

typedef struct {
  char nombre1[MAXNOM];
  int relacion;
  char nombre2[MAXNOM];
} PersBin;

const int FAMILIAR=0, ENEMIGO=1, AMIGO=2;

// busca el personaje en el vector y devuelve su posición
// si no está lo añade al final y devuelve la posición
int posicion(vector<Personaje> &vpers, string nom)
{
  int pos=-1;
  
  for (unsigned int i=0;i<vpers.size() && pos==-1;i++)
  {
    if (vpers[i].nombre == nom)
      pos=(int)i;
  }
  if (pos==-1)
  {
    Personaje p;
    
    p.nombre=nom;
    vpers.push_back(p);
    pos=(int)vpers.size()  - 1;
  }
  
  return pos;
}

void actualizarRelacion(vector<Personaje> &vpers,const PersBin pb)
{
  int p1,p2;
  
  p1=posicion(vpers,pb.nombre1);  // buscar o añadir el nombre 1
  p2=posicion(vpers,pb.nombre2);  // lo mismo para el nombre 2
  
  switch (pb.relacion)
  {
     case FAMILIAR:
       vpers[p1].familiares.push_back(pb.nombre2);  // añadir, si no estaba
       vpers[p2].familiares.push_back(pb.nombre1);
       break;
     case ENEMIGO:
       vpers[p1].enemigos.push_back(pb.nombre2);
       vpers[p2].enemigos.push_back(pb.nombre1);
       break;
     case AMIGO:
       vpers[p1].amigos.push_back(pb.nombre2);
       vpers[p2].amigos.push_back(pb.nombre1);
       break;
  }
}

void mostrarRelacionados(string prefijo,const vector<string> &vrel)
{
  if (vrel.size()>0)
  {
    cout << prefijo; // Relatives / Enemies / Friends
    for (unsigned int i=0;i<vrel.size();i++)
    {
      cout << vrel[i];
      if (i+1<vrel.size()) cout << ", ";  // si no es el último, imprimir la coma
    }
    cout << endl;
  }
}

void mostrarPersonajes(vector<Personaje> &vpers)
{
  for (unsigned int i=0;i<vpers.size();i++)
  {
    cout << "Name: " << vpers[i].nombre << endl;
    mostrarRelacionados("Relatives: ", vpers[i].familiares);
    mostrarRelacionados("Enemies: ", vpers[i].enemigos);
    mostrarRelacionados("Friends: ", vpers[i].amigos);
    cout << endl;
  }
}

int main(int argc, char *argv[])
{
  ifstream f;
  vector<Personaje> personajes;
  
  if (argc == 2)
  {
    f.open(argv[1],ios::in|ios::binary);
    if (f.is_open())
    {
      PersBin pb;
      
      while (f.read((char *)&pb,sizeof(pb)))
      {
        actualizarRelacion(personajes,pb);
      }
      f.close();
      
      mostrarPersonajes(personajes);
    }
    else
      cout << "Error al abrir el fichero" << endl;
  
  }
  else cout << "Error en los argumentos" << endl;
}
