#include <iostream>
#include "Region.h"
using namespace std;

int main(){
  Region r("Comunitat Valenciana"); 


  r.addStation("Alicante.txt");
  r.addStation("Alicante2.txt");
  //r.addStation("Valencia.txt");
  //r.addStation("Castellon.txt");
  //r.addStation("unknown.txt"); // No existe

  cout << r.getValue("Alicante",Tm,Sep) << endl;
  cout << r.getAvgTemp(Oct) << endl;
  cout << r.getWarmestStation(Aug) << endl;

  return 0;
}