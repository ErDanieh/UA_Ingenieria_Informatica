#include <iostream>
#include <fstream>
#include <cctype>
using namespace std;

struct Film{
	string title;
	string director;
	int year;
};


string sacaCampo(string linea){
	string cad;
	stringstream ss(linea);
	
	ss.getline(ss, cad, ':');
	ss.get();
	ss.getline(ss, cad);

	return ss;
}

void leerFichero2(const char filename[]){
	ifstream fich;
	string title, director, ignore;
	int year;
	vector<Film> films;
	Film nuevo;

	fich.open(filename);
	if(fich.is_open()){
		getline(fich, linea);		
		while(!fich.eof()){
			nuevo.title = sacaCampo(linea);
			getline(fich, linea);
			nuevo.director = sacaCampo(linea);
			getline(fich, linea);
			nuevo.year = atoi(sacaCampo(linea).c_str());
			films.push_back(nuevo);
			getline(fich, linea);			
		}
		fich.close();
		for(int i = 1; i < films.size(); i++){
			for(int j = films.size() - 1; j >= i ; j--){
				if(films[j].year < films[j - 1].year){
					Film aux = films[j];
					films[j] = films[j-1];
					films[j-1] = aux;
				}
			}
		}
		for(int i = 0; i < films.size(); i++){
			cout << films[i].year << ", ";
			cout << films[i].title << ", ";
			cout << films[i].director << endl;
		}
	}
	else{
		cout << "nombre de fichero no existe" << endl;
	}
}




void leerFichero(const char filename[]){
	ifstream fich;
	string title, director, ignore;
	int year;
	vector<Film> films;

	fich.open(filename);
	if(fich.is_open()){
		getline(fich, ignore, ':');
		while(!fich.eof()){
			fich.get();
			getline(fich, title);
			getline(fich, ignore, ':');
			fich.get();
			getline(fich, director);
			getline(fich, ignore, ':');
			fich >> year;
			fich.get(); // me quito el salto de linea.
			Film nuevo;
			nuevo.title = title;
			nuevo.director = director;
			nuevo.year = year;
			films.push_back(nuevo);
			getline(fich, ignore, ':');			
		}
		fich.close();
		for(int i = 1; i < films.size(); i++){
			for(int j = films.size() - 1; j >= i ; j--){
				if(films[j].year < films[j - 1].year){
					Film aux = films[j];
					films[j] = films[j-1];
					films[j-1] = aux;
				}
			}
		}
		for(int i = 0; i < films.size(); i++){
			cout << films[i].year << ", ";
			cout << films[i].title << ", ";
			cout << films[i].director << endl;
		}
	}
	else{
		cout << "nombre de fichero no existe" << endl;
	}
}



int main(int argc, char *argv[]){
	if(argc == 2){
		leerFichero(argv[1]);
	}
	else{
		cout << "Ussage: ./main filename" << endl;
	}
	return 0;
}
