#include "Animal.h"
#include <sstream>

ostream &operator<<(ostream &os, const Animal &a){
	os << a.name << "(" << Animal::getStringOf(a.type);
	os << "), age=" << a.age << ", owner=" << a.owner;
	return os;
}

AnimalType Animal::getTypeOf(string s){
	AnimalType type;
	if(s == "Cat"){
		type = Cat;
	}
	else{
		if(s == "Dog"){
			type = Dog;
		}
		else{
			if(s == "Jerbo"){
				type = Jerbo;
			}
			else{
				throw s;
			}
		}
	}
	return type;
}

string Animal::getStringOf(AnimalType type){
	string cadena;
	switch(type){
		case Cat:
			cadena = "Cat";
		break;
		case Dog:
			cadena = "Dog";
		break;
		case Jerbo:
			cadena = "Jerbo";
		break;
	}
	return cadena;
}

Animal::Animal(string s){
	stringstream ss(s);
	string tipo;
	
	getline(ss, name, ',');
	getline(ss, tipo, ',');
	ss >> age;
	//type = tipo; // AnimalType = string ERROR!
	type = getTypeOf(tipo); // si el tipo es incorrecto me lanza 1, se cancela este porque no lo captura y  lo propaga.
	owner = "";
}

string Animal::getName() const{
	return name;
}

unsigned Animal::getAge() const{
	return age;
}

AnimalType Animal::getAnimalType() const{
	return type;
}

string Animal::getOwner() const{
	return owner;
}

void Animal::adopthitler(string owner){
	this->owner = owner;
}

bool Animal::isAdopted() const{
	return owner != "";
}



