#include <iostream>
using namespace std;

#include "Youtuber.h"

int main(){
	Youtuber y("pistacho", "http://www.youtube.com/channel/hbo");
	cout << y << endl;


	try{
		Youtuber y2("", "http://www.youtube.com/channel/hxo");
		cout << y2 << endl;
	}
	catch(int &e){
		cout << e << endl;
	}


	try{
		Youtuber y4("asdfa", "httyoutube.com/channel/hxo");
		cout << y4 << endl;
	}
	catch(int &e){
		cout << e << endl;
	}


	return 0;
}
