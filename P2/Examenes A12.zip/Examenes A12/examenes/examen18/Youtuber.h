#ifndef _YOUTUBER_
#define _YOUTUBER_
#include <iostream>
using namespace std;


class Youtuber{
	friend ostream &operator<<(ostream &os, const Youtuber &y);
	private:
		string nick;
		string url;
		bool penalized;
		float profits;
	public:
		Youtuber(string nick, string url);
		string getNick() const;
		string getUrl() const;
		bool isPenalized() const;
		void setPenalized(bool penalized);
		void addProfits(float profits);
};

#endif
