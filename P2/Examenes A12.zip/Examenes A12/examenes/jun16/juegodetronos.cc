#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

struct Personaje{
	string name;
	vector<string> relatives;
	vector<string> enemies;
	vector<string> friends;
};

struct Entrada{
	char nombre1[40];
	int relacion;
	char nombre2[40];
};

/*
func composicion<P, Q, R>(f:(P) -> Q, g:(R) -> P, x : R) -> Q{
  return f(g(x))
}
*/

int buscarEntrada(vector<Personaje> personas, string nombre){
	int pos, i;
	pos = -1;
	for(i = 0; i < personas.size() && pos == -1; i++){
		if(nombre == personas[i].name){
			pos  = i;
		}
	}
	return pos;
}

void procesarEntrada(Entrada nueva, vector<Personaje> &personajes){
	int pos1, pos2;
	pos1 = buscarEntrada(personajes, nueva.nombre1);
	pos2 = buscarEntrada(personajes, nueva.nombre2);
	switch(nueva.relacion){
		case 0:
			personajes[pos1].relatives.push_back(nueva.nombre2);
			personajes[pos2].relatives.push_back(nueva.nombre1);
		break;
		case 1:
			personajes[pos1].enemies.push_back(nueva.nombre2);
			personajes[pos2].enemies.push_back(nueva.nombre1);
		break;
		case 2:
			personajes[pos1].friends.push_back(nueva.nombre2);
			personajes[pos2].friends.push_back(nueva.nombre1);
		break;
	}
}

void leerFichero(string nombreFichero){
	ifstream fich;
	Entrada entrada;
	vector<Personaje> personajes;

	fich.open(nombreFichero.c_str(), ios::binary);
	if(fich.is_open()){
		fich.read((char *) &entrada, sizeof(Entrada));
		while(!fich.eof()){
			procesarEntrada(entrada, personajes);
			fich.read((char *) &entrada, sizeof(Entrada));
		}
		fich.close();
		for(int i = 0; i < personajes.size(); i++){
			cout << "Name: " << personajes[i].name << endl;
			cout << "Relatives: ";
			for(int j = 0; j < personajes[i].relatives.size(); j++){
				cout << personajes[i].relatives[j];
				if(j != personajes[i].relatives.size() - 1){
					cout << ", ";
				}
			}
			cout << endl;
			cout << "Enemies: ";
			for(int j = 0; j < personajes[i].relatives.size(); j++){
				cout << personajes[i].enemies[j];
				if(j != personajes[i].enemies.size() - 1){
					cout << ", ";
				}
			}
			cout << endl;
			cout << "Friends: ";
			for(int j = 0; j < personajes[i].relatives.size(); j++){
				cout << personajes[i].friends[j];
				if(j != personajes[i].friends.size() - 1){
					cout << ", ";
				}
			}
			cout << endl;
		}
	}
}

int main(int argc, char *argv[]){
	if(argc == 2){
		leerFichero(argv[1]);
	}
	return 0;
}

