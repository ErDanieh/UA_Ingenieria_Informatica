#include "Movie.h"

const int Movie::NS = -1;


  
Movie::Movie(string title, Genre genre, int score){
	/*// el titulo tiene que tener al menos 5 caracteres.	
	if(title.length() < 5){
		throw title; // lanza un string, catch(string &e)
	}
	if(title.length() > 100){
		throw "Demasiado largo"; // catch(const char *e)
	}*/
	if(score < -1 || score > 5){
		throw score; // lanza un tipo int, catch(int &e)
	}
	this->score = score;
	this->genre = genre;
	this->title = title;
}

string Movie::getTitle() const{
	return title;
}

int Movie::getScore() const{
	return score;
}

Genre Movie::getGenre() const{
	return genre;
}

// es estatico no tiene objeto implicito, solo tiene
// como parametro genre.
// string Util::error(Error &e)
string Movie::genreToString(Genre genre){
	string s;
	switch(genre){
		case 0:
			s = "Action";
		break;
		case 1:
			s = "SciFi";
		break;
		case 2:
			s = "Drama";
		break;
		case 3:
			s = "Comedy";
		break;
	}
	return s;
}

ostream &operator<<(ostream &os, const Movie &movie){
	os << movie.title << " (" << movie.score << ") ";
	os << movie.genre; // sale el valor entero del enum.
	return os;
}
