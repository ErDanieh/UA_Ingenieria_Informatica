#include <iostream>
#include "Movie.h"
using namespace std;

int main(){
	string title;
	int score;

	while(true){
		try{
			cout << "Titulo: ";
			getline(cin, title);
			cout << "Score: ";
			cin >> title;
			cin.get();
			Movie movie(title, Comedy); // score = -1
			cout << movie << endl;			
			break;		
		}
		catch(int &e){
			cout << "wrong score: " << e << endl;
		}
		catch(string &t){
			cout << "titulo muy corto: " << t << endl;
		}
		catch(const char *e){
			cout << e << endl;
		}
	}
	
	return 0;
}
