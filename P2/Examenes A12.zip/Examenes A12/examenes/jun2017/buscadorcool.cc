#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

struct Entrada{
	int id, veces;
};

struct Documento{
	char title[50];
	char url[50];
	int length;
};




// busca la palabra en el fichero y devuelve la linea.
// devuelve una cadena tal que asi : "0:3|3:5|4:2|12:32|3:34"
string leerInfoPalabra(string buscada){
	ifstream fich;
	bool leido_fich = false, encontrada;
	string palabra;
	string resto = "";

	fich.open("index.txt");
	if(fich.is_open()){
		leido_fich = true;
		encontrada = false;
		getline(fich, palabra, '|');
		while(!fich.eof() && !encontrada){
			getline(fich, resto);			
			if(palabra == buscada){
				encontrada = true;
			}
			else{
				getline(fich, palabra, '|');
			}
		}	
		fich.close();
	}
	if(!encontrada){
		resto = "";
	}
	return resto;
}


// "0:3|3:5|4:2|12:32|3:34"
void buscarFrecuencia(string palabra){
	double frec, mayor_frec;
	int pos_mayor;
	int i, veces;
	Documento leido;
	string cad_id, cad_veces;
	int posicionDocumento;
	string resto;
	ifstream fichBin;

	resto = leerInfoPalabra(palabra);
	if(resto != ""){
		fichBin.open("documents.bin", ios::binary);
		if(fichBin.is_open()){
			i = 0;
			mayor_frec;
			while(i < resto.length()){
				cad_id = "";
				while(resto[i] != ':'){
					cad_id += resto[i++];
				}
				i++;
				cad_veces = "";
				while(i < resto.length() && resto[i] != '|'){
					cad_veces += resto[i++];
				}
				i++;
				posicionDocumento = atoi(cad_id.c_str());
				veces = atoi(cad_veces.c_str());			
				fichBin.seekg(sizeof(Documento) * posicionDocumento);
				fichBin.read((char *) &leido, sizeof(leido));	
				frec = (double) veces / leido.length;
				if(frec > mayor_frec){
					mayor_frec = frec;
					pos_mayor = posicionDocumento;
				}
			}
			fichBin.seekg(sizeof(Documento) * pos_mayor);
			fichBin.read((char *) &leido, sizeof(leido));	
			cout << leido.title << " (";
			cout << leido.url << ") [";
			cout << mayor_frec << "]\n";
			fichBin.close();		
		}
	}
}

int main(int argc, char * argv[]){
	if(argc == 2){
		buscarFrecuencia(argv[1]);
	}
	
}





