#include <vector>
#include <iostream>
#include <sstream>
#include <fstream>
using namespace std;

struct Politico{
	string nombre;
	int total, encontrados;
};

void leerPoliticos(string nombre, vector<Politico> &politicos){
	ifstream fich;
	string linea;

	fich.open(nombre.c_str());
	if(fich.is_open()){
		getline(fich, linea);
		while(!fich.eof()){
			Politico nueva;
			nueva.nombre = linea;
			nueva.total = 0;
			nueva.encontrados = 0;
			politicos.push_back(nueva);
			getline(fich, linea);			
		}
		fich.close();	
	}
}

bool buscarPalabraLinea(string linea, string buscada){
	bool encontrada = false;
	string palabra;
	stringstream ss(linea);
	while(ss >> palabra){
		if(palabra == buscada){
			encontrada = true;
		}
	}
	return encontrada;
}

void procesarLinea(vector<Politico> &politicos, string linea, string buscada){
	stringstream ss(linea);
	string palabra;
	bool encontrada = buscarPalabraLinea(linea, buscada);

	// tenemos que saber si la palabra esta en la linea antes
	// de empezar a recorrerla.
	while(ss >> palabra){
		if(palabra[0] == '@'){
			for(int i = 0; i < politicos.size(); i++){
				if(palabra == politicos[i].nombre){
					politicos[i].total++;
					if(encontrada){
						politicos[i].encontrados++;
					}
				}
			}

		}
	}	
}

void procesarTweets(string ftweets, vector<Politico> &politicos, string buscada){
	ifstream fich;
	string linea;
	double ratio;
	
	fich.open(ftweets.c_str());
	if(fich.is_open()){
		getline(fich, linea);
		while(!fich.eof()){
			procesarLinea(politicos, linea, buscada);
			getline(fich, linea);
		}
		fich.close();
		for(int i = 0; i < politicos.size(); i++){
			cout << politicos[i].nombre << " (Total: ";
			cout << politicos[i].total << "; Encontrados: ";
			cout << politicos[i].encontrados << "; Ratio: ";
			if(politicos[i].total != 0){
				ratio = (double)politicos[i].encontrados/politicos[i].total * 100;
			}
			else{
				ratio = 00000;
			}			
			cout << ratio << "%)" << endl;
		}
	}
}

void analizar(string ftweets, string fpoliticos, string buscada){
	vector<Politico> politicos;

	leerPoliticos(fpoliticos, politicos);	
	procesarTweets(ftweets, politicos, buscada);

}

int main(int argc, char *argv[]){
	if(argc == 3){
		analizar(argv[1], argv[2], argv[3]);
	}
}





