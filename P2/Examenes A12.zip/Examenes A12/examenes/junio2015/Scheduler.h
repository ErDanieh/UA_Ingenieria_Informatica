#ifndef _SCHEDULER_
#define _SCHEDULER_
#include <vector>
#include <iostream>
#include "Hoguera.h"
using namespace std;

class Scheduler{
	friend ostream &operator<<(ostream &os, const Scheduler &scheduler);
	private:
		vector<string> teams;
		vector<Hoguera> hogueras;
	public:
		Scheduler(string fileName);
		void addTeam(string team);
		void distributeTeams();
		int getMinor() const;
};

#endif
