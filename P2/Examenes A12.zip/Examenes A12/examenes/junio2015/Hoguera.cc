#include "Hoguera.h"
#include <sstream>

int Hoguera::idNextHoguera = 1;

// "Maissonnave:14"
Hoguera::Hoguera(string line){
	stringstream ss(line);
/*
	pos = line.find(":");
	name = line.substr(0, pos);
	time = atoi(line.substr(pos+1).c_str());
*/
	getline(ss, name, ':');
	ss >> time;
	
	id = idNextHoguera;
	idNextHoguera++;
	team = "";
}

int Hoguera::getTime() const{
	return time;
}

string Hoguera::getTeam() const{
	return team;
}

void Hoguera::setTime(int time){
	this->time = time;
}

void Hoguera::setTeam(string team){
	this->team = team;
}

ostream &operator<<(ostream &os, const Hoguera &hoguera){
	os << hoguera.name << "(" << hoguera.id << ")=" << hoguera.time;
	return os;
}
