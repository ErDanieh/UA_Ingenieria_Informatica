#ifndef _FIGHTER_
#define _FIGHTER_
#include <iostream>
using namespace std;
class Fighter{
	friend ostream &operator<<(ostream &os, const Fighter &f);
	private:
		string type;
		int attack;
		int shield;
	public:
		Fighter(string type, int attack, int shield);
		static int getRandomNumber(int n);
		bool fight(Fighter &f);
		int getAttack() const;
		int getShield() const;
		void setAttack(int attack);
		void setShield(int shield);
};
#endif
