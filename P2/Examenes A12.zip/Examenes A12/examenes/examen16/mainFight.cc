#include <iostream>
#include "Fighter.h"
using namespace std;


int main(){
	Fighter ship1("x-wing", 30, 40);
	Fighter ship2("tie-wing", 20, 50);

	bool defeated = ship1.fight(ship2);

	cout << defeated << endl;	

	cout << ship1 << endl;
	cout << ship2 << endl;


	defeated = ship1.fight(ship2);

	cout << defeated << endl;	

	cout << ship1 << endl;
	cout << ship2 << endl;


}
