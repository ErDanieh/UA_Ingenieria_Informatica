#include "Squadron.h"
int main()
{
	Squadron a("first.txt","smarters"), b("second.txt","gordis");
	cout << "---" << endl << a << endl;
	a.fight(b);
	cout << "---" << endl << a << endl << b << endl;
}
