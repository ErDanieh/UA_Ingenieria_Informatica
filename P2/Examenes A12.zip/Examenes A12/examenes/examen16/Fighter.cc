#include "Fighter.h"
#include <cstdlib>

Fighter::Fighter(string type, int attack, int shield){
	if(shield < 0 || shield > 99 || attack < 0 || attack > 99){
		throw 1;
	}
	this->shield = shield;
	this->attack = attack;
	this->type = type;

}
/*
Fighter::Fighter(string type, int attack, int shield){
	if(shield >= 0 && shield <= 99 && attack >= 0 && attack <= 99){
		this->shield = shield;
		this->attack = attack;
		this->type = type;
	}
	else{
		throw 1;
	}
}
*/
// como no uso atributos de instancia, lo declaro estatdiciidco
int Fighter::getRandomNumber(int n){
	return rand() % n;
}

// this = atacante
// f es el atacado
bool Fighter::fight(Fighter &enemy){
	int damage;
	bool destroyed = false;
	damage = (int) (attack * getRandomNumber(100) / 100.0);
	enemy.shield -= damage;
	if(enemy.shield < 0){
		destroyed = true;
	}
	return destroyed;
}

int Fighter::getAttack() const{
	return attack;
}

int Fighter::getShield() const{
	return shield;
}

void Fighter::setAttack(int attack){
	this->attack = attack;
}

void Fighter::setShield(int shield){
	this->shield = shield;
}

ostream &operator<<(ostream &os, const Fighter &f){
	os << f.type << "(a=" << f.attack << ",s=" << f.shield << ")";
	return os;
}




