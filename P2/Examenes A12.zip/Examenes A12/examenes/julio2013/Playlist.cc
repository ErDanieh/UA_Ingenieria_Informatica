#include "Playlist.h"
#include <algorithm>
bool Playlist::buscarCancion(const Cancion &c) const{
	bool encontrado = false;
	for(int i = 0; i < canciones.size() && !encontrado; i++){
		if(canciones[i].getNombre() == c.getNombre() &&
			canciones[i].getArtista() == c.getArtista()){
			encontrado = true;
		}
	}
	return encontrado;
}

Playlist::Playlist(string nombre){
	this->nombre = nombre;
}

float Playlist::getPuntuacionMedia() const{
	float suma = 0;
	int puntuadas = 0;
	for(int i = 0; i < canciones.size(); i++){
		if(canciones[i].getPuntuacion() != Cancion::SP){
			suma = suma + canciones[i].getPuntuacion();
			puntuadas ++;
		}		
	}
	if(puntuadas > 0){
		suma = suma / puntuadas;
	}
	return suma;
}
// un vector con los nombres de los artistas sin duplicados.
vector<string> Playlist::getArtistas() const{
	vector<string> nombres;

	for(int i = 0; i < canciones.size(); i++){
		if(find(nombres.begin(), nombres.end(), canciones[i].getNombre()) == nombres.end()){
			nombres.push_back(canciones[i].getNombre());
		}
	}
	return nombres;
}

/*
vector<string> Cancion::getArtistas() const{
	vector<string> nombres;
	bool encontrado;
	for(int i = 0; i < canciones.size(); i++){
		encontrado = false;
		for(int j = 0; j < nombres.size() && !encontrado; j++){
			if(nombres[j] == canciones[i].getNombre()){
				encontrado = true;	
			}
		}
		if(encontrado){
			nombres.push_back(canciones[i].getNombre());
		}
	}
	return nombres;
}
*/

bool Playlist::anyadirCancion(const Cancion &c){
	bool anyadida = false;
	bool encontrado;
	encontrado = buscarCancion(c);
	if(!encontrado){
		canciones.push_back(c);
		anyadida = true;
	}
	return anyadida;
}

ostream &operator<<(ostream &os, const Playlist &pl){
	vector<string> artistas;
	os << "Titulo: " << pl.nombre << endl;
	os << "Artistas: ";
	artistas = pl.getArtistas();
	for(int i = 0; i < artistas.size(); i++){
		os << artistas[i];
		if(i != artistas.size() - 1){
			os << ",";		
		}
	}
	os << endl;
	os << "-----------" << endl;
	for(int i = 0; i < pl.canciones.size(); i++){
		os << pl.canciones[i] << endl;
	}
	os << "-----------" << endl;

	return os;
}






