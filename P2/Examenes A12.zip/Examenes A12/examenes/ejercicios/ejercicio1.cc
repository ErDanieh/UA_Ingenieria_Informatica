#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
/*
Dada la siguiente estructura. Pedir al usuario, title, url y cantidad
	de palabras de la cantidad de documentos seleccionada por el y 
	almacenarlos en un fichero binario llamado documents.bin

	¿Cuantos documentos quieres almacenar? 3
	doc 1
	------
	title:
	url:
	length:  <y almacenas en el fichero binario>
	
	doc 2
	------
	title:
	url:
	length:  < y almacenas en el fichero binario>

	doc 3
	------
	title:
	url:
	length:  < y almacenas en el fichero binario>

*/
struct Documento{
	char title[50];
	char url[50];
	int length;
};

int main(){
	string title, url;
	int length, cuantos;
	ofstream fich;
	Documento doc;
	
	fich.open("documents.bin", ios::binary);
	if(fich.is_open()){
		cout << "¿Cuantos documentos quieres almacenar? ";
		cin >> cuantos;
		cin.get();
		for(int i = 1; i <= cuantos; i++){
			cout << "doc " << i << endl;
			cout << "------" << endl;
			cout << "title: ";
			getline(cin, title);
			cout << "url: ";
			getline(cin, url);
			cout << "length: ";
			cin >> length;
			cin.get();
			strncpy(doc.title, title.c_str(), 50);
			doc.title[49] = '\0';
			strncpy(doc.url, url.c_str(), 50);
			doc.url[49] = '\0';
			doc.length = length;
			fich.write((const char *) &doc, sizeof(doc));
		}
		fich.close();
	}			
	return 0;
}









































