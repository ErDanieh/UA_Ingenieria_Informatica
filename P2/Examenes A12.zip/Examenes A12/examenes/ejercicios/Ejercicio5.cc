/*
	Queremos encontrar los numeros que se han escrito en nuestro fichero "texto.txt"
	para ello realizaremos un programa que abra dicho fichero, extraiga los numeros
	a un vector y los muestre ordenados de menor a mayor sin repetidos.
	Se considera numero cualquier digitos secuencia de digitos que aparezca en el fichero.

	la casa89 de la calle mayor que viven 3 personas negras69
	son 34muy inteligentes pero a ve34 puto facha99


	>> 3 34 69 89 99	
*/
#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include <cstring>
using namespace std;

void extraerNumerosLinea(string linea, vector<int> &numeros){
	string cad_num;
	int i, num;
	i = 0;
	while(i < linea.length()){
		while(i < linea.length() && !isdigit(linea[i]) ){
			i++;
		}
		cad_num = "";
		while(i < linea.length() && isdigit(linea[i])) {
			cad_num += linea[i++];
		}
		if(cad_num != ""){
			num = atoi(cad_num.c_str());
			if(find(numeros.begin(), numeros.end(), num) == numeros.end()){		
				numeros.push_back(num);
			}
		}
	}
}

void sumarNumeros(){
	ifstream fich;
	int total;
	vector<int> numeros;
	string linea;

	fich.open("texto.txt");
	if(fich.is_open()){
		getline(fich, linea);
		while(!fich.eof()){
			extraerNumerosLinea(linea, numeros);
			getline(fich, linea);
		}
		sort(numeros.begin(), numeros.end());
		for(int i = 0; i < numeros.size(); i++){
			cout << numeros[i] << " ";
		}
		cout << endl;
		fich.close();
	}
	
}


int main(int argc, char *argv[]){
	sumarNumeros();
	return 0;
}
