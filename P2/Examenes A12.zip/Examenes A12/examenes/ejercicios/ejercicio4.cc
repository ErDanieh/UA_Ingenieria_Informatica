/*Programa que lee dos ficheros de texto y crea un nuevo fichero de texto intercalando
las lineas de ambos ficheros:
	
	fich1		fich2		resultado
	lin1		l1		lin1
	lin2		l2		l1
	lin3		l3		lin2
	lin4				l2
	lin5				lin3
					l3
					lin4
					lin5
*/
#include <fstream>
#include <iostream>
using namespace std;

int main(int argc, char *argv[]){
	ifstream fich1, fich2;
	ofstream resultado;
	string linea1, linea2;

	if(argc == 4){
		fich1.open(argv[1]);
		if(fich1.is_open()){
			fich2.open(argv[2]);
			if(fich2.is_open()){
				resultado.open(argv[3]);
				if(resultado.is_open()){
					getline(fich1, linea1);
					getline(fich2, linea2);
					while(!fich1.eof() || !fich2.eof()){
						if(!fich1.eof()){
							resultado << linea1 << endl;
						}
						if(!fich2.eof()){						
							resultado << linea2 << endl;
						}					
						getline(fich1, linea1);
						getline(fich2, linea2);
					}
					resultado.close();	
				}
				fich2.close();
			}
			fich1.close();			
		}
	}

	return 0;
}
