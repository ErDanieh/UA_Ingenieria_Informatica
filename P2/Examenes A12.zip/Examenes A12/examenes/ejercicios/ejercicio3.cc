/*
	3. Programa que lee dos ficheros cuyo nombre se pasa como parametro al programa
	y muestra por pantalla el que mas palabras por linea tiene de media.
		palabras/lineas
*/
#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;

/*
// considerando que las palabras son secuencias de caracteres separadas por uno o varios espacios
int getPalabras(string linea) {
	int cuantas;
	string aux;
	stringstream ss(linea);
	cuantas = 0;
	while(ss >> aux){
		cuantas++;
	}

	return cuantas;
}
*/

// considerando que las palabras son las secuencias de letras.
int getPalabras(string linea){
	int cuantas;
	string palabra;
	int i;
	cuantas = 0;
	i = 0;
	while(i < linea.length()){
		while(i < linea.length() && isalpha(linea[i]) == 0){
			i++;
		}
		palabra = "";
		while(i < linea.length() && isalpha(linea[i]) != 0){
			palabra += linea[i];
			i++;
		}
		if(palabra != ""){
			cuantas++;
		}
	}
	return cuantas;
}



double contarPalabrasLinea(string nombre){
	double ratio;
	int totalPalabras, totalLineas;
	string linea;
	ifstream fich;
	
	fich.open(nombre.c_str());
	if(fich.is_open()){
		totalLineas = 0;
		totalPalabras = 0;
		getline(fich, linea);
		while(!fich.eof()){
			totalLineas++;
			totalPalabras += getPalabras(linea);
			getline(fich, linea);
		}
	}
	if(totalLineas > 0){
		ratio = (float)totalPalabras/totalLineas;
	}
	else{
		ratio = 0;	
	}

	return ratio;
}



void cmpFicheros(string nomfich1, string nomfich2){
	double pal1, pal2;
	pal1 = contarPalabrasLinea(nomfich1);
	pal2 = contarPalabrasLinea(nomfich2);
	if(pal1 > pal2){
		cout << nomfich1 << " [" << pal1 << "]" << endl;
	}
	else{
		cout << nomfich2 << " [" << pal2 << "]" << endl;
	}
}


int main(int argc, char * argv[]){
	if(argc == 3){
		cmpFicheros(argv[1], argv[2]);
	}
	return 0;
}

