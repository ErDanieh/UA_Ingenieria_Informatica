#ifndef _AJEDREZ_
#define _AJEDREZ_
#include "Pieza.h"
#include <iostream>
#include <sstream>
#include <fstream>
using namespace std;

class Ajedrez{
	private:
		string nombre;
		Pieza tablero[8][8];
		static bool comprobarCoordenadas(int x, int y);	
	public:
		Ajedrez(string nombre);
		Ajedrez(string nombre, string nombrefichero);
		void inicializarTablero();
		bool leerFichero(string nombreFichero);
		bool anyadirPieza(const Pieza &p, int x, int y);
		bool moverPieza(int ox, int oy, int dx, int dy);
		bool borrarPieza(int y, int x);
		void mostrar();
};

#endif
