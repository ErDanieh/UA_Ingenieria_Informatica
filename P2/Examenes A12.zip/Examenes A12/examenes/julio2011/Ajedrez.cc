#include "Ajedrez.h"


// devolver cierto si las coordenadas estan dentro del tablero.
bool Ajedrez::comprobarCoordenadas(int x, int y){
	bool correctas  =false;
	if(x >= 0 && x <= 7 && y >= 0 && y <= 7){
		correctas = true;
	}
	return correctas;
}



// inicializar el tablero todo con piezas vacias :)
Ajedrez::Ajedrez(string nombre){
	this->nombre = nombre;
	// cuando creamos la matriz de 8x8 como es de tipo Pieza
	// en cada una de las casillas de la matriz habra una Pieza.
	// C++ invoca al constructor de Pieza para inicializar cada
	// una de las piezas del tablero. Como no tenemos un constructor
	// sin parametros, usara el constructor parametrizado con sus
	// valores por defecto tipo = ' '
}

Ajedrez::Ajedrez(string nombre, string nombrefichero){
	this->nombre = nombre;
	
}

bool Ajedrez::anyadirPieza(const Pieza &p, int x, int y){
	bool anyadida = false;
	if(comprobarCoordenadas(x, y)){
		if(p.getTipo() != tablero[x][y].getTipo()){
			tablero[x][y] = p;
			anyadida = true;
		}
	}
	return anyadida;
}
