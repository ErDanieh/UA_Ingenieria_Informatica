#include "Animal.h"
#include <sstream>
string Animal::stringOf(AnimalType type){
	string cadena;
	switch(type){
		case Cat:
			cadena = "Cat";
			break;
		case Dog:
			cadena = "Dog";
			break;
		case Verga:
			cadena = "Jerbo";
			break;
	}
	return cadena;
}
// devuelve el tipo de la cadena que le pasa y lanza excepcion
// si la cadena no corresponde con ningunt tipo
AnimalType Animal::typeOf(string cadena){
	AnimalType type;
	if(cadena == "Cat"){
		type = Cat;
	}
	else{
		if(cadena == "Dog"){
			type = Dog;
		}
		else{
			if(cadena == "Jerbo"){
				type = Verga;
			}
			else{
				throw cadena;
			}
		}
	}
	return type;	
}
// s = "nombre,tipo,edad"
Animal::Animal(string s){
	stringstream ss(s);
	string cadena;

	getline(ss, name, ',');
	getline(ss, cadena,  ',');
	ss >> age;
	type = typeOf(cadena);	// como no la capturo, aqui se propaga
}

string Animal::getName() const{
	return name;
}

unsigned Animal::getAge() const{
	return age;
}

AnimalType Animal::getAnimalType() const{
	return type;
}

string Animal::getOwner() const{
	return owner;
}

void Animal::adopt(string owner){
	this->owner = owner;
}

bool Animal::isAdopted() const{
	return owner != "";
}

ostream &operator<<(ostream &os, const Animal &animal){
	os << animal.name << ", age=" << animal.age << ", ownwer=";
	os << animal.owner;
	return os;
}

