#ifndef _SHELTER_
#define _SHELTER_
#include "Animal.h"
#include <vector>
using namespace std;

class Shelter{
	friend ostream &operator<<(ostream &os, const Shelter &shelter);
	private:
		static const unsigned MAXADOPTED;
		string name;
		vector<Animal> animals;
		int search(const Animal &a) const;
		bool ownerIsValid(string owner) const;
	public:
		Shelter(string name = "Natura Shelter");
		bool add(const Animal &a);
		bool adopt(const Animal &a, string owner);
};



#endif
