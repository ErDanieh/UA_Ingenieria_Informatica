/*
	Queremos encontrar los numeros que se han escrito en nuestro fichero "texto.txt"
	para ello realizaremos un programa que abra dicho fichero, extraiga los numeros
	a un vector y los muestre ordenados de menor a mayor sin repetidos.
	Se considera numero cualquier digitos secuencia de digitos que aparezca en el fichero.

	la casa89 de la calle mayor que viven 3 personas negras69
	son 34muy inteligentes pero a ve34 puto facha99


	>> 3 34 69 89 99	
*/
