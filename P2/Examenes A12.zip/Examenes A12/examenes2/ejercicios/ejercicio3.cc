/*
	3. Programa que lee dos ficheros cuyo nombre se pasa como parametro al programa
	y muestra por pantalla el que mas palabras por linea tiene de media.
		palabras/lineas
*/
#include <iostream>
#include <fstream>
#include <sstream>
using namespace std;

// secuencia de una o mas caracteres separados por una o mas caracteres en lineas
int contarPalabrasLinea(string linea){
	int totalPalabras = 0;
	stringstream ss(linea);
	string aux;
	while(ss >> aux){
		totalPalabras++;
	}	
	return totalPalabras;
}

double mediaFichero(string nombre){
	double media = 0;
	ifstream fich;
	int totalPalabras, totalLineas;
	string linea;

	fich.open(nombre.c_str());
	if(fich.is_open()){
		totalPalabras = totalLineas =  0;
		getline(fich, linea);
		while(!fich.eof()){
			totalPalabras += contarPalabrasLinea(linea);
			totalLineas++;
			getline(fich, linea);
		}
		fich.close();
		media = (float) totalPalabras / totalLineas;
	}
	return media;
}


void cmpFicheros(string nf1, string nf2){
	double media1, media2;

	media1 = mediaFichero(nf1);
	media2 = mediaFichero(nf2);
	if(media1 > media2){
		cout << nf1 << " [" << media1 << "]" << endl;
	}
	else{
		cout << nf2 << " [" << media2 << "]" << endl;
	}

}

int main(int argc, char *argv[]){
	if(argc == 3){
		cmpFicheros(argv[1], argv[2]);
	}
}
