#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
/*
Dada la siguiente estructura. Pedir al usuario, title, url y cantidad
	de palabras de la cantidad de documentos seleccionada por el y 
	almacenarlos en un fichero binario llamado documents.bin

	¿Cuantos documentos quieres almacenar? 3
	doc 1
	------
	title:
	url:
	length:  <y almacenas en el fichero binario>
	
	doc 2
	------
	title:
	url:
	length:  < y almacenas en el fichero binario>

	doc 3
	------
	title:
	url:
	length:  < y almacenas en el fichero binario>

*/
struct Documento{
	char title[50];
	char url[50];
	int length;
};
int main(){
	ofstream fich;
	Documento leido;	
	string title, url;
	int length;
	int ndocs;

	fich.open("documents.bin", ios::binary);
	if(fich.is_open()){
		cout << "Cuantos documentos quieres almacenar: ";
		cin >> ndocs;
		cin.get();
		for(int i = 1; i <= ndocs; i++){
			cout << "Title: ";
			getline(cin, title);
			cout << "URL: ";
			getline(cin, url);
			cout << "Length: ";
			cin >> length;
			cin.get();
			strncpy(leido.title, title.c_str(), 50);
			leido.title[49] = '\0';
			strncpy(leido.url, url.c_str(), 50);
			leido.title[49] = '\0';
			leido.length = length;
			fich.write((const char *) &leido, sizeof(leido)); 
		}
		fich.close();
	}
	return 0;
}























