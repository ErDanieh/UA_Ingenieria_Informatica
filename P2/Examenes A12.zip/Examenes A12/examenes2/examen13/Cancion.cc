#include "Cancion.h"

const int Cancion::SP = -1;

Cancion::Cancion(string nombre, string artista, int punt){
	this->nombre = nombre;
	this->artista = artista;
	if(punt < 0 || punt > 5){
		this->puntuacion = Cancion::SP;
	}
	else{
		this->puntuacion = punt;
	}
}

string Cancion::getNombre() const{
	return nombre;
}

string Cancion::getArtista() const{
	return artista;
}

int Cancion::getPuntuacion() const{
	return puntuacion;
}

void Cancion::setPuntuacion(int puntuacion){
	if(puntuacion >= 1 && puntuacion <= 5){
		this->puntuacion = puntuacion;
	}
}

ostream &operator<<(ostream &os, const Cancion &cancion){
	os << cancion.nombre << " - " << cancion.artista;
	if(cancion.puntuacion != Cancion::SP){
		os << " - " << cancion.puntuacion;
	}
	return os;
}
