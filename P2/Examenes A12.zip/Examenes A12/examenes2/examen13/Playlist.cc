#include "Playlist.h"
#include <algorithm>
Playlist::Playlist(string nombre){
	this->nombre = nombre;
}

float Playlist::getPuntuacionMedia() const{
	float media = 0;
	int numPuntuaciones;

	numPuntuaciones = 0;
	for(int i = 0; i < canciones.size(); i++){
		if(canciones[i].getPuntuacion() != Cancion::SP){		
			media = media + canciones[i].getPuntuacion();
			numPuntuaciones++;		
		}
	}
	if(numPuntuaciones != 0){
		media = media / numPuntuaciones;
	}
	return media;	
}

// un vector con los nombres de los artistas, sin reptidos.
vector<string> Playlist::getArtistas() const{
	vector<string> artistas;

	for(int i = 0; i < canciones.size(); i++){
		if(find(artistas.begin(), artistas.end(), canciones[i].getArtista() )== artistas.end()){
			artistas.push_back(canciones[i].getArtista());
		}	
	}
	return artistas;
}

bool Playlist::anyadirCancion(const Cancion &c) {
	bool anyadida = false;
	bool encontrada;
	encontrada = buscarCancion(c);
	if(encontrada == false){
		anyadida = true;
		canciones.push_back(c);
	}
	return anyadida;
}

bool Playlist::buscarCancion(const Cancion &c) const{
	bool encontrada = false;
	for(int i = 0; i < canciones.size() && encontrada == false; i++){
		if(canciones[i].getNombre() == c.getNombre() && canciones[i].getArtista() == c.getArtista()){
			encontrada = true;		
		}
	}
	return encontrada;
}

ostream &operator<<(ostream &os, const Playlist &playlist){
	os << "Titulo: " << playlist.nombre << endl;
	os << "Artistas: ";
	vector<string> artistas = playlist.getArtistas();
	for(int i = 0; i < artistas.size(); i++){
		os << artistas[i];
		if(i != artistas.size() - 1){
			os << ", ";
		}
	}
	os << endl;
	os << "---------------" << endl;
	for(int i = 0; i < playlist.canciones.size(); i++){
		os << playlist.canciones[i] << endl;
	}
	os << "----------------" << endl;
	os << "Puntuacion media= " << playlist.getPuntuacionMedia();




	return os;
}








