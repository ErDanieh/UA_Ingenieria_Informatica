#include "List.h"
#include <sstream>

bool List::searchMovie(string title){
	bool found = false;
	
	for(int i = 0; i < movies.size() && !found; i++){
		if(movies[i].getTitle() == title){
			found = true;
		}
	}

	return found;	
}

List::List(string name){
	this->name = name;
}

// desc = "el titulo, 12"
void List::addMovie(string desc, Genre genre){
	string newTitle;
	int newScore;
	stringstream ss(desc);
	bool found;

	getline(ss, newTitle, ','); // se queda en el ' '
	ss >> newScore;
	try{
		Movie nueva(newTitle, genre, newScore);
		found = searchMovie(newTitle);
		if(!found){
			movies.push_back(nueva);
		}
	}
	catch(int &e){
		cout << "Wrong movie \"" << newTitle << "\"" << endl;
	}

}	

float List::getMeanScore() const{
	float media;
	media = 0;
	for(int i = 0; i < movies.size(); i++){
		media += movies[i].getScore();
	}
	if(movies.size() > 0){
		media /= movies.size();
	}
	return media;
}

ostream &operator<<(ostream &os, const List &list){
	os << list.name << endl;
	os << list.getMeanScore() << endl;
	for(int i =0; i < list.movies.size(); i++){
		os << list.movies[i] << endl;
	}	

	return os;
}







