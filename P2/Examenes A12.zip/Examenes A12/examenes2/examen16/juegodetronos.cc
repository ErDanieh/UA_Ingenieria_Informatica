#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
// En el fichero binario hay esto almacenado muchas veces :)
struct Entrada{
	char nombre1[40];
	int relacion;
	char nombre2[40];
};
struct Personaje{
	string name;
	vector<string> relatives;
	vector<string> enemies;
	vector<string> friends;
};
int buscar(vector<Personaje> &personajes, string nombre){
	int i, pos;
	pos = -1;
	for(i = 0; i < personajes.size() && pos == -1; i++){
		if(personajes[i].name == nombre){
			pos = i;
		}
	}
	return pos;
}
void actualizar(vector<Personaje> &personajes, Entrada nueva){
	int pos1, pos2;
	Personaje nuevo;
	pos1 = buscar(personajes, nueva.nombre1);
	if(pos1 == -1){
		nuevo.name = nueva.nombre1;
		personajes.push_back(nuevo);
		pos1 = personajes.size() - 1;
	}
	pos2 = buscar(personajes, nueva.nombre2);
	if(pos2 == -1){
		nuevo.name = nueva.nombre2;
		personajes.push_back(nuevo);
		pos2 = personajes.size() - 1;
	}
	switch(nueva.relacion){
		case 0:
			personajes[pos1].relatives.push_back(nueva.nombre2);
			personajes[pos2].relatives.push_back(nueva.nombre1);
		break;
		case 1:
			personajes[pos1].enemies.push_back(nueva.nombre2);
			personajes[pos2].enemies.push_back(nueva.nombre1);
		break;
		case 2:
			personajes[pos1].friends.push_back(nueva.nombre2);
			personajes[pos2].friends.push_back(nueva.nombre1);
		break;
	}
	
}

void imprimir(vector<string> lista){
	for(int i = 0; i < lista.size(); i++){
		cout << lista[i];
		if(i != lista.size() - 1){
			cout << ", ";
		}
	}
	cout << endl;
}
void procesarFichero(string nombreFichero){
	// se va actualizando con cada una de las entradas que leemos
	// del fichero binario.
	vector<Personaje> personajes;
	Entrada leida;
	Personaje p;
	ifstream fich;

	fich.open(nombreFichero.c_str(), ios::binary);
	if(fich.is_open()){
		fich.read((char *) &leida, sizeof(leida));
		while(!fich.eof()){
			actualizar(personajes, leida);
			fich.read((char *) &leida, sizeof(leida));
		}
		fich.close();
		// irmprimir la lista de personajes.
		for(int i = 0; i < personajes.size(); i++){
			cout << "Name: " << personajes[i].name << endl;
			if(personajes[i].relatives.size() != 0){			
				cout << "Relatives: ";
				imprimir(personajes[i].relatives);
			}
			if(personajes[i].enemies.size() != 0){
				cout << "Enemies: ";
				imprimir(personajes[i].enemies);
			}
			if(personajes[i].friends.size() != 0){
				cout << "Friends: ";
				imprimir(personajes[i].friends);
			}
		}		
	}
}
int main(int argc, char *argv[]){
	if(argc == 2){
		procesarFichero(argv[1]);
	}

}







