#include "Fighter.h"
#include <iostream>
using namespace std;


int main(){
	Fighter fighter1("x-athar", 20, 30);
	Fighter fighter2("y-carmen", 90, 30);
	Fighter fighter3("aguarraFobia", 30, 30);

	bool defeated = fighter2.fight(fighter1);

	cout << defeated << endl;
	cout << fighter1 << endl;
	cout << fighter2 << endl;
	
	return 0;
}
