#include "Squadron.h"
#include <fstream>

Squadron::Squadron(string filename, string name){
	ifstream fich;
	string type;
	int attack, shield;
	
	wins = 0;
	losses = 0;
	this->name = name;
	fich.open(filename.c_str());
	if(!fich.is_open()){
		throw 1; // si el fichero no se puedo abrido
	}
	fich >> type >> attack >> shield;
	while(!fich.eof()){
		try{
			Fighter nuevo(type, attack, shield);
			fighters.push_back(nuevo);
		}
		catch(int &e){
			cout << "Wrong fighter data" << endl;
		}	
		fich >> type >> attack >> shield;
	}
	fich.close();
	
}

// this lucha con enemy
void Squadron::fight(Squadron &enemy){
	int pos, posEnemy;
	bool defeated1, defeated2;

	while(fighters.size() > 0 && enemy.fighters.size() > 0){
		// dos posiciones aleatorias
		pos = Fighter::getRandomNumber(fighters.size());
		posEnemy = Fighter::getRandomNumber(enemy.fighters.size());
		
		// los saco de la posicion aleatoria
		Fighter feste = fighters[pos];
		Fighter fenemy = enemy.fighters[posEnemy];

		// los elimino (pero los tengo en feste y fenemy)
		fighters.erase(fighters.begin() + pos);
		enemy.fighters.erase(enemy.fighters.begin() + posEnemy);
		
		cout << feste.getType() << " VS " << fenemy.getType() << endl;
		cout << "=============================================" << endl;
		// se atacan hasta que uno gana
		do{
			defeated1 = feste.fight(fenemy);
			if(!defeated1){
				defeated2 = fenemy.fight(feste);
			}
			else{
				defeated2 = false;
			}
		}while(!defeated1 && !defeated2);
		if(defeated1){ // gana feste
			cout << feste.getType() << " wins!!!" << endl;
			fighters.push_back(feste);
			wins++;
			enemy.losses++;
		}
		else{ // gana fenemy
			cout << fenemy.getType() << " wins!!!" << endl;
			enemy.fighters.push_back(fenemy);
			losses++;
			enemy.wins++;
		}
	}

}

ostream &operator<<(ostream &os, const Squadron &sq){
	os << sq.name << ": Wins=" << sq.wins;
	os << " Losses=" << sq.losses;
	for(int i = 0; i < sq.fighters.size(); i++){
		os << " " << sq.fighters[i];
	}	
	return os;
}


