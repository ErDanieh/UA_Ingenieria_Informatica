#ifndef _SQUADRON_
#define _SQUADRON_
#include "Fighter.h"
#include <vector>
#include <iostream>
using namespace std;
class Squadron{
	friend ostream &operator<<(ostream &os, const Squadron &sq);
	private:
		string name;
		int wins;
		int losses;
		vector<Fighter> fighters;
	public:
		Squadron(string filename, string name = "");
		void fight(Squadron &enemy);
};
#endif
