#include <iostream>
#include <fstream>
#include <cctype>
#include <vector>
#include <algorithm>
using namespace std;

// imprimir las 5 palabras que mas se repiten en el fichero.
struct Palabra{
	string palabra;
	int veces;
};

// inserto la palabra si no esta en el vector.
void insertarPalabra(vector<Palabra> &palabras, string palabra){
	int pos, i;
	// si esta hay que incrementar l a cantidad de veces y si no esta, hay que añadir una nueva al final.
	pos = -1;
	for(i = 0; i < palabras.size() && pos == -1; i++){
		if(palabras[i].palabra == palabra){
			pos = i;
		}
	}
	if(pos == -1){
		Palabra nueva = {palabra, 1};
		palabras.push_back(nueva);
	}
	else{
		palabras[pos].veces++;
	}

}

void procesarLinea(string linea, vector<Palabra> &palabras){
	// vector<string> palabras; cada linea añade palabras al vector que hay en leerFichero
	int i;
	string palabra;

	i = 0;
	while(i < linea.length()){
		// busca el comienzo de la palabra
		while(i < linea.length() && isalpha(linea[i]) == 0){
			i++;
		}
		// buscar el fin de la palabra
		palabra = "";
		while(i < linea.length() && isalpha(linea[i]) != 0){
			palabra += linea[i];
			i++;
		}
		if(palabra != ""){
			insertarPalabra(palabras, palabra);
		}
	}
	
}


// mostrar la cantidad de palabras que hay en cada linea.
void leerFichero(const char filename[]){
	ifstream fich;
	string linea;
	vector<Palabra> palabras;

	fich.open(filename);
	if(!fich.is_open()){
		cout << "Cant open file " << filename << endl;
	}
	else{
		getline(fich, linea);
		while(!fich.eof()){
			procesarLinea(linea, palabras);
			getline(fich, linea);
		}
		fich.close();
		
		// ordenar el vector (bubblesort)
		for(int i = 0; i < palabras.size(); i++){
			for(int j = palabras.size() - 1; j >= i; j--){
				if(palabras[j].veces > palabras[j-1].veces){
					Palabra aux = palabras[j];
					palabras[j] = palabras[j-1];
					palabras[j-1] = aux;		
				}
			}
		}

		for(int i = 0; i < 5 && i < palabras.size(); i++){
			cout << palabras[i].palabra << ", " << palabras[i].veces << endl;
		}
	}
}

int main(int argc, char *argv[]){
	if(argc == 2){
		// argv[0] es el nombre del programa
		leerFichero(argv[1]);
	}
	else{
		cout << "Ussage: ./main nombreFichero" << endl;
	}
}
