#include <iostream>
#include <string>
#include <fstream>

using namespace std;


int main()
{
    string line1;
    string line2;

    ifstream f1("f1.txt");
    ifstream f2("f2.txt");

    

    if(f1.is_open() && f2.is_open()){
        while(getline(f1,line1) && getline(f2,line2)){
            if (line1 != line2){
                cout << "< " << line1 << endl;
                cout << "> " << line2 << endl;
            }
        }
    }

    else
    {
        /* code */
    }
    

}