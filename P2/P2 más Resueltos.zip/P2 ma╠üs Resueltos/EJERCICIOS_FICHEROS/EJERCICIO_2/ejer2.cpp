
#include <iostream>
#include <string>
#include <fstream>

using namespace std;


int main(){

    
    ifstream fi("fichero.txt"); //Fichero de entrada
    ofstream fo("FICHERO.txt"); //Fichero de salida

    if (fi.is_open()) // Comprobar que el fichero se puede abrir/existe/no daerrores
    {
        char c; //Variable que almacena el caracter
        while (fi.get(c)){ //lee caracter a caracter
        /*
            Traducir como lee letra mientras exista
        */
            if (islower(c) != 0) // Vemos que es minuscula para pasarlo
                                // a mayuscula
            {
                fo << (char)toupper(c);
                //Hay que poner char porque sino 
                //devuelve el entero del codigo asci                
            }

            else
            {
                fo << c; 
            }
        }
    }
    
    else
    {
        cout << "No funciona." << endl;
    }

}
