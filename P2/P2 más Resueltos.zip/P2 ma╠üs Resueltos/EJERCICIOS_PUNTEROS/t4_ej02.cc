// Programación 2
// Tema 4 - Ejercicio 2

#include <iostream>
#include <fstream>

using namespace std;

const char kFICHERO[]="fichero.dat";
const int kTAM=32; // tamaño máximo de nombre

// Definimos el tipo "Cliente" y el puntero a ese tipo ("pCliente")
// El tipo "pCliente" se podría haber definido también con "typedef Cliente *pCliente;"
typedef struct{
  char nombre[kTAM];
  int edad;
}Cliente,*pCliente;

int main(){
  ifstream ficheroEntrada;

  ficheroEntrada.open(kFICHERO,ios::binary);
  if(ficheroEntrada.is_open()){
    pCliente nuevo = new Cliente; // Reservamos memoria para almacenar un cliente
                                  // Se podría haber hecho también con "Cliente *nuevo = new Cliente;" si no hubiéramos definido "pCliente"
    
    // "nuevo" es un puntero que almacena la dirección de memoria que acabamos de reservar
    // No se debe aplicar el operador '&' para saber la dirección de "nuevo", 
    // ya que "nuevo" ya almacena la dirección donde queremos guardar la información
    ficheroEntrada.read((char *)nuevo,sizeof(Cliente));

    // Mostramos el contenido por pantalla
    // Al ser un puntero a registro, usamos "->" para acceder a sus campos
    cout << "Nombre: " << nuevo->nombre << endl;
    cout << "Edad: " << nuevo->edad << endl;
    
    delete nuevo;
        
    ficheroEntrada.close();
  }
  else{
    cerr << "ERROR: no se ha podido abrir el fichero " << kFICHERO << endl;
  }
}
