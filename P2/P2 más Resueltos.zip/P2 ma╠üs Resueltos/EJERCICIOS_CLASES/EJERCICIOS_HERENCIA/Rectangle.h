#include <iostream>
#include "Shape.h"

using namespace std;


class Rectangle: public Shapees
{
  public:
    int getArea(){
      return (width * height);
    }
};


