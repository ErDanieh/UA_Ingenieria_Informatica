#include "Cliente.h"

Cliente::Cliente(string nom,string dir,string tel){
  nombre=nom;
  direccion=dir;
  telefono=tel;
}

