#ifndef _COORDENADAS_H_
#define _COORDENADAS_H_

#include <iostream>
using namespace std;


class Coordenada
{
  
  friend ostream& operator<<(ostream& os, const Coordenada& obj);
  
  private:
    float x;
    float y;

  public:
    Coordenada(float cx=0, float cy=0);
    Coordenada(const Coordenada &);
    ~Coordenada();
    float getX() const;
    float getY() const;
    void setX(float cx);
    void setY(float cy);
    
};

#endif
