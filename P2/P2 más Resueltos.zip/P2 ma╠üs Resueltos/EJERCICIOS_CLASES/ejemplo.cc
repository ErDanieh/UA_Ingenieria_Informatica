
#include "ejemplo.h"
#include <iostream>
using namespace std;

Rect::Rect(int ax, int ay, int bx, int by) {
  x1=ax;
  y1=ay;
  x2=bx;
  y2=by;
}

Rect::~Rect() { }

int Rect::base() { return (x2-x1); }
int Rect::altura() { return (y2-y1); }
int Rect::area() { return base()* altura(); }


// main.cc
int main()
{
  Rect r(10,20,40,50);
  cout << r.area() << endl;
  cout << r.base() << endl;
  cout << r.altura() << endl;
}