
#include <iostream>
#include "fecha.h"

using namespace std;


fecha::fecha(int d, int m, int a){
  dia = d;
  mes = m;
  anyo = a;
}

fecha::~fecha(){}


int fecha::getDia(){
  return dia;
}

int fecha::getMes(){
  return mes;
}

int fecha::getAnyo(){
  return anyo;
}

void fecha::setDia(int d){
  dia = d;
}

void fecha::setMes(int m){
  mes = m;
}

void fecha::setAnyo(int a){
  anyo = a;
}

int main(){

  fecha f;
  cout << f.getDia() << " " << f.getMes() << " " << f.getAnyo() << endl;

  cout << f.getDia() << " " << f.getMes() << " " << f.getAnyo() << endl;
  f.setDia(3);
  cout << f.getDia() << " " << f.getMes() << " " << f.getAnyo() << endl;
  f.setMes(5);
  cout << f.getDia() << " " << f.getMes() << " " << f.getAnyo() << endl;
  f.setAnyo(1996);
  cout << f.getDia() << " " << f.getMes() << " " << f.getAnyo() << endl;
  return 0;
}