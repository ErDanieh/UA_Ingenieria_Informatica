#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <cctype>

using namespace std;


const string solicitarPregunta = "Hola, soy C3PBot. Escribe tu pregunta a continuaci on:";


struct dataBase
{
  string preguntaAlmacenada;
  string respuestaAlmacenada;
};


string estandarizarPalabra(string palabra){
  string palabraEstandarizada;
  string letra;

  for (unsigned i=0; palabra.length(); i++){
    if(islower(palabra[i]) != 0){
      letra = tolower(palabra[i]);
      palabraEstandarizada = palabraEstandarizada + letra;
    }
    else{
      palabraEstandarizada = palabraEstandarizada + letra;
    }
    
  }

  return palabraEstandarizada;
}

vector <string> estandarizarTexto(vector <string> pregunta){

  vector <string> textoEstandarizado;
  for (unsigned i=0; i < pregunta.size(); i++){
    textoEstandarizado.push_back(estandarizarPalabra(pregunta[i]));
  }

  return textoEstandarizado;
}


int main(){

  vector <dataBase> data;

  string pregunta;
  cout << solicitarPregunta << endl;

  cin >> pregunta;


  return 0;
}

