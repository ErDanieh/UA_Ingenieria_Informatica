#include "Movie.h"


const int Movie::NS = -1;

Movie::Movie(string title, Genre genre, int score){
  
  if(score>5 || score<-1){
    throw exception();
  }
  
  this->title=title;
  this->genre=genre;
  this->score=score;
}

string Movie::genreToString(Genre genre){
  string genreName = "";

  switch (genre)
  {
  case Action:
    genreName = "Action";
    break;
  
  case SciFi:
    genreName = "SciFi";
    break;

  case Drama:
    genreName = "Drama";
    break;

  case Comedy:
    genreName = "Comedy";
    break;
  }

  return genreName;
}

ostream &operator<<(ostream &os, const Movie &m){
  cout << m.getTitle() << " (" << m.getScores() << ") " << Movie::genreToString(m.getGenre()) << endl;
  return os;
}