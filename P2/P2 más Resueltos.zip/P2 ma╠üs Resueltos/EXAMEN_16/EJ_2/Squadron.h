#ifndef _SQUADRON_H_
#define _SQUADRON_H_


#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>
#include "Fighter.h"

using namespace std;

class Squadron
{
  friend ostream& operator<<(ostream &os, Squadron &q);
  private:
    vector <Fighter> fighters;
    string name;
    int wins;
    int losses;
  public:
    Squadron(string filename, string name = "");
    void fight(Squadron &enemy);
};


#endif