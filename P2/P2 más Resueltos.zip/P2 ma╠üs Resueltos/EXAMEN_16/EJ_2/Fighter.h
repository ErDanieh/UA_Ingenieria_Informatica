#ifndef _FIGHTER_H_
#define _FIGHTER_H_


#include <iostream>
#include <string>
#include <vector>

using namespace std;


class Fighter
{
  friend ostream& operator<<(ostream &os, Fighter &f);
  private:
    string type;
    int attack;
    int shield;
  public:
    Fighter(string type, int attack, int shield);
    static int getRandomNumber(int n);
    bool fight(Fighter &enemy);
    int getAttack() const { return attack; };
    int getShield() const { return shield; };
    void setAttack(int attack);
    void setShield(int shield);
};



#endif