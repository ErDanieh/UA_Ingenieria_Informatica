#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <vector>
#include <cstring>

using namespace std;

struct Relaciones
{
  char nombre1[40];
  int relacion;
  char nombre2[40];
};

void leerFichero(string filename, vector <Relaciones> &todasRelaciones);
void devolverInformacion(vector <Relaciones> todasRelaciones);


int main(int args, char *argv[]){

  vector <Relaciones> todasRelaciones;
  string filename;

  if(args != 2){
    cout << "Error arguments. " << endl;
  }
  else
  {
    filename = argv[1];
    cout << (string) argv[1] << endl;
    leerFichero(filename,todasRelaciones);
    devolverInformacion(todasRelaciones);
  }
  
  cout << endl;
  return 0;
}

void devolverInformacion(vector <Relaciones> todasRelaciones){
  char name[40];
  cout << "Name: ";
  cin.getline(name,40);
  cout << name << endl;

  cout << "Relatives: " ;

  for(unsigned i = 0; i < todasRelaciones.size(); i++){
    if(strcmp(name,todasRelaciones[i].nombre1)==0 && todasRelaciones[i].relacion == 0){
      cout << (string) todasRelaciones[i].nombre2 << ", ";
    }
    if(strcmp(name,todasRelaciones[i].nombre2)==0 && todasRelaciones[i].relacion == 0){
      cout << (string) todasRelaciones[i].nombre1 << ", ";
    }
  }

  cout << endl << "Enemys: " ;

  for(unsigned i = 0; i < todasRelaciones.size(); i++){
    if(strcmp(name,todasRelaciones[i].nombre1)==0 && todasRelaciones[i].relacion == 1){
      cout << (string) todasRelaciones[i].nombre2 << ", ";
    }
    if(strcmp(name,todasRelaciones[i].nombre2)==0 && todasRelaciones[i].relacion == 1){
      cout << (string) todasRelaciones[i].nombre1 << ", ";
    }
  }

  cout << endl << "Friends: " ;

  for(unsigned i = 0; i < todasRelaciones.size(); i++){
    if(strcmp(name,todasRelaciones[i].nombre1)==0 && todasRelaciones[i].relacion == 2){
      cout << (string) todasRelaciones[i].nombre2 << ", ";
    }
    if(strcmp(name,todasRelaciones[i].nombre2)==0 && todasRelaciones[i].relacion == 2){
      cout << (string) todasRelaciones[i].nombre1 << ", ";
    }
  }
}

void leerFichero(string filename, vector <Relaciones> &todasRelaciones){

  Relaciones relaciones;

  ifstream ficheroBinario(filename,ios::binary);

  if(ficheroBinario.is_open()){
    while (ficheroBinario.read((char*)&relaciones,sizeof(relaciones))){
      todasRelaciones.push_back(relaciones);
    }

    ficheroBinario.close();
  }
  else
  {
    cout << "El fichero no se puede abrir. " << endl;
  }
}