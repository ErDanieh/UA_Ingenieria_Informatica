#include "Station.h"

unsigned int Station::nextId = 1;

Station::Station(string filename){
  
  unsigned i = 0;
  string mes;
  float T,TM,Tm;
  string test;
  ifstream ficheroEntrada;
  ficheroEntrada.open(filename);

  getline(ficheroEntrada,name);
   
  
  while(ficheroEntrada >> mes){
    ficheroEntrada >> T;
    data[0][i] = T;
    ficheroEntrada >> TM;
    data[1][i] = TM;
    ficheroEntrada >> Tm;
    data[2][i] = Tm;
    i++;
  }
  

  id = nextId;
  nextId++;
}

float Station::getValue(Value v, Month m ) const{
  return data[v][m];
}