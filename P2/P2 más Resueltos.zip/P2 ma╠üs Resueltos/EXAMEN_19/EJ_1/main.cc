#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <vector>
#include <string>
#include <cstring>


using namespace std;


#define PELOTON_MIN 30
#define PELOTON_MAX 50


struct Tropas
{
  char family[40];    // Nombre de la familia a la que pertenecen los soldados
  char type[20];      // Tipo de soldados: cavalry (caballerı́a), infantry (infanterı́a), ...
  unsigned int units; // Número de soldados (unidades) disponibles
};


void leerDatosBatlla(string filename, vector <Tropas> &tropas);
void leerLoosesBatalla(string filename, vector <Tropas> &tropasAgrupadas);
void mostrarTropas(vector <Tropas> tropasAgrupadas);
vector <Tropas> agruparPelotones(vector <Tropas> tropas);



int main(int args, char *argv[]){

  vector <Tropas> tropasIniciales;  // Tropas enviadas inicialmente
  vector <Tropas> tropasAgrupadas;  // Tropas agrupadas según su familia y tipo

  string ficheroTexto = "troops.dat";
  string ficheroBinario = "losses.txt";

  leerDatosBatlla(ficheroTexto,tropasIniciales);
  tropasAgrupadas = agruparPelotones(tropasIniciales);
  leerLoosesBatalla(ficheroBinario,tropasAgrupadas);
  mostrarTropas(tropasAgrupadas);


  return 0;
}

void mostrarTropas(vector <Tropas> tropasAgrupadas){
  int j = 0;
  int mixed = 0;

  for (unsigned i = 0; i < tropasAgrupadas.size(); i++){
    do{

      if(tropasAgrupadas[i].units>=PELOTON_MAX){
        cout << j+1 << ". " << (string) tropasAgrupadas[i].family << " | " << (string) tropasAgrupadas[i].type << " | " << PELOTON_MAX << endl;
        j++;
        tropasAgrupadas[i].units -= PELOTON_MAX;
      }
      else if(tropasAgrupadas[i].units<PELOTON_MAX && tropasAgrupadas[i].units>=PELOTON_MIN){
        cout << j+1 << ". " << (string) tropasAgrupadas[i].family << " | " << (string) tropasAgrupadas[i].type << " | " << tropasAgrupadas[i].units << endl;
        j++;
        tropasAgrupadas[i].units = 0;
      }

    }while (tropasAgrupadas[i].units>PELOTON_MIN);
    
    mixed += tropasAgrupadas[i].units;
    tropasAgrupadas[i].units = 0;
  }

  if(mixed>0){
    cout << j+1 << ". " << "Mixed" <<  " | " << mixed << endl;
  }
}

/*
  funcion que devuelve un vector <Tropas> de las tropas agrupadas
  segun su familia y tipo
*/
vector <Tropas> agruparPelotones(vector <Tropas> tropas){
  
  vector <Tropas> agrupadas;
  bool existe = false;

  for (unsigned i = 0; i < tropas.size(); i++)
  {
    existe = false;

    for(unsigned j = 0; j < agrupadas.size() && existe == false; j++){
      if(strcmp(tropas[i].family,agrupadas[j].family)==0
        && strcmp(tropas[i].type,agrupadas[j].type)==0){

        agrupadas[j].units += tropas[i].units;
        existe = true;
      }
    }

    if(existe==false){
      agrupadas.push_back(tropas[i]);
    }
  }
  
  return agrupadas;
}



/*
  funcion que carga la informacion en tropas
*/
void leerDatosBatlla(string filename, vector <Tropas> &tropas){


  Tropas tropa;

  ifstream ficheroBinario(filename,ios::binary);

  if(ficheroBinario.is_open()){
    while (ficheroBinario.read((char*)&tropa,sizeof(tropa)))
    {
      tropas.push_back(tropa);
    }

    ficheroBinario.close();
  }

  else
  {
    cout << "Error file not open. " << endl;
  }
}


/*
  funcion que elimina actualiza los datos de tropas
*/
void leerLoosesBatalla(string filename, vector <Tropas> &tropasAgrupadas){
  
  string linea;
  string localizacion;
  string familia;
  string tipo;
  string unidades;

  bool tropasDescontadasCorrectamente = true;
  bool tropasDescontdas = false;

  ifstream ficheroPerdidas(filename);

  while( getline(ficheroPerdidas ,linea) )
  {
    stringstream li(linea);
    getline(li,localizacion,'|');

    while (getline(li,familia,'-'))
    {
      tropasDescontadasCorrectamente = true;

      getline(li,tipo,':');
      getline(li,unidades,'|');

      for (unsigned i = 0; i < tropasAgrupadas.size() 
          && tropasDescontadasCorrectamente == true; i++)
      {
        if(strcmp(tropasAgrupadas[i].family,familia.c_str())==0
          && strcmp(tropasAgrupadas[i].type,tipo.c_str())==0 ){
          
          if((unsigned) stoi(unidades)>tropasAgrupadas[i].units){
            cout << "Wrong troop" << endl;
            tropasDescontadasCorrectamente = false;
            tropasDescontdas = true;
          }

          else
          {
            tropasAgrupadas[i].units -= stoi(unidades);
            tropasDescontdas = true;
          }
        }
      }

      if(tropasDescontdas == false){
        cout << "Wrong troop" << endl;
      }
    }
  } 
}